# IUT Bencase Test Launcher (C# App)

A small Windows desktop app that runs the VBA test scripts stored in the
IUT Bencase `.xlsm` workbooks — the same job the Excel "Master" launcher
workbook does today, as a standalone program with run statistics.

- Pick a folder → the app lists **every** `.xlsm` test file in it (no
  fixed list; new files appear automatically). Excel lock files
  (`~$...`) that exist while a workbook is open are ignored.
- Check the files to run → they execute **one at a time, in order**,
  each in its own Excel process.
- A per-test **timeout** closes a blocked test (for example a script
  waiting on a dialog) and continues with the next one.
- A **one-time scheduled run** starts the checked tests unattended.
- Every run is recorded; the **History & Statistics** tab shows per-file
  run counts, success rate, average duration and last result, with CSV
  export.

See `docs/Proposal.md` for the design overview.

## Requirements

- Windows 10/11
- Microsoft Excel (desktop, 2016 or later / Microsoft 365) — required:
  the test macros live in the workbooks and are executed by Excel.
- To **build**: Visual Studio 2022 (Community is fine) with the
  ".NET desktop development" workload, **or** the .NET 8 SDK.

The test files' folder should be an Excel **Trusted Location**
(Excel → Options → Trust Center → Trusted Locations), or macro
settings must otherwise allow these files — the same requirement as
with the Excel launcher.

## Build

**Visual Studio:** open `src/IUTBencaseTestLauncher.sln`, press
**Build → Build Solution** (or F6). The exe appears in
`src/IUTBencaseTestLauncher/bin/Release/net8.0-windows/`
(Release) or the `Debug` folder.

**Command line (with the .NET 8 SDK installed):**

```
cd src
dotnet publish IUTBencaseTestLauncher -c Release -o ..\publish
```

Copy the contents of the output folder anywhere and run
`IUTBencaseTestLauncher.exe`. No installation, no admin rights.

Notes for the machine that *runs* the app: the .NET 8 Desktop Runtime
must be present (it is included with Visual Studio / the SDK, and is a
free download from Microsoft). To ship without that requirement, publish
self-contained instead: add `-r win-x64 --self-contained true` to the
command above (bigger output, nothing to install).

## First run

1. Start the app. In **Test files folder**, browse to the folder that
   contains the test `.xlsm` files (default: the app's own folder).
2. The list fills with every `.xlsm` in that folder. The **Script to
   run** column is filled in automatically from the file name
   (`..._CCB.xlsm` → `Bencase_test_CCB`); edit any row if a file uses a
   different macro name — the app remembers it per file name.
   Or click **Scan scripts**: the app reads the macros actually stored
   in each file and fills the column with one that exists; if a file
   holds several and none matches the file-name convention, it asks
   you to pick. Scanning needs one Excel setting (see
   Troubleshooting); typing names manually works without it.
3. Check the files to run and click **Run Selected** (or **Run All**).

## Options

- **Save file after a successful run** — saves the workbook after its
  script finishes (the app closes each test's Excel process afterwards,
  so there is no "leave open" mode; results are in the saved file).
- **Show Excel window while running** — watch the test work, or leave
  it hidden in the background.
- **Max minutes per test** (default 180) — if a single test runs longer
  than this, the app closes that test's Excel process, records the run
  as **Timed out**, and continues with the next test. Set it above your
  longest normal test.
- **Stop** button — closes the current test's Excel process (recorded
  as **Stopped**) and stops the queue.

## Scheduled run (one time)

Set a date and time in **Run once at:** and click **Start Schedule**.
The app waits (status shows "Pending"), then runs the checked tests
once, with no confirmation dialogs. Click **Stop Schedule** to cancel.
The app must stay open until the run time, and the PC must not sleep
through a long queue — the same operational notes as the Excel
launcher.

## History & Statistics tab

- **Statistics per test file**: runs, successes, failures, timeouts,
  success rate, average duration, last run and last result.
- **Run history**: every run with start time, file, script, status,
  duration and message. Filter by **All time / Last 7 days /
  Last 30 days**; **Export history to CSV** writes the filtered history
  to a file for reporting.

## Data files (created next to the exe)

- `launcher-settings.json` — folder, options, per-file script names and
  checkbox states.
- `run-history.csv` — the full run history. Deleting it starts the
  statistics from zero; the app recreates it on the next run.

## Troubleshooting

- **"Microsoft Excel is not installed"** — the app needs desktop Excel
  on the same PC.
- **A run fails immediately with an Excel error** — usually macro
  security: add the test folder as a Trusted Location (see
  Requirements), or check that the file opens and its macro runs
  manually in Excel.
- **A run fails in a second or two and the macro works in Excel** —
  the name in the **Script to run** column does not exist in that
  file. Click **Scan scripts** to pick a name that exists, or type
  the right one.
- **Scan reports that Excel blocked reading the scripts** — enable
  **Trust access to the VBA project object model** (Excel → Options →
  Trust Center → Trust Center Settings → Macro Settings), then scan
  again; or type the script names manually.
- **A test shows "Timed out"** — its script ran past the limit
  (often a dialog inside the script waiting for a click). Raise
  **Max minutes per test** if the test legitimately needs longer.
- **A leftover EXCEL.EXE process** — the app closes the Excel process
  of each test it starts; it never touches Excel windows you opened
  yourself.

## Project layout

```
docs/Proposal.md                     Design proposal
src/IUTBencaseTestLauncher.sln       Visual Studio solution
src/IUTBencaseTestLauncher/
  Program.cs                         Entry point
  MainForm.cs                        Run tab, run queue, scheduling
  MainForm.Stats.cs                  History & Statistics tab
  ExcelRunner.cs                     Runs one test in its own Excel
                                     process, with timeout / stop
  Models.cs                          Data types + macro-name convention
  SettingsStore.cs                   launcher-settings.json
  HistoryStore.cs                    run-history.csv + statistics
```
