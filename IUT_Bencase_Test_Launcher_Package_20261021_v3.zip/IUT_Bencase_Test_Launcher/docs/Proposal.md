# Proposal: IUT Bencase Test Launcher (C# Desktop App)

**Date:** 2026-10-21
**Status:** For review
**Replaces / extends:** The current Excel/VBA "Master" launcher workbook

## 1. Background

Today, the IUT Bencase test scripts (VBA macros stored in `.xlsm` workbooks
such as `IUT_Bencase_Automation_CCB.xlsm`) are started from an Excel-based
launcher workbook ("Master"). The launcher works and is in daily use: it
lists the test files, runs their scripts one by one in order, logs every
run, and supports a one-time scheduled run.

Its limits are structural, because the launcher itself is an Excel
workbook: it must be built and maintained inside Excel, settings live in
worksheet cells, statistics are limited to a log sheet, and if a test
script ever blocks on a dialog, the launcher is frozen together with the
test — a stuck test cannot be skipped automatically.

This proposal moves the launcher into a small standalone C# Windows
application with the same functions, plus proper run statistics.

## 2. Objective

A Windows desktop app ("IUT Bencase Test Launcher") that lets an operator:

- choose a folder and see **all** test workbooks in it (no fixed list —
  new test files are picked up automatically),
- select which files to execute and run them **sequentially**, one file
  completely finishing before the next starts,
- schedule a one-time unattended run,
- and get clear **statistics** on every execution: what ran, when, how
  long it took, and whether it succeeded.

## 3. Functional scope (parity with the current launcher, plus statistics)

| Area | Behaviour |
|---|---|
| File discovery | The app scans the selected folder for `*.xlsm` files and lists however many it finds. Adding a file to the folder adds it to the list; no configuration change is needed. |
| Script per file | The macro to run is derived automatically from the file name (suffix after the last `_`, e.g. `..._CCB` → `Bencase_test_CCB`). It can be edited per file in the list; the app remembers the setting per file name. |
| Selection | Each file has a checkbox. **Run Selected** runs the checked files; **Run All** runs everything in the list. |
| Execution | Files run one at a time, in list order. Each file runs in **its own Excel process**, controlled by the app. Options: save the file after a successful run; show or hide the Excel window while running. |
| Timeout & skip | Each test has a configurable maximum duration (default 180 minutes). If a test exceeds it — for example because its script is waiting on a dialog — the app closes that test's Excel process, records the run as **Timed out**, and continues with the next test. A **Stop** button does the same on demand. *(New capability; not possible in the Excel-based launcher.)* |
| Scheduling | One-time scheduled run, same behaviour as today: set a date and time, the app waits and then runs the checked files once, unattended (no confirmation dialogs). The app must stay open until the run time. |
| Run history | Every run is recorded automatically: file, script, start time, end time, duration, status (Success / Failed / Timed out / Stopped) and an error/note message. History is kept in a local CSV file next to the app. |
| Statistics | A dedicated view shows, per test file: number of runs, successes, failures, timeouts, success rate, average duration, last run time and last result — filterable by period (all time / last 7 days / last 30 days) and exportable to CSV for reporting. |
| Excel dialogs | While a test runs, Excel's own alerts are suppressed by the app, so routine Excel prompts do not interrupt unattended runs. |

## 4. How it works

The app does not replace the test scripts. The macros stay in the Excel
workbooks, unchanged. The app uses Excel automation (COM) to open a
workbook in a separate Excel process, run its macro, wait for it to
finish, save and close it, and record the result. Because each test runs
in its own process, a hung or dialog-blocked test can be terminated
without affecting the app or the remaining tests.

Settings (folder, per-file script names, selections, options) are stored
in a small JSON file next to the app; run history in a CSV file. No
server, database or network access is required.

## 5. Requirements and deployment

- Windows 10/11 PC with Microsoft Excel installed (desktop version,
  2016 or later / Microsoft 365). Excel is required because the test
  macros live in the workbooks; the app cannot execute VBA by itself.
- Built with C# / WinForms on .NET 8. Deployment is a single folder
  containing the `.exe` and its data files — copy it to the machine and
  run. No installation and no admin rights are needed.
- The test workbooks' folder should be an Excel **Trusted Location**
  (or macro settings must allow the files), the same requirement as
  with the current launcher.

## 6. Limitations and notes

- One difference from the Excel launcher: because every test runs in
  its own Excel process that closes afterwards, the "leave the target
  file open to inspect results" option becomes "save after run"
  (results are in the saved file, as today when the launcher closes it).
- A test killed by the timeout may leave its workbook in an
  intermediate state; that run is marked **Timed out** in the log so it
  is visible and can be re-run.
- Scheduled runs require the app (not Excel) to stay open, and the PC
  must not sleep through a long queue of tests — the same operational
  note as today.

## 7. Rollout plan

1. Build the app and pilot it with the current six test files, in
   parallel with the existing Excel launcher.
2. Compare run logs between the two for a few runs.
3. Switch daily use to the app; keep the Excel launcher as a fallback.

## 8. Deliverables in this package

- `docs/Proposal.md` — this document.
- `src/` — complete C# source code (Visual Studio solution), ready to
  build on a Windows machine.
- `README.md` — build, usage and troubleshooting instructions.
