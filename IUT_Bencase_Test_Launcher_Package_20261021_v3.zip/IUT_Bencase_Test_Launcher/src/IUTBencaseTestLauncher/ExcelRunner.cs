using System.Diagnostics;
using System.Runtime.InteropServices;

namespace IutBencaseTestLauncher;

/// <summary>
/// Runs one test macro in its OWN Excel process (created via COM
/// automation, late-bound so no Office interop assembly is needed at
/// build time and any Excel version works at run time).
///
/// Because the macro runs in a separate process, a test that hangs or
/// blocks on a dialog cannot freeze this app: when the timeout expires
/// (or the operator presses Stop, which calls <see cref="RequestStop"/>),
/// the runner kills exactly that Excel process. The blocked COM call
/// then fails, and the run is recorded as Timed out / Stopped.
/// </summary>
public sealed class ExcelRunner
{
    [DllImport("user32.dll")]
    private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);

    private volatile bool _timedOut;
    private volatile bool _stopRequested;
    private int _excelPid;

    /// <summary>Ask the currently running test (if any) to stop: its Excel
    /// process is killed and the run is recorded as Stopped.</summary>
    public void RequestStop()
    {
        _stopRequested = true;
        KillExcelProcess();
    }

    public bool IsStopRequested => _stopRequested;

    public RunRecord RunOne(TestFileItem item, AppSettings settings)
    {
        var record = new RunRecord
        {
            Start = DateTime.Now,
            FileName = item.FileName,
            Macro = item.MacroName,
        };
        var stopwatch = Stopwatch.StartNew();
        _timedOut = false;
        _stopRequested = false;
        _excelPid = 0;

        dynamic excel = null;
        dynamic workbook = null;

        // Watchdog: checks every 5 seconds whether the timeout expired.
        using var watchdog = new System.Threading.Timer(
            _ =>
            {
                if (settings.TimeoutMinutes > 0 &&
                    stopwatch.Elapsed.TotalMinutes >= settings.TimeoutMinutes)
                {
                    _timedOut = true;
                    KillExcelProcess();
                }
            },
            null, TimeSpan.FromSeconds(5), TimeSpan.FromSeconds(5));

        try
        {
            if (string.IsNullOrWhiteSpace(item.MacroName))
                throw new InvalidOperationException(
                    "No script name set for this file. Enter it in the 'Script to run' column first.");

            var excelType = Type.GetTypeFromProgID("Excel.Application")
                ?? throw new InvalidOperationException(
                    "Microsoft Excel is not installed on this computer.");
            excel = Activator.CreateInstance(excelType);
            TryCapturePid(excel);

            excel.Visible = settings.ShowExcelWindow;
            excel.DisplayAlerts = false;      // no Excel prompts during the run
            excel.AskToUpdateLinks = false;
            excel.EnableEvents = false;       // suppress the file's Workbook_Open

            // UpdateLinks:=0, ReadOnly:=false
            workbook = excel.Workbooks.Open(item.FilePath, 0, false);
            excel.EnableEvents = true;

            // Same call form as the Excel launcher: 'FileName.xlsm'!MacroName
            string runTarget = "'" + item.FileName + "'!" + item.MacroName;
            excel.Run(runTarget);

            if (settings.SaveAfterRun) workbook.Save();

            record.Status = RunStatus.Success;
            record.Message = "Completed.";
        }
        catch (Exception ex)
        {
            if (_timedOut)
            {
                record.Status = RunStatus.TimedOut;
                record.Message = $"Exceeded the {settings.TimeoutMinutes} minute limit " +
                                 "and was closed (a script dialog or a hang is the usual cause).";
            }
            else if (_stopRequested)
            {
                record.Status = RunStatus.Stopped;
                record.Message = "Stopped by the operator.";
            }
            else
            {
                record.Status = RunStatus.Failed;
                record.Message = ShortError(ex);
            }
        }
        finally
        {
            stopwatch.Stop();
            record.End = DateTime.Now;
            record.DurationSec = stopwatch.Elapsed.TotalSeconds;

            try { workbook?.Close(false); } catch { /* process may be gone */ }
            try { excel?.Quit(); } catch { /* process may be gone */ }
            ReleaseCom(workbook);
            ReleaseCom(excel);
            EnsureProcessGone(_excelPid);
            _excelPid = 0;
        }

        return record;
    }

    private void TryCapturePid(dynamic excel)
    {
        try
        {
            int hwnd = Convert.ToInt32(excel.Hwnd);
            if (hwnd != 0 &&
                GetWindowThreadProcessId((IntPtr)hwnd, out uint pid) != 0)
            {
                _excelPid = (int)pid;
            }
        }
        catch
        {
            // No PID: timeout/kill will be unavailable for this run,
            // but the run itself can still proceed normally.
        }
    }

    private void KillExcelProcess()
    {
        int pid = _excelPid;
        if (pid <= 0) return;
        try
        {
            using var process = Process.GetProcessById(pid);
            if (!process.HasExited) process.Kill();
        }
        catch
        {
            // Already gone, or no permission: nothing more to do.
        }
    }

    private static void EnsureProcessGone(int pid)
    {
        if (pid <= 0) return;
        try
        {
            using var process = Process.GetProcessById(pid);
            if (!process.WaitForExit(3000) && !process.HasExited)
                process.Kill();
        }
        catch
        {
            // Already exited.
        }
    }

    private static void ReleaseCom(object comObject)
    {
        try
        {
            if (comObject != null && Marshal.IsComObject(comObject))
                Marshal.FinalReleaseComObject(comObject);
        }
        catch
        {
            // Best effort only.
        }
    }

    private static string ShortError(Exception ex)
    {
        string message = ex.Message?.Trim() ?? ex.GetType().Name;
        if (ex is COMException com)
            message = $"Excel error 0x{com.HResult:X8}: {message}";
        // Keep the history cell readable: collapse line breaks.
        message = message.Replace("\r", " ").Replace("\n", " ");
        return message.Length > 300 ? message[..300] + "..." : message;
    }
}
