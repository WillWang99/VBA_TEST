using System.Globalization;
using System.Text;

namespace IutBencaseTestLauncher;

/// <summary>
/// Run history stored as CSV in run-history.csv next to the exe:
/// one row per finished run. The reader is a small full CSV parser so
/// messages containing commas, quotes or line breaks survive intact.
/// </summary>
public static class HistoryStore
{
    public static string HistoryPath =>
        Path.Combine(AppContext.BaseDirectory, "run-history.csv");

    public const string HeaderLine =
        "Start,End,File,Script,Status,DurationSec,Message";

    private const string TimeFormat = "yyyy-MM-dd HH:mm:ss";

    public static void Append(RunRecord record)
    {
        bool writeHeader = !File.Exists(HistoryPath) || new FileInfo(HistoryPath).Length == 0;
        using var writer = new StreamWriter(HistoryPath, append: true);
        if (writeHeader) writer.WriteLine(HeaderLine);
        writer.WriteLine(ToCsvLine(record));
    }

    public static string ToCsvLine(RunRecord r)
    {
        return string.Join(",",
            Escape(r.Start.ToString(TimeFormat, CultureInfo.InvariantCulture)),
            Escape(r.End.ToString(TimeFormat, CultureInfo.InvariantCulture)),
            Escape(r.FileName),
            Escape(r.Macro),
            Escape(r.Status),
            r.DurationSec.ToString("0.0", CultureInfo.InvariantCulture),
            Escape(r.Message));
    }

    public static string Escape(string value)
    {
        value ??= "";
        return "\"" + value.Replace("\"", "\"\"") + "\"";
    }

    public static List<RunRecord> LoadAll()
    {
        var records = new List<RunRecord>();
        if (!File.Exists(HistoryPath)) return records;

        string text;
        try { text = File.ReadAllText(HistoryPath); }
        catch { return records; }

        foreach (var fields in ParseCsv(text))
        {
            if (fields.Count < 7) continue;
            if (fields[0] == "Start") continue; // header
            if (!DateTime.TryParseExact(fields[0], TimeFormat, CultureInfo.InvariantCulture,
                    DateTimeStyles.None, out var start)) continue;
            DateTime.TryParseExact(fields[1], TimeFormat, CultureInfo.InvariantCulture,
                DateTimeStyles.None, out var end);
            double.TryParse(fields[5], NumberStyles.Float, CultureInfo.InvariantCulture,
                out var duration);
            records.Add(new RunRecord
            {
                Start = start,
                End = end,
                FileName = fields[2],
                Macro = fields[3],
                Status = fields[4],
                DurationSec = duration,
                Message = fields[6],
            });
        }
        return records;
    }

    /// <summary>Per-file aggregates over the given records.</summary>
    public static List<FileStats> ComputeStats(IEnumerable<RunRecord> records)
    {
        return records
            .GroupBy(r => r.FileName)
            .Select(g =>
            {
                var list = g.OrderBy(r => r.Start).ToList();
                return new FileStats
                {
                    FileName = g.Key,
                    Runs = list.Count,
                    Successes = list.Count(r => r.Status == RunStatus.Success),
                    Failures = list.Count(r => r.Status == RunStatus.Failed),
                    Timeouts = list.Count(r => r.Status == RunStatus.TimedOut),
                    AverageDurationSec = list.Count == 0 ? 0 : list.Average(r => r.DurationSec),
                    LastRun = list.Count == 0 ? null : list[^1].Start,
                    LastStatus = list.Count == 0 ? "" : list[^1].Status,
                };
            })
            .OrderBy(s => s.FileName, StringComparer.OrdinalIgnoreCase)
            .ToList();
    }

    /// <summary>Minimal RFC-4180-style CSV parser (quotes, "" escapes,
    /// commas and newlines inside quoted fields).</summary>
    private static IEnumerable<List<string>> ParseCsv(string text)
    {
        var rows = new List<List<string>>();
        var field = new StringBuilder();
        var row = new List<string>();
        bool inQuotes = false;

        for (int i = 0; i < text.Length; i++)
        {
            char c = text[i];
            if (inQuotes)
            {
                if (c == '"')
                {
                    if (i + 1 < text.Length && text[i + 1] == '"')
                    {
                        field.Append('"');
                        i++;
                    }
                    else inQuotes = false;
                }
                else field.Append(c);
            }
            else if (c == '"') inQuotes = true;
            else if (c == ',')
            {
                row.Add(field.ToString());
                field.Clear();
            }
            else if (c == '\r' || c == '\n')
            {
                if (c == '\r' && i + 1 < text.Length && text[i + 1] == '\n') i++;
                row.Add(field.ToString());
                field.Clear();
                if (row.Count > 1 || row[0].Length > 0) rows.Add(row);
                row = new List<string>();
            }
            else field.Append(c);
        }
        if (field.Length > 0 || row.Count > 0)
        {
            row.Add(field.ToString());
            rows.Add(row);
        }
        return rows;
    }
}
