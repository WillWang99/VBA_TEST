namespace IutBencaseTestLauncher;

/// <summary>
/// Main window, "Run tests" tab: pick a folder, the app lists every
/// .xlsm test file in it, check the ones to run, Run Selected / Run All,
/// plus a one-time scheduled run — the same workflow as the Excel
/// launcher, with the addition of a per-test timeout that skips a
/// blocked test (see ExcelRunner). The "History &amp; Statistics" tab
/// lives in MainForm.Stats.cs.
/// </summary>
public sealed partial class MainForm : Form
{
    private readonly AppSettings _settings;
    private readonly ExcelRunner _runner = new();
    private readonly List<TestFileItem> _items = new();

    private bool _isRunning;
    private bool _stopQueue;
    private bool _scanning;
    private bool _loadingList;   // true while RefreshFileList fills the grid
    private DateTime? _scheduledAt;
    private string _currentItemName = "";
    private DateTime? _currentItemStart;

    // Run tab controls
    private TextBox _txtFolder = null!;
    private DataGridView _grid = null!;
    private CheckBox _chkSave = null!;
    private CheckBox _chkShow = null!;
    private NumericUpDown _numTimeout = null!;
    private Button _btnRunSelected = null!;
    private Button _btnRunAll = null!;
    private Button _btnStop = null!;
    private Button _btnStartSchedule = null!;
    private Button _btnStopSchedule = null!;
    private DateTimePicker _dtpSchedule = null!;
    private Label _lblScheduleStatus = null!;
    private ToolStripStatusLabel _statusMain = null!;
    private ToolStripStatusLabel _statusElapsed = null!;
    private System.Windows.Forms.Timer _uiTimer = null!;

    private int _colRun, _colFile, _colMacro, _colLastResult, _colLastDuration;

    public MainForm()
    {
        _settings = SettingsStore.Load();
        BuildUi();
        LoadSettingsIntoControls();
        Shown += (_, _) =>
        {
            RefreshFileList(initial: true);
            RefreshStats();
        };
        FormClosing += OnFormClosing;
    }

    // ------------------------------------------------------------------
    // UI construction (code-built so the project needs no designer files)
    // ------------------------------------------------------------------
    private void BuildUi()
    {
        Text = "IUT Bencase Test Launcher";
        StartPosition = FormStartPosition.CenterScreen;
        Size = new Size(1140, 740);
        MinimumSize = new Size(920, 600);

        var tabs = new TabControl { Dock = DockStyle.Fill };
        var tabRun = new TabPage("Run tests");
        var tabStats = new TabPage("History && Statistics");
        tabs.TabPages.Add(tabRun);
        tabs.TabPages.Add(tabStats);
        Controls.Add(tabs);

        var statusStrip = new StatusStrip();
        _statusMain = new ToolStripStatusLabel("Ready") { Spring = true, TextAlign = ContentAlignment.MiddleLeft };
        _statusElapsed = new ToolStripStatusLabel("");
        statusStrip.Items.Add(_statusMain);
        statusStrip.Items.Add(_statusElapsed);
        Controls.Add(statusStrip);

        BuildRunTab(tabRun);
        BuildStatsTab(tabStats);

        _uiTimer = new System.Windows.Forms.Timer { Interval = 1000 };
        _uiTimer.Tick += UiTimer_Tick;
        _uiTimer.Start();
    }

    private void BuildRunTab(TabPage page)
    {
        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 4,
            Padding = new Padding(8),
        };
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 40));   // folder
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));   // grid
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 52));   // options + run buttons
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 52));   // schedule
        page.Controls.Add(layout);

        // --- Folder row ---
        var folderPanel = new FlowLayoutPanel { Dock = DockStyle.Fill, WrapContents = false };
        folderPanel.Controls.Add(new Label { Text = "Test files folder:", AutoSize = true, Margin = new Padding(0, 6, 4, 0) });
        _txtFolder = new TextBox { Width = 620 };
        folderPanel.Controls.Add(_txtFolder);
        var btnBrowse = new Button { Text = "Browse...", AutoSize = true };
        btnBrowse.Click += BtnBrowse_Click;
        folderPanel.Controls.Add(btnBrowse);
        var btnRefresh = new Button { Text = "Refresh list", AutoSize = true };
        btnRefresh.Click += (_, _) => { SaveGeneralSettings(); RefreshFileList(initial: false); };
        folderPanel.Controls.Add(btnRefresh);
        var btnAll = new Button { Text = "Select all", AutoSize = true };
        btnAll.Click += (_, _) => SetAllSelected(true);
        folderPanel.Controls.Add(btnAll);
        var btnNone = new Button { Text = "Select none", AutoSize = true };
        btnNone.Click += (_, _) => SetAllSelected(false);
        folderPanel.Controls.Add(btnNone);
        var btnScan = new Button { Text = "Scan scripts", AutoSize = true };
        btnScan.Click += async (_, _) => await ScanScriptsAsync();
        folderPanel.Controls.Add(btnScan);
        layout.Controls.Add(folderPanel, 0, 0);

        // --- File grid ---
        _grid = new DataGridView
        {
            Dock = DockStyle.Fill,
            AllowUserToAddRows = false,
            AllowUserToDeleteRows = false,
            RowHeadersVisible = false,
            SelectionMode = DataGridViewSelectionMode.FullRowSelect,
            AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None,
        };
        _colRun = _grid.Columns.Add(new DataGridViewCheckBoxColumn { Name = "colRun", HeaderText = "Run", Width = 45 });
        _colFile = _grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "colFile", HeaderText = "Test file", ReadOnly = true, AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill });
        _colMacro = _grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "colMacro", HeaderText = "Script to run", Width = 250 });
        _colLastResult = _grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "colLastResult", HeaderText = "Last result", Width = 110, ReadOnly = true });
        _colLastDuration = _grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "colLastDuration", HeaderText = "Last duration", Width = 110, ReadOnly = true });
        _grid.CurrentCellDirtyStateChanged += (_, _) =>
        {
            if (_grid.IsCurrentCellDirty) _grid.CommitEdit(DataGridViewDataErrorContexts.Commit);
        };
        _grid.CellValueChanged += (_, e) => { if (!_loadingList && e.RowIndex >= 0 && e.ColumnIndex == _colRun) SyncRowToSettings(e.RowIndex); };
        _grid.CellEndEdit += (_, e) => { if (!_loadingList && e.RowIndex >= 0 && e.ColumnIndex == _colMacro) SyncRowToSettings(e.RowIndex); };
        layout.Controls.Add(_grid, 0, 1);

        // --- Options + run buttons ---
        var optionsPanel = new FlowLayoutPanel { Dock = DockStyle.Fill, WrapContents = false };
        _chkSave = new CheckBox { Text = "Save file after a successful run", AutoSize = true, Margin = new Padding(0, 14, 12, 0) };
        _chkSave.CheckedChanged += (_, _) => SaveGeneralSettings();
        optionsPanel.Controls.Add(_chkSave);
        _chkShow = new CheckBox { Text = "Show Excel window while running", AutoSize = true, Margin = new Padding(0, 14, 12, 0) };
        _chkShow.CheckedChanged += (_, _) => SaveGeneralSettings();
        optionsPanel.Controls.Add(_chkShow);
        optionsPanel.Controls.Add(new Label { Text = "Max minutes per test:", AutoSize = true, Margin = new Padding(0, 15, 4, 0) });
        _numTimeout = new NumericUpDown { Minimum = 1, Maximum = 1440, Width = 70, Margin = new Padding(0, 11, 16, 0) };
        _numTimeout.ValueChanged += (_, _) => SaveGeneralSettings();
        optionsPanel.Controls.Add(_numTimeout);
        _btnRunSelected = new Button { Text = "Run Selected", AutoSize = true, Margin = new Padding(0, 9, 8, 0) };
        _btnRunSelected.Click += async (_, _) => await RunQueueAsync(SelectedItems(), silent: false);
        optionsPanel.Controls.Add(_btnRunSelected);
        _btnRunAll = new Button { Text = "Run All", AutoSize = true, Margin = new Padding(0, 9, 8, 0) };
        _btnRunAll.Click += async (_, _) => await RunQueueAsync(new List<TestFileItem>(_items), silent: false);
        optionsPanel.Controls.Add(_btnRunAll);
        _btnStop = new Button { Text = "Stop", AutoSize = true, Enabled = false, Margin = new Padding(0, 9, 0, 0) };
        _btnStop.Click += (_, _) =>
        {
            _stopQueue = true;
            _runner.RequestStop();
            _statusMain.Text = "Stopping...";
        };
        optionsPanel.Controls.Add(_btnStop);
        layout.Controls.Add(optionsPanel, 0, 2);

        // --- Schedule row ---
        var schedulePanel = new FlowLayoutPanel { Dock = DockStyle.Fill, WrapContents = false };
        schedulePanel.Controls.Add(new Label { Text = "Run once at:", AutoSize = true, Margin = new Padding(0, 13, 4, 0) });
        _dtpSchedule = new DateTimePicker
        {
            Format = DateTimePickerFormat.Custom,
            CustomFormat = "yyyy-MM-dd HH:mm",
            ShowUpDown = true,
            Width = 170,
            Margin = new Padding(0, 10, 8, 0),
            Value = DateTime.Today.AddDays(1).AddHours(9),
        };
        schedulePanel.Controls.Add(_dtpSchedule);
        _btnStartSchedule = new Button { Text = "Start Schedule", AutoSize = true, Margin = new Padding(0, 9, 8, 0) };
        _btnStartSchedule.Click += BtnStartSchedule_Click;
        schedulePanel.Controls.Add(_btnStartSchedule);
        _btnStopSchedule = new Button { Text = "Stop Schedule", AutoSize = true, Margin = new Padding(0, 9, 12, 0) };
        _btnStopSchedule.Click += (_, _) =>
        {
            if (_scheduledAt.HasValue)
            {
                _scheduledAt = null;
                _lblScheduleStatus.Text = "Schedule is OFF";
                MessageBox.Show("Schedule cancelled. No run is pending.", "Scheduled Run",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        };
        schedulePanel.Controls.Add(_btnStopSchedule);
        _lblScheduleStatus = new Label { Text = "Schedule is OFF", AutoSize = true, Margin = new Padding(0, 13, 0, 0) };
        schedulePanel.Controls.Add(_lblScheduleStatus);
        layout.Controls.Add(schedulePanel, 0, 3);
    }

    // ------------------------------------------------------------------
    // Settings and file list
    // ------------------------------------------------------------------
    private void LoadSettingsIntoControls()
    {
        _txtFolder.Text = string.IsNullOrWhiteSpace(_settings.FolderPath)
            ? AppContext.BaseDirectory
            : _settings.FolderPath;
        _chkSave.Checked = _settings.SaveAfterRun;
        _chkShow.Checked = _settings.ShowExcelWindow;
        _numTimeout.Value = Math.Clamp(_settings.TimeoutMinutes, 1, 1440);
    }

    private void SaveGeneralSettings()
    {
        _settings.FolderPath = _txtFolder.Text.Trim();
        _settings.SaveAfterRun = _chkSave.Checked;
        _settings.ShowExcelWindow = _chkShow.Checked;
        _settings.TimeoutMinutes = (int)_numTimeout.Value;
        SettingsStore.Save(_settings);
    }

    private void RefreshFileList(bool initial)
    {
        string folder = _txtFolder.Text.Trim();
        _items.Clear();
        _grid.Rows.Clear();

        if (string.IsNullOrWhiteSpace(folder) || !Directory.Exists(folder))
        {
            if (!initial)
                MessageBox.Show("The folder does not exist. Please choose the folder that " +
                                "contains the test .xlsm files.", "Folder Not Found",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            _statusMain.Text = "Folder not found: " + folder;
            return;
        }

        var lastByFile = HistoryStore.LoadAll()
            .GroupBy(r => r.FileName)
            .ToDictionary(g => g.Key, g => g.OrderBy(r => r.Start).Last(),
                StringComparer.OrdinalIgnoreCase);

        // Skip Excel owner/lock files (~$<name>.xlsm): they appear while a
        // workbook is open and are not real test files.
        var files = Directory.GetFiles(folder, "*.xlsm")
            .Where(f => !Path.GetFileName(f).StartsWith("~$", StringComparison.Ordinal))
            .OrderBy(f => Path.GetFileName(f), StringComparer.OrdinalIgnoreCase);

        // While filling the grid, setting cell values fires the grid's
        // change events; _loadingList stops those handlers from syncing
        // half-filled rows back into the settings (which blanked the
        // script names in v1.0).
        _loadingList = true;
        foreach (string path in files)
        {
            string name = Path.GetFileName(path);
            var item = new TestFileItem
            {
                FileName = name,
                FilePath = path,
                // An empty stored value counts as "not set" and is healed
                // by re-deriving from the file name.
                MacroName = _settings.MacroByFile.TryGetValue(name, out var macro) &&
                            !string.IsNullOrWhiteSpace(macro)
                    ? macro
                    : TestFileItem.DeriveMacroName(name),
                Selected = !_settings.SelectedByFile.TryGetValue(name, out var sel) || sel,
            };
            _items.Add(item);

            int row = _grid.Rows.Add();
            _grid.Rows[row].Cells[_colRun].Value = item.Selected;
            _grid.Rows[row].Cells[_colFile].Value = item.FileName;
            _grid.Rows[row].Cells[_colMacro].Value = item.MacroName;
            if (lastByFile.TryGetValue(name, out var last))
            {
                _grid.Rows[row].Cells[_colLastResult].Value = last.Status;
                _grid.Rows[row].Cells[_colLastDuration].Value = FormatDuration(last.DurationSec);
            }
        }
        _loadingList = false;

        _statusMain.Text = _items.Count == 0
            ? "No .xlsm test files found in this folder."
            : $"Found {_items.Count} test file(s). Check the ones to run, then Run Selected.";
    }

    private void SyncRowToSettings(int rowIndex)
    {
        if (rowIndex < 0 || rowIndex >= _items.Count) return;
        var row = _grid.Rows[rowIndex];
        var item = _items[rowIndex];
        item.Selected = row.Cells[_colRun].Value is true;
        item.MacroName = row.Cells[_colMacro].Value?.ToString()?.Trim() ?? "";
        _settings.SelectedByFile[item.FileName] = item.Selected;
        _settings.MacroByFile[item.FileName] = item.MacroName;
        SettingsStore.Save(_settings);
    }

    private void SetAllSelected(bool selected)
    {
        for (int i = 0; i < _grid.Rows.Count; i++)
        {
            _grid.Rows[i].Cells[_colRun].Value = selected;
            SyncRowToSettings(i);
        }
    }

    private List<TestFileItem> SelectedItems() => _items.Where(i => i.Selected).ToList();

    private void BtnBrowse_Click(object sender, EventArgs e)
    {
        using var dialog = new FolderBrowserDialog
        {
            Description = "Choose the folder that contains the test .xlsm files",
            UseDescriptionForTitle = true,
            SelectedPath = Directory.Exists(_txtFolder.Text.Trim()) ? _txtFolder.Text.Trim() : "",
        };
        if (dialog.ShowDialog(this) == DialogResult.OK)
        {
            _txtFolder.Text = dialog.SelectedPath;
            SaveGeneralSettings();
            RefreshFileList(initial: false);
        }
    }

    // ------------------------------------------------------------------
    // Scanning: read the real macro list out of each file, so the
    // operator picks an existing script instead of typing (and possibly
    // mistyping) its name. Typing in the Script column still works.
    // ------------------------------------------------------------------
    private async Task ScanScriptsAsync()
    {
        if (_isRunning || _scanning) return;
        if (_items.Count == 0)
        {
            MessageBox.Show("No test files are listed. Choose the folder first, then scan.",
                "Scan Scripts", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        _scanning = true;
        _btnRunSelected.Enabled = false;
        _btnRunAll.Enabled = false;
        _btnStartSchedule.Enabled = false;
        _grid.Enabled = false;
        _txtFolder.Enabled = false;
        var notes = new List<string>();
        try
        {
            for (int i = 0; i < _items.Count; i++)
            {
                var item = _items[i];
                _statusMain.Text = $"Scanning {item.FileName}...";
                List<string> macros;
                try
                {
                    macros = await Task.Run(() => MacroScanner.ScanMacros(item.FilePath));
                }
                catch (Exception ex)
                {
                    notes.Add(item.FileName + ": " + ex.Message);
                    continue;
                }
                if (macros.Count == 0)
                {
                    notes.Add(item.FileName + ": no runnable scripts found in this file.");
                    continue;
                }
                string derived = TestFileItem.DeriveMacroName(item.FileName);
                string chosen =
                    macros.FirstOrDefault(m => string.Equals(m, item.MacroName, StringComparison.OrdinalIgnoreCase)) ??
                    macros.FirstOrDefault(m => string.Equals(m, derived, StringComparison.OrdinalIgnoreCase)) ??
                    (macros.Count == 1 ? macros[0] : ChooseMacro(item.FileName, macros, item.MacroName));
                if (chosen != null)
                {
                    item.MacroName = chosen;
                    _grid.Rows[i].Cells[_colMacro].Value = chosen;
                    SyncRowToSettings(i);
                }
                else
                {
                    notes.Add($"{item.FileName}: found {macros.Count} scripts ({string.Join(", ", macros)}). " +
                              "Run Scan again to pick one, or type the name in the Script column.");
                }
            }
        }
        finally
        {
            _scanning = false;
            SetRunningUi(false);
            _statusMain.Text = "Scan finished.";
        }
        if (notes.Count > 0)
            MessageBox.Show(string.Join("\n\n", notes), "Scan Scripts",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    /// <summary>Small chooser shown when a file holds several scripts and
    /// none matches the current/default name. Returns null on Skip.</summary>
    private string ChooseMacro(string fileName, List<string> macros, string current)
    {
        using var form = new Form
        {
            Text = "Choose script",
            StartPosition = FormStartPosition.CenterParent,
            Size = new Size(430, 330),
            MinimizeBox = false,
            MaximizeBox = false,
            FormBorderStyle = FormBorderStyle.FixedDialog,
        };
        var list = new ListBox { Dock = DockStyle.Fill };
        list.Items.AddRange(macros.ToArray());
        list.SelectedItem =
            macros.FirstOrDefault(m => string.Equals(m, current, StringComparison.OrdinalIgnoreCase)) ?? macros[0];
        list.DoubleClick += (_, _) => { form.DialogResult = DialogResult.OK; form.Close(); };
        var label = new Label
        {
            Dock = DockStyle.Top,
            Height = 46,
            Padding = new Padding(8, 6, 8, 0),
            Text = $"{fileName} contains {macros.Count} scripts.\nChoose the one this launcher should run:",
        };
        var buttons = new FlowLayoutPanel
        {
            Dock = DockStyle.Bottom,
            Height = 44,
            FlowDirection = FlowDirection.RightToLeft,
            Padding = new Padding(6),
        };
        var ok = new Button { Text = "Use selected", AutoSize = true, DialogResult = DialogResult.OK };
        var cancel = new Button { Text = "Skip", AutoSize = true, DialogResult = DialogResult.Cancel };
        buttons.Controls.Add(ok);
        buttons.Controls.Add(cancel);
        form.Controls.Add(list);
        form.Controls.Add(label);
        form.Controls.Add(buttons);
        form.AcceptButton = ok;
        form.CancelButton = cancel;
        return form.ShowDialog(this) == DialogResult.OK ? list.SelectedItem?.ToString() : null;
    }

    // ------------------------------------------------------------------
    // Running
    // ------------------------------------------------------------------
    private async Task RunQueueAsync(List<TestFileItem> items, bool silent)
    {
        if (_isRunning) return;
        if (items.Count == 0)
        {
            if (!silent)
                MessageBox.Show("Nothing to run. Check at least one test file in the list.",
                    "Run", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        // Make sure the latest macro edits / checkboxes are what runs.
        for (int i = 0; i < _grid.Rows.Count; i++) SyncRowToSettings(i);
        SaveGeneralSettings();

        _isRunning = true;
        _stopQueue = false;
        SetRunningUi(true);
        int ok = 0, failed = 0, timedOut = 0, stopped = 0;

        try
        {
            foreach (var item in items)
            {
                if (_stopQueue) break;
                _currentItemName = item.FileName;
                _currentItemStart = DateTime.Now;
                SetRowResult(item, "Running...", "");
                _statusMain.Text = $"Running {item.FileName} (script {item.MacroName})...";

                var record = await Task.Run(() => _runner.RunOne(item, _settings));

                HistoryStore.Append(record);
                SetRowResult(item, record.Status, FormatDuration(record.DurationSec));
                switch (record.Status)
                {
                    case RunStatus.Success: ok++; break;
                    case RunStatus.TimedOut: timedOut++; break;
                    case RunStatus.Stopped: stopped++; break;
                    default: failed++; break;
                }
                if (_runner.IsStopRequested) _stopQueue = true;
            }
        }
        finally
        {
            _isRunning = false;
            _currentItemStart = null;
            _statusElapsed.Text = "";
            SetRunningUi(false);
            RefreshStats();
        }

        string summary = $"Finished: {ok} succeeded, {failed} failed, " +
                         $"{timedOut} timed out, {stopped} stopped. See History && Statistics for details.";
        _statusMain.Text = summary;
        if (!silent)
            MessageBox.Show(summary.Replace("&&", "&"), "Run Finished",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    private void SetRowResult(TestFileItem item, string status, string duration)
    {
        int idx = _items.IndexOf(item);
        if (idx < 0 || idx >= _grid.Rows.Count) return;
        _grid.Rows[idx].Cells[_colLastResult].Value = status;
        _grid.Rows[idx].Cells[_colLastDuration].Value = duration;
    }

    private void SetRunningUi(bool running)
    {
        _btnRunSelected.Enabled = !running;
        _btnRunAll.Enabled = !running;
        _btnStartSchedule.Enabled = !running;
        _btnStop.Enabled = running;
        _grid.Enabled = !running;
        _txtFolder.Enabled = !running;
    }

    internal static string FormatDuration(double seconds)
    {
        if (seconds < 60) return $"{seconds:0.0} s";
        int total = (int)Math.Round(seconds);
        return $"{total / 60} min {total % 60:00} s";
    }

    // ------------------------------------------------------------------
    // Scheduling (one-time) and the 1-second UI timer
    // ------------------------------------------------------------------
    private void BtnStartSchedule_Click(object sender, EventArgs e)
    {
        if (_isRunning)
        {
            MessageBox.Show("A run is in progress. Please wait for it to finish.",
                "Scheduled Run", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        var target = new DateTime(_dtpSchedule.Value.Year, _dtpSchedule.Value.Month,
            _dtpSchedule.Value.Day, _dtpSchedule.Value.Hour, _dtpSchedule.Value.Minute, 0);
        if (target <= DateTime.Now)
        {
            MessageBox.Show("The scheduled time is in the past. Please choose a future date and time.",
                "Scheduled Run", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            return;
        }
        if (SelectedItems().Count == 0)
        {
            MessageBox.Show("No test file is checked. Check the files to run first.",
                "Scheduled Run", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            return;
        }
        _scheduledAt = target;
        _lblScheduleStatus.Text = $"Pending: runs once at {target:yyyy-MM-dd HH:mm}";
        MessageBox.Show($"Scheduled. The app will run the checked tests once at {target:yyyy-MM-dd HH:mm}.\n\n" +
                        "Keep this app open until then. Click [Stop Schedule] to cancel.",
            "Scheduled Run", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    private async Task TriggerScheduledRunAsync()
    {
        _lblScheduleStatus.Text = "Running (scheduled run)...";
        await RunQueueAsync(SelectedItems(), silent: true);
        _lblScheduleStatus.Text = $"Done: ran at {DateTime.Now:yyyy-MM-dd HH:mm}. Schedule is OFF";
    }

    private void UiTimer_Tick(object sender, EventArgs e)
    {
        if (_isRunning && _currentItemStart.HasValue)
        {
            var elapsed = DateTime.Now - _currentItemStart.Value;
            _statusElapsed.Text = $"{_currentItemName} elapsed {(int)elapsed.TotalMinutes}:{elapsed.Seconds:00}";
        }

        if (_scheduledAt.HasValue && !_isRunning && DateTime.Now >= _scheduledAt.Value)
        {
            _scheduledAt = null;
            _ = TriggerScheduledRunAsync();
        }
    }

    private void OnFormClosing(object sender, FormClosingEventArgs e)
    {
        if (_isRunning)
        {
            var answer = MessageBox.Show(
                "A test is running. Exit anyway?\nThe current test's Excel process will be closed.",
                "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (answer != DialogResult.Yes)
            {
                e.Cancel = true;
                return;
            }
            _runner.RequestStop();
        }
        SaveGeneralSettings();
    }
}
