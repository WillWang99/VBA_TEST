using System.Diagnostics;
using System.Runtime.InteropServices;

namespace IutBencaseTestLauncher;

/// <summary>
/// Reads the list of runnable macros (public Subs) stored inside a
/// workbook, by walking its VBA project through Excel automation —
/// the same job the "Scan" buttons did in the Excel launcher.
///
/// Reading the VBA project requires Excel's "Trust access to the VBA
/// project object model" setting (Excel &gt; Options &gt; Trust Center
/// &gt; Trust Center Settings &gt; Macro Settings). When it is off, this
/// throws an InvalidOperationException explaining that; typing the
/// script name manually always works as a fallback.
/// </summary>
public static class MacroScanner
{
    [DllImport("user32.dll")]
    private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);

    private const int VbExtPkProc = 0; // vbext_proctype.vbext_pk_Proc

    public static List<string> ScanMacros(string filePath)
    {
        dynamic excel = null;
        dynamic workbook = null;
        int pid = 0;

        try
        {
            var excelType = Type.GetTypeFromProgID("Excel.Application")
                ?? throw new InvalidOperationException(
                    "Microsoft Excel is not installed on this computer.");
            excel = Activator.CreateInstance(excelType);
            pid = TryGetPid(excel);
            excel.Visible = false;
            excel.DisplayAlerts = false;
            excel.AskToUpdateLinks = false;
            excel.EnableEvents = false;

            // UpdateLinks:=0, ReadOnly:=true (scanning never modifies the file)
            workbook = excel.Workbooks.Open(filePath, 0, true);

            dynamic project;
            try
            {
                project = workbook.VBProject;
            }
            catch (COMException)
            {
                throw new InvalidOperationException(
                    "Excel blocked reading the scripts in this file. To use Scan, enable " +
                    "'Trust access to the VBA project object model' (Excel > Options > " +
                    "Trust Center > Trust Center Settings > Macro Settings), or type the " +
                    "script name manually.");
            }

            var names = new SortedSet<string>(StringComparer.OrdinalIgnoreCase);
            dynamic components = project.VBComponents;
            int componentCount = 0;
            try { componentCount = components.Count; } catch { /* locked project */ }

            for (int ci = 1; ci <= componentCount; ci++)
            {
                dynamic codeModule;
                try { codeModule = components.Item(ci).CodeModule; }
                catch { continue; } // component without readable code: skip

                int totalLines = 0;
                try { totalLines = codeModule.CountOfLines; } catch { }
                int line = 1;
                while (line <= totalLines)
                {
                    string proc = null;
                    try { proc = codeModule.ProcOfLine[line, VbExtPkProc]; }
                    catch { /* line is not inside a procedure */ }

                    if (string.IsNullOrEmpty(proc))
                    {
                        line++;
                        continue;
                    }

                    int start = line;
                    try { start = codeModule.ProcStartLine[proc, VbExtPkProc]; }
                    catch { /* keep current line */ }

                    string declaration = null;
                    try { declaration = codeModule.Lines[start, 1]; }
                    catch { /* unknown: the name is kept (best effort) */ }

                    if (IsRunnableSub(declaration)) names.Add(proc);

                    int count = 1;
                    try { count = codeModule.ProcCountLines[proc, VbExtPkProc]; }
                    catch { /* advance one line */ }
                    line = start + Math.Max(count, 1); // always moves forward
                }
            }

            return names.ToList();
        }
        finally
        {
            try { workbook?.Close(false); } catch { }
            try { excel?.Quit(); } catch { }
            ReleaseCom(workbook);
            ReleaseCom(excel);
            if (pid > 0)
            {
                try
                {
                    using var process = Process.GetProcessById(pid);
                    if (!process.WaitForExit(3000) && !process.HasExited) process.Kill();
                }
                catch { /* already gone */ }
            }
        }
    }

    /// <summary>Best-effort filter for "a macro the operator can run":
    /// a public Sub (not a Function / Property / Private helper).
    /// An unreadable declaration keeps the name.</summary>
    private static bool IsRunnableSub(string declaration)
    {
        if (string.IsNullOrWhiteSpace(declaration)) return true;
        if (declaration.IndexOf("Private", StringComparison.OrdinalIgnoreCase) >= 0) return false;
        string padded = " " + declaration.Trim() + " ";
        if (padded.IndexOf(" Function ", StringComparison.OrdinalIgnoreCase) >= 0) return false;
        if (padded.IndexOf(" Property ", StringComparison.OrdinalIgnoreCase) >= 0) return false;
        return padded.IndexOf(" Sub ", StringComparison.OrdinalIgnoreCase) >= 0;
    }

    private static int TryGetPid(dynamic excel)
    {
        try
        {
            int hwnd = Convert.ToInt32(excel.Hwnd);
            if (hwnd != 0 && GetWindowThreadProcessId((IntPtr)hwnd, out uint pid) != 0)
                return (int)pid;
        }
        catch { }
        return 0;
    }

    private static void ReleaseCom(object comObject)
    {
        try
        {
            if (comObject != null && Marshal.IsComObject(comObject))
                Marshal.FinalReleaseComObject(comObject);
        }
        catch { }
    }
}
