namespace IutBencaseTestLauncher;

/// <summary>Run status values written to the history CSV. Keep them stable:
/// statistics group on these strings.</summary>
public static class RunStatus
{
    public const string Success = "Success";
    public const string Failed = "Failed";
    public const string TimedOut = "Timed out";
    public const string Stopped = "Stopped";
}

/// <summary>One test workbook found in the selected folder.</summary>
public sealed class TestFileItem
{
    public string FileName { get; set; } = "";
    public string FilePath { get; set; } = "";
    public string MacroName { get; set; } = "";
    public bool Selected { get; set; } = true;

    /// <summary>
    /// Derive the default macro name from the file name, following the
    /// existing naming convention: IUT_Bencase_Automation_CCB.xlsm runs
    /// Bencase_test_CCB, i.e. "Bencase_test_" + the suffix after the
    /// last underscore. Files without an underscore get an empty name
    /// (the operator fills it in once; it is then remembered).
    /// </summary>
    public static string DeriveMacroName(string fileName)
    {
        string baseName = Path.GetFileNameWithoutExtension(fileName);
        int idx = baseName.LastIndexOf('_');
        if (idx < 0 || idx == baseName.Length - 1) return "";
        return "Bencase_test_" + baseName.Substring(idx + 1);
    }
}

/// <summary>One finished run, as stored in run-history.csv.</summary>
public sealed class RunRecord
{
    public DateTime Start { get; set; }
    public DateTime End { get; set; }
    public string FileName { get; set; } = "";
    public string Macro { get; set; } = "";
    public string Status { get; set; } = "";
    public double DurationSec { get; set; }
    public string Message { get; set; } = "";
}

/// <summary>Aggregated statistics for one test file.</summary>
public sealed class FileStats
{
    public string FileName { get; set; } = "";
    public int Runs { get; set; }
    public int Successes { get; set; }
    public int Failures { get; set; }
    public int Timeouts { get; set; }
    public double SuccessRatePercent => Runs == 0 ? 0 : 100.0 * Successes / Runs;
    public double AverageDurationSec { get; set; }
    public DateTime? LastRun { get; set; }
    public string LastStatus { get; set; } = "";
}

/// <summary>Persisted app settings (launcher-settings.json next to the exe).</summary>
public sealed class AppSettings
{
    public string FolderPath { get; set; } = "";
    public bool SaveAfterRun { get; set; } = true;
    public bool ShowExcelWindow { get; set; } = false;
    public int TimeoutMinutes { get; set; } = 180;

    /// <summary>Macro name per file name, when edited by the operator.</summary>
    public Dictionary<string, string> MacroByFile { get; set; } = new();

    /// <summary>Checkbox state per file name.</summary>
    public Dictionary<string, bool> SelectedByFile { get; set; } = new();
}
