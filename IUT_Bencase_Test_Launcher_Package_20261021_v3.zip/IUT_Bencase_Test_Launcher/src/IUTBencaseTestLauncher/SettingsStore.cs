using System.Text.Json;

namespace IutBencaseTestLauncher;

/// <summary>Loads/saves launcher-settings.json in the app folder.
/// A broken or missing file falls back to defaults instead of crashing.</summary>
public static class SettingsStore
{
    public static string SettingsPath =>
        Path.Combine(AppContext.BaseDirectory, "launcher-settings.json");

    public static AppSettings Load()
    {
        try
        {
            if (File.Exists(SettingsPath))
            {
                string json = File.ReadAllText(SettingsPath);
                var settings = JsonSerializer.Deserialize<AppSettings>(json);
                if (settings != null) return settings;
            }
        }
        catch
        {
            // Ignore: defaults below are safe.
        }
        return new AppSettings();
    }

    public static void Save(AppSettings settings)
    {
        try
        {
            var options = new JsonSerializerOptions { WriteIndented = true };
            File.WriteAllText(SettingsPath, JsonSerializer.Serialize(settings, options));
        }
        catch
        {
            // Settings are a convenience; never let a save failure break a run.
        }
    }
}
