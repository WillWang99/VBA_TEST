namespace IutBencaseTestLauncher;

/// <summary>
/// "History &amp; Statistics" tab: per-file statistics and the recent
/// run history, computed from run-history.csv, with a period filter and
/// CSV export for reporting.
/// </summary>
public sealed partial class MainForm
{
    private ComboBox _cmbPeriod = null!;
    private DataGridView _statsGrid = null!;
    private DataGridView _historyGrid = null!;
    private List<RunRecord> _filteredHistory = new();

    private void BuildStatsTab(TabPage page)
    {
        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 5,
            Padding = new Padding(8),
        };
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 40));  // toolbar
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 24));  // "Statistics" label
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 42));   // stats grid
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 24));  // "Run history" label
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 58));   // history grid
        page.Controls.Add(layout);

        var toolbar = new FlowLayoutPanel { Dock = DockStyle.Fill, WrapContents = false };
        toolbar.Controls.Add(new Label { Text = "Period:", AutoSize = true, Margin = new Padding(0, 7, 4, 0) });
        _cmbPeriod = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = 140 };
        _cmbPeriod.Items.AddRange(new object[] { "All time", "Last 7 days", "Last 30 days" });
        _cmbPeriod.SelectedIndex = 0;
        _cmbPeriod.SelectedIndexChanged += (_, _) => RefreshStats();
        toolbar.Controls.Add(_cmbPeriod);
        var btnRefresh = new Button { Text = "Refresh", AutoSize = true, Margin = new Padding(8, 2, 0, 0) };
        btnRefresh.Click += (_, _) => RefreshStats();
        toolbar.Controls.Add(btnRefresh);
        var btnExport = new Button { Text = "Export history to CSV...", AutoSize = true, Margin = new Padding(8, 2, 0, 0) };
        btnExport.Click += BtnExport_Click;
        toolbar.Controls.Add(btnExport);
        layout.Controls.Add(toolbar, 0, 0);

        layout.Controls.Add(new Label { Text = "Statistics per test file", AutoSize = true, Margin = new Padding(0, 4, 0, 0) }, 0, 1);

        _statsGrid = NewReadOnlyGrid();
        _statsGrid.Columns.Add(NewTextColumn("File", 240, fill: true));
        _statsGrid.Columns.Add(NewTextColumn("Runs", 60));
        _statsGrid.Columns.Add(NewTextColumn("Success", 70));
        _statsGrid.Columns.Add(NewTextColumn("Failed", 60));
        _statsGrid.Columns.Add(NewTextColumn("Timed out", 80));
        _statsGrid.Columns.Add(NewTextColumn("Success rate", 90));
        _statsGrid.Columns.Add(NewTextColumn("Avg duration", 100));
        _statsGrid.Columns.Add(NewTextColumn("Last run", 130));
        _statsGrid.Columns.Add(NewTextColumn("Last result", 90));
        layout.Controls.Add(_statsGrid, 0, 2);

        layout.Controls.Add(new Label { Text = "Run history (latest first, up to 500 shown)", AutoSize = true, Margin = new Padding(0, 4, 0, 0) }, 0, 3);

        _historyGrid = NewReadOnlyGrid();
        _historyGrid.Columns.Add(NewTextColumn("Start", 140));
        _historyGrid.Columns.Add(NewTextColumn("File", 240, fill: true));
        _historyGrid.Columns.Add(NewTextColumn("Script", 180));
        _historyGrid.Columns.Add(NewTextColumn("Status", 90));
        _historyGrid.Columns.Add(NewTextColumn("Duration", 90));
        _historyGrid.Columns.Add(NewTextColumn("Message", 320, fill: true));
        layout.Controls.Add(_historyGrid, 0, 4);
    }

    private static DataGridView NewReadOnlyGrid()
    {
        return new DataGridView
        {
            Dock = DockStyle.Fill,
            AllowUserToAddRows = false,
            AllowUserToDeleteRows = false,
            ReadOnly = true,
            RowHeadersVisible = false,
            SelectionMode = DataGridViewSelectionMode.FullRowSelect,
        };
    }

    private static DataGridViewTextBoxColumn NewTextColumn(string header, int width, bool fill = false)
    {
        return new DataGridViewTextBoxColumn
        {
            HeaderText = header,
            Width = width,
            AutoSizeMode = fill
                ? DataGridViewAutoSizeColumnMode.Fill
                : DataGridViewAutoSizeColumnMode.None,
        };
    }

    private void RefreshStats()
    {
        if (_statsGrid == null || _historyGrid == null) return;

        var all = HistoryStore.LoadAll();
        DateTime? since = _cmbPeriod.SelectedIndex switch
        {
            1 => DateTime.Now.AddDays(-7),
            2 => DateTime.Now.AddDays(-30),
            _ => null,
        };
        _filteredHistory = since.HasValue
            ? all.Where(r => r.Start >= since.Value).ToList()
            : all;

        _statsGrid.Rows.Clear();
        foreach (var s in HistoryStore.ComputeStats(_filteredHistory))
        {
            _statsGrid.Rows.Add(
                s.FileName,
                s.Runs.ToString(),
                s.Successes.ToString(),
                s.Failures.ToString(),
                s.Timeouts.ToString(),
                $"{s.SuccessRatePercent:0.0}%",
                FormatDuration(s.AverageDurationSec),
                s.LastRun?.ToString("yyyy-MM-dd HH:mm") ?? "",
                s.LastStatus);
        }

        _historyGrid.Rows.Clear();
        foreach (var r in _filteredHistory.OrderByDescending(r => r.Start).Take(500))
        {
            _historyGrid.Rows.Add(
                r.Start.ToString("yyyy-MM-dd HH:mm:ss"),
                r.FileName,
                r.Macro,
                r.Status,
                FormatDuration(r.DurationSec),
                r.Message);
        }
    }

    private void BtnExport_Click(object sender, EventArgs e)
    {
        if (_filteredHistory.Count == 0)
        {
            MessageBox.Show("There is no run history in the selected period to export.",
                "Export", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        using var dialog = new SaveFileDialog
        {
            Filter = "CSV files (*.csv)|*.csv",
            FileName = $"run-history-{DateTime.Now:yyyyMMdd}.csv",
        };
        if (dialog.ShowDialog(this) != DialogResult.OK) return;

        using var writer = new StreamWriter(dialog.FileName);
        writer.WriteLine(HistoryStore.HeaderLine);
        foreach (var r in _filteredHistory.OrderBy(r => r.Start))
            writer.WriteLine(HistoryStore.ToCsvLine(r));

        MessageBox.Show("Exported to:\n" + dialog.FileName, "Export",
            MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
}
