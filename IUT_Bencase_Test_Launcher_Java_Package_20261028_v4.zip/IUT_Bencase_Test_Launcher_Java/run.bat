@echo off
rem Start the IUT Bencase Test Launcher (Java version).
rem The lib folder must stay next to app.jar: it holds the JACOB
rem bridge (jar + Windows DLLs) used to talk to Excel.
cd /d %~dp0
java -Djava.library.path=lib -jar app.jar
if errorlevel 1 pause
