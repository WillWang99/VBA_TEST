@echo off
rem Build the IUT Bencase Test Launcher (Java version).
rem Requires a JDK 17 or newer on PATH (check: javac -version).
setlocal
cd /d %~dp0
if not exist out mkdir out
dir /s /b src\*.java > sources.txt
javac --release 17 -encoding UTF-8 -cp lib\jacob.jar -d out @sources.txt
if errorlevel 1 (
  echo.
  echo BUILD FAILED - see the errors above.
  pause
  exit /b 1
)
jar --create --file app.jar --manifest manifest.mf -C out .
del sources.txt
echo.
echo BUILD OK: app.jar created. Start the app with run.bat
