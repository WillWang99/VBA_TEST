package com.iutbencase.launcher;

/** One test workbook found in the selected folder. */
public class TestFileItem {
    public String fileName = "";
    public String filePath = "";
    public String macroName = "";
    public boolean selected = true;

    /**
     * Derive the default macro name from the file name, following the
     * existing naming convention: IUT_Bencase_Automation_CCB.xlsm runs
     * Bencase_test_CCB, i.e. "Bencase_test_" + the suffix after the
     * last underscore. Files without an underscore get an empty name
     * (the operator fills it in once; it is then remembered).
     */
    public static String deriveMacroName(String fileName) {
        String base = fileName;
        int dot = base.lastIndexOf('.');
        if (dot > 0) base = base.substring(0, dot);
        int idx = base.lastIndexOf('_');
        if (idx < 0 || idx == base.length() - 1) return "";
        return "Bencase_test_" + base.substring(idx + 1);
    }
}
