package com.iutbencase.launcher;

import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Run history stored as CSV in run-history.csv next to the app: one row
 * per finished run. Same format as the C# version, so history files can
 * be carried over. The reader is a small full CSV parser so messages
 * containing commas, quotes or line breaks survive intact.
 */
public final class HistoryStore {

    public static final String HEADER_LINE = "Start,End,File,Script,Status,DurationSec,Message";
    private static final DateTimeFormatter TIME_FORMAT =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private HistoryStore() { }

    public static void append(RunRecord record) {
        File file = AppPaths.historyFile();
        boolean writeHeader = !file.isFile() || file.length() == 0;
        try (BufferedWriter w = Files.newBufferedWriter(file.toPath(), StandardCharsets.UTF_8,
                StandardOpenOption.CREATE, StandardOpenOption.APPEND)) {
            if (writeHeader) {
                w.write(HEADER_LINE);
                w.newLine();
            }
            w.write(toCsvLine(record));
            w.newLine();
        } catch (IOException e) {
            // History is important but must never crash a run in progress;
            // the caller surfaces failures through the UI status instead.
            System.err.println("Could not write run history: " + e.getMessage());
        }
    }

    public static String toCsvLine(RunRecord r) {
        return String.join(",",
                escape(r.start.format(TIME_FORMAT)),
                escape(r.end == null ? "" : r.end.format(TIME_FORMAT)),
                escape(r.fileName),
                escape(r.macro),
                escape(r.status),
                String.format(Locale.ROOT, "%.1f", r.durationSec),
                escape(r.message));
    }

    public static String escape(String value) {
        if (value == null) value = "";
        return "\"" + value.replace("\"", "\"\"") + "\"";
    }

    public static List<RunRecord> loadAll() {
        List<RunRecord> records = new ArrayList<>();
        File file = AppPaths.historyFile();
        if (!file.isFile()) return records;

        String text;
        try {
            text = Files.readString(file.toPath(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            return records;
        }

        for (List<String> fields : parseCsv(text)) {
            if (fields.size() < 7) continue;
            if (fields.get(0).equals("Start")) continue; // header
            LocalDateTime start = parseTime(fields.get(0));
            if (start == null) continue;
            RunRecord r = new RunRecord();
            r.start = start;
            r.end = parseTime(fields.get(1));
            r.fileName = fields.get(2);
            r.macro = fields.get(3);
            r.status = fields.get(4);
            try {
                r.durationSec = Double.parseDouble(fields.get(5));
            } catch (NumberFormatException e) {
                r.durationSec = 0;
            }
            r.message = fields.get(6);
            records.add(r);
        }
        return records;
    }

    private static LocalDateTime parseTime(String s) {
        try {
            return LocalDateTime.parse(s, TIME_FORMAT);
        } catch (Exception e) {
            return null;
        }
    }

    /** Per-file aggregates over the given records. */
    public static List<FileStats> computeStats(List<RunRecord> records) {
        Map<String, List<RunRecord>> byFile = new LinkedHashMap<>();
        for (RunRecord r : records) {
            byFile.computeIfAbsent(r.fileName, k -> new ArrayList<>()).add(r);
        }
        List<FileStats> result = new ArrayList<>();
        for (Map.Entry<String, List<RunRecord>> e : byFile.entrySet()) {
            List<RunRecord> list = e.getValue();
            list.sort((a, b) -> a.start.compareTo(b.start));
            FileStats s = new FileStats();
            s.fileName = e.getKey();
            s.runs = list.size();
            double totalDuration = 0;
            for (RunRecord r : list) {
                if (RunStatus.SUCCESS.equals(r.status)) s.successes++;
                else if (RunStatus.FAILED.equals(r.status)) s.failures++;
                else if (RunStatus.TIMED_OUT.equals(r.status)) s.timeouts++;
                totalDuration += r.durationSec;
            }
            s.averageDurationSec = list.isEmpty() ? 0 : totalDuration / list.size();
            if (!list.isEmpty()) {
                RunRecord last = list.get(list.size() - 1);
                s.lastRun = last.start;
                s.lastStatus = last.status;
            }
            result.add(s);
        }
        result.sort((a, b) -> a.fileName.compareToIgnoreCase(b.fileName));
        return result;
    }

    /** Minimal RFC-4180-style CSV parser (quotes, "" escapes, commas
     *  and newlines inside quoted fields). */
    static List<List<String>> parseCsv(String text) {
        List<List<String>> rows = new ArrayList<>();
        StringBuilder field = new StringBuilder();
        List<String> row = new ArrayList<>();
        boolean inQuotes = false;

        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (inQuotes) {
                if (c == '"') {
                    if (i + 1 < text.length() && text.charAt(i + 1) == '"') {
                        field.append('"');
                        i++;
                    } else {
                        inQuotes = false;
                    }
                } else {
                    field.append(c);
                }
            } else if (c == '"') {
                inQuotes = true;
            } else if (c == ',') {
                row.add(field.toString());
                field.setLength(0);
            } else if (c == '\r' || c == '\n') {
                if (c == '\r' && i + 1 < text.length() && text.charAt(i + 1) == '\n') i++;
                row.add(field.toString());
                field.setLength(0);
                if (row.size() > 1 || !row.get(0).isEmpty()) rows.add(row);
                row = new ArrayList<>();
            } else {
                field.append(c);
            }
        }
        if (field.length() > 0 || !row.isEmpty()) {
            row.add(field.toString());
            rows.add(row);
        }
        return rows;
    }
}
