package com.iutbencase.launcher;

import java.io.File;
import java.net.URISyntaxException;

/** Locations of the app's data files: next to the jar (or classes dir
 *  when running unpacked in development), like the C# version keeps
 *  them next to the exe. */
public final class AppPaths {

    public static File baseDir() {
        try {
            File loc = new File(Main.class.getProtectionDomain()
                    .getCodeSource().getLocation().toURI());
            return loc.isDirectory() ? loc : loc.getParentFile();
        } catch (URISyntaxException | NullPointerException e) {
            return new File(".").getAbsoluteFile();
        }
    }

    public static File settingsFile() {
        return new File(baseDir(), "launcher-settings.json");
    }

    public static File historyFile() {
        return new File(baseDir(), "run-history.csv");
    }

    private AppPaths() { }
}
