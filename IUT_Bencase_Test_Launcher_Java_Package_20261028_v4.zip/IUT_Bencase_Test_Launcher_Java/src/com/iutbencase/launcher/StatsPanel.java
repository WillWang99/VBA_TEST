package com.iutbencase.launcher;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * "History &amp; Statistics" tab: per-file statistics and the recent
 * run history, computed from run-history.csv, with a period filter and
 * CSV export for reporting. Mirrors the C# version.
 */
public class StatsPanel extends JPanel {

    private final JComboBox<String> periodCombo;
    private final DefaultTableModel statsModel;
    private final DefaultTableModel historyModel;
    private List<RunRecord> filteredHistory = new ArrayList<>();

    public StatsPanel() {
        super(new BorderLayout(0, 6));
        setBorder(javax.swing.BorderFactory.createEmptyBorder(8, 8, 8, 8));

        JPanel toolbar = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 2));
        toolbar.add(new JLabel("Period:"));
        periodCombo = new JComboBox<>(new String[] {"All time", "Last 7 days", "Last 30 days"});
        periodCombo.addActionListener(e -> refresh());
        toolbar.add(periodCombo);
        JButton refreshButton = new JButton("Refresh");
        refreshButton.addActionListener(e -> refresh());
        toolbar.add(refreshButton);
        JButton exportButton = new JButton("Export history to CSV...");
        exportButton.addActionListener(e -> exportCsv());
        toolbar.add(exportButton);
        add(toolbar, BorderLayout.NORTH);

        JPanel tables = new JPanel(new GridLayout(2, 1, 0, 8));

        statsModel = new DefaultTableModel(new Object[] {
                "File", "Runs", "Success", "Failed", "Timed out",
                "Success rate", "Avg duration", "Last run", "Last result"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable statsTable = new JTable(statsModel);
        statsTable.setFillsViewportHeight(true);
        JPanel statsBlock = new JPanel(new BorderLayout(0, 2));
        statsBlock.add(new JLabel("Statistics per test file"), BorderLayout.NORTH);
        statsBlock.add(new JScrollPane(statsTable), BorderLayout.CENTER);
        tables.add(statsBlock);

        historyModel = new DefaultTableModel(new Object[] {
                "Start", "File", "Script", "Status", "Duration", "Message"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable historyTable = new JTable(historyModel);
        historyTable.setFillsViewportHeight(true);
        JPanel historyBlock = new JPanel(new BorderLayout(0, 2));
        historyBlock.add(new JLabel("Run history (latest first, up to 500 shown)"), BorderLayout.NORTH);
        historyBlock.add(new JScrollPane(historyTable), BorderLayout.CENTER);
        tables.add(historyBlock);

        add(tables, BorderLayout.CENTER);
    }

    public void refresh() {
        List<RunRecord> all = HistoryStore.loadAll();
        LocalDateTime since = switch (periodCombo.getSelectedIndex()) {
            case 1 -> LocalDateTime.now().minusDays(7);
            case 2 -> LocalDateTime.now().minusDays(30);
            default -> null;
        };
        filteredHistory = new ArrayList<>();
        for (RunRecord r : all) {
            if (since == null || !r.start.isBefore(since)) filteredHistory.add(r);
        }

        statsModel.setRowCount(0);
        DateTimeFormatter lastRunFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        for (FileStats s : HistoryStore.computeStats(filteredHistory)) {
            statsModel.addRow(new Object[] {
                    s.fileName,
                    s.runs,
                    s.successes,
                    s.failures,
                    s.timeouts,
                    String.format(java.util.Locale.ROOT, "%.1f%%", s.successRatePercent()),
                    MainFrame.formatDuration(s.averageDurationSec),
                    s.lastRun == null ? "" : s.lastRun.format(lastRunFormat),
                    s.lastStatus});
        }

        historyModel.setRowCount(0);
        DateTimeFormatter startFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        List<RunRecord> newestFirst = new ArrayList<>(filteredHistory);
        newestFirst.sort((a, b) -> b.start.compareTo(a.start));
        int shown = 0;
        for (RunRecord r : newestFirst) {
            if (shown++ >= 500) break;
            historyModel.addRow(new Object[] {
                    r.start.format(startFormat),
                    r.fileName,
                    r.macro,
                    r.status,
                    MainFrame.formatDuration(r.durationSec),
                    r.message});
        }
    }

    private void exportCsv() {
        if (filteredHistory.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "There is no run history in the selected period to export.",
                    "Export", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        JFileChooser chooser = new JFileChooser();
        chooser.setSelectedFile(new File("run-history-" +
                LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd")) + ".csv"));
        if (chooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;

        List<RunRecord> chronological = new ArrayList<>(filteredHistory);
        chronological.sort((a, b) -> a.start.compareTo(b.start));
        try (PrintWriter w = new PrintWriter(chooser.getSelectedFile(), StandardCharsets.UTF_8)) {
            w.println(HistoryStore.HEADER_LINE);
            for (RunRecord r : chronological) {
                w.println(HistoryStore.toCsvLine(r));
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Export failed: " + e.getMessage(),
                    "Export", JOptionPane.ERROR_MESSAGE);
            return;
        }
        JOptionPane.showMessageDialog(this, "Exported to:\n" + chooser.getSelectedFile().getAbsolutePath(),
                "Export", JOptionPane.INFORMATION_MESSAGE);
    }
}
