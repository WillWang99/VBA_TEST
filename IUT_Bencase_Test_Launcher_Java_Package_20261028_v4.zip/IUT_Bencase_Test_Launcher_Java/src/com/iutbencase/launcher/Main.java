package com.iutbencase.launcher;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/** Entry point: IUT Bencase Test Launcher (Java/Swing version). */
public final class Main {

    private Main() { }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {
            // Fall back to the default look and feel.
        }
        SwingUtilities.invokeLater(() -> new MainFrame().setVisible(true));
    }
}
