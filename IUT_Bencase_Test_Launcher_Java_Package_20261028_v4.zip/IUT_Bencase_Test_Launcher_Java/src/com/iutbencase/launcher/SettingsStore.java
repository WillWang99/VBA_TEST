package com.iutbencase.launcher;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.LinkedHashMap;
import java.util.Map;

/** Loads/saves launcher-settings.json in the app folder.
 *  A broken or missing file falls back to defaults instead of crashing.
 *  Field names match the C# version's settings file. */
public final class SettingsStore {

    private SettingsStore() { }

    public static AppSettings load() {
        AppSettings settings = new AppSettings();
        try {
            java.io.File file = AppPaths.settingsFile();
            if (!file.isFile()) return settings;
            String json = Files.readString(file.toPath(), StandardCharsets.UTF_8);
            Object root = Json.parse(json);
            if (!(root instanceof Map<?, ?> map)) return settings;

            settings.folderPath = asString(map.get("FolderPath"), "");
            settings.saveAfterRun = asBoolean(map.get("SaveAfterRun"), true);
            settings.showExcelWindow = asBoolean(map.get("ShowExcelWindow"), false);
            settings.timeoutMinutes = asInt(map.get("TimeoutMinutes"), 180);
            settings.attachToRunningExcel = asBoolean(map.get("AttachToRunningExcel"), false);

            if (map.get("MacroByFile") instanceof Map<?, ?> macros) {
                for (Map.Entry<?, ?> e : macros.entrySet()) {
                    settings.macroByFile.put(String.valueOf(e.getKey()), asString(e.getValue(), ""));
                }
            }
            if (map.get("SelectedByFile") instanceof Map<?, ?> selected) {
                for (Map.Entry<?, ?> e : selected.entrySet()) {
                    settings.selectedByFile.put(String.valueOf(e.getKey()), asBoolean(e.getValue(), true));
                }
            }
        } catch (Exception e) {
            // Ignore: defaults are safe.
            return new AppSettings();
        }
        return settings;
    }

    public static void save(AppSettings settings) {
        try {
            Map<String, Object> root = new LinkedHashMap<>();
            root.put("FolderPath", settings.folderPath);
            root.put("SaveAfterRun", settings.saveAfterRun);
            root.put("ShowExcelWindow", settings.showExcelWindow);
            root.put("TimeoutMinutes", settings.timeoutMinutes);
            root.put("AttachToRunningExcel", settings.attachToRunningExcel);
            root.put("MacroByFile", new LinkedHashMap<>(settings.macroByFile));
            root.put("SelectedByFile", new LinkedHashMap<>(settings.selectedByFile));
            Files.writeString(AppPaths.settingsFile().toPath(),
                    Json.write(root), StandardCharsets.UTF_8);
        } catch (IOException e) {
            // Settings are a convenience; never let a save failure break a run.
        }
    }

    private static String asString(Object v, String fallback) {
        return v == null ? fallback : String.valueOf(v);
    }

    private static boolean asBoolean(Object v, boolean fallback) {
        return v instanceof Boolean b ? b : fallback;
    }

    private static int asInt(Object v, int fallback) {
        return v instanceof Number n ? n.intValue() : fallback;
    }
}
