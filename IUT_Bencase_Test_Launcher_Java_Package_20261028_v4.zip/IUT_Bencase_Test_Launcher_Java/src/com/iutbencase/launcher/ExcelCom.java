package com.iutbencase.launcher;

import java.time.Instant;
import java.util.HashSet;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;

/**
 * Process bookkeeping for the Excel instances this app starts.
 * A fresh Excel.Application COM activation starts a new EXCEL.EXE
 * process; diffing the process list before/after identifies exactly
 * the process we own (never the operator's own Excel windows), so a
 * timeout or Stop can kill precisely that one.
 */
final class ExcelCom {

    private ExcelCom() { }

    static Set<Long> excelPids() {
        Set<Long> pids = new HashSet<>();
        ProcessHandle.allProcesses().forEach(ph -> {
            String cmd = ph.info().command().orElse("");
            String c = cmd.toUpperCase(Locale.ROOT);
            if (c.equals("EXCEL.EXE") || c.endsWith("\\EXCEL.EXE") || c.endsWith("/EXCEL.EXE")) {
                pids.add(ph.pid());
            }
        });
        return pids;
    }

    /** The newest EXCEL.EXE pid that was not in {@code before}, or -1. */
    static long newestNewPid(Set<Long> before) {
        Set<Long> now = excelPids();
        now.removeAll(before);
        long best = -1;
        Instant bestStart = Instant.MIN;
        for (long pid : now) {
            if (best == -1) best = pid;
            Optional<Instant> start = ProcessHandle.of(pid)
                    .flatMap(ph -> ph.info().startInstant());
            if (start.isPresent() && start.get().isAfter(bestStart)) {
                bestStart = start.get();
                best = pid;
            }
        }
        return best;
    }

    static void killPid(long pid) {
        if (pid <= 0) return;
        try {
            ProcessHandle.of(pid).ifPresent(ProcessHandle::destroyForcibly);
        } catch (Exception ignored) {
            // Already gone, or no permission: nothing more to do.
        }
    }

    /** Wait briefly for the process to exit after Quit; force it after. */
    static void ensureGone(long pid, long timeoutMillis) {
        if (pid <= 0) return;
        long deadline = System.currentTimeMillis() + timeoutMillis;
        while (System.currentTimeMillis() < deadline) {
            Optional<ProcessHandle> ph = ProcessHandle.of(pid);
            if (ph.isEmpty() || !ph.get().isAlive()) return;
            try {
                Thread.sleep(200);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }
        }
        killPid(pid);
    }
}
