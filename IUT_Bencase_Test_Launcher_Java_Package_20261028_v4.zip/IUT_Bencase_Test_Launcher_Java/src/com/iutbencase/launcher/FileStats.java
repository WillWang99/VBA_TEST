package com.iutbencase.launcher;

import java.time.LocalDateTime;

/** Aggregated statistics for one test file. */
public class FileStats {
    public String fileName = "";
    public int runs;
    public int successes;
    public int failures;
    public int timeouts;
    public double averageDurationSec;
    public LocalDateTime lastRun;
    public String lastStatus = "";

    public double successRatePercent() {
        return runs == 0 ? 0 : 100.0 * successes / runs;
    }
}
