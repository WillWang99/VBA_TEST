package com.iutbencase.launcher;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SpinnerDateModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.event.TableModelEvent;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Main window, "Run tests" tab: pick a folder, the app lists every
 * .xlsm test file in it, check the ones to run, Run Selected / Run All,
 * plus a one-time scheduled run and a Scan that reads the real macro
 * names out of each file — the same workflow as the C# version.
 * The "History &amp; Statistics" tab is {@link StatsPanel}.
 */
public class MainFrame extends JFrame {

    private static final int COL_RUN = 0;
    private static final int COL_FILE = 1;
    private static final int COL_MACRO = 2;
    private static final int COL_LAST_RESULT = 3;
    private static final int COL_LAST_DURATION = 4;

    private final AppSettings settings;
    private final ExcelRunner runner = new ExcelRunner();
    private final List<TestFileItem> items = new ArrayList<>();

    private volatile boolean running;
    private volatile boolean stopQueue;
    private volatile boolean scanning;
    private volatile boolean currentRunScheduled;
    private boolean loading; // true while the table is being filled
    private volatile LocalDateTime scheduledAt;
    private volatile String currentItemName = "";
    private volatile long currentItemStartMillis;

    private final JTextField folderField = new JTextField(52);
    private final DefaultTableModel tableModel;
    private final JTable table;
    private final JCheckBox saveCheck = new JCheckBox("Save file after a successful run");
    private final JCheckBox showCheck = new JCheckBox("Show Excel window while running");
    private final JCheckBox attachCheck = new JCheckBox("Use already-open Excel (I enable macros myself)");
    private final JSpinner timeoutSpinner = new JSpinner(new SpinnerNumberModel(180, 1, 1440, 1));
    private final JButton runSelectedButton = new JButton("Run Selected");
    private final JButton runAllButton = new JButton("Run All");
    private final JButton stopButton = new JButton("Stop");
    private final JButton startScheduleButton = new JButton("Start Schedule");
    private final JButton stopScheduleButton = new JButton("Stop Schedule");
    private final JSpinner scheduleSpinner;
    private final JLabel scheduleStatusLabel = new JLabel("Schedule is OFF");
    private final JLabel statusLabel = new JLabel("Ready");
    private final JLabel elapsedLabel = new JLabel("");
    private final StatsPanel statsPanel = new StatsPanel();

    public MainFrame() {
        super("IUT Bencase Test Launcher");
        settings = SettingsStore.load();

        // ---- Run tab ----
        JPanel runTab = new JPanel(new BorderLayout(0, 6));
        runTab.setBorder(javax.swing.BorderFactory.createEmptyBorder(8, 8, 8, 8));

        JPanel folderPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 2));
        folderPanel.add(new JLabel("Test files folder:"));
        folderPanel.add(folderField);
        JButton browseButton = new JButton("Browse...");
        browseButton.addActionListener(e -> browseFolder());
        folderPanel.add(browseButton);
        JButton refreshButton = new JButton("Refresh list");
        refreshButton.addActionListener(e -> {
            saveGeneralSettings();
            refreshFileList(false);
        });
        folderPanel.add(refreshButton);
        JButton allButton = new JButton("Select all");
        allButton.addActionListener(e -> setAllSelected(true));
        folderPanel.add(allButton);
        JButton noneButton = new JButton("Select none");
        noneButton.addActionListener(e -> setAllSelected(false));
        folderPanel.add(noneButton);
        JButton scanButton = new JButton("Scan scripts");
        scanButton.addActionListener(e -> startScan());
        folderPanel.add(scanButton);
        runTab.add(folderPanel, BorderLayout.NORTH);

        tableModel = new DefaultTableModel(
                new Object[] {"Run", "Test file", "Script to run", "Last result", "Last duration"}, 0) {
            @Override public Class<?> getColumnClass(int column) {
                return column == COL_RUN ? Boolean.class : String.class;
            }
            @Override public boolean isCellEditable(int row, int column) {
                return column == COL_RUN || column == COL_MACRO;
            }
        };
        table = new JTable(tableModel);
        table.setFillsViewportHeight(true);
        table.getColumnModel().getColumn(COL_RUN).setPreferredWidth(45);
        table.getColumnModel().getColumn(COL_FILE).setPreferredWidth(560);
        table.getColumnModel().getColumn(COL_MACRO).setPreferredWidth(250);
        table.getColumnModel().getColumn(COL_LAST_RESULT).setPreferredWidth(110);
        table.getColumnModel().getColumn(COL_LAST_DURATION).setPreferredWidth(110);
        tableModel.addTableModelListener(e -> {
            if (loading || e.getType() != TableModelEvent.UPDATE) return;
            int row = e.getFirstRow();
            int col = e.getColumn();
            if (row >= 0 && (col == COL_RUN || col == COL_MACRO)) syncRowToSettings(row);
        });
        runTab.add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel southPanel = new JPanel(new GridLayout(2, 1, 0, 2));

        JPanel optionsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 2));
        saveCheck.addItemListener(e -> saveGeneralSettings());
        optionsPanel.add(saveCheck);
        showCheck.addItemListener(e -> saveGeneralSettings());
        optionsPanel.add(showCheck);
        attachCheck.setToolTipText("<html>Attach mode: instead of starting its own Excel process, " +
                "the app runs the macro in the Excel you already have open, in a workbook " +
                "you opened and enabled yourself. Use this when macros are disabled by " +
                "default on this PC.<br>Note: in attach mode the app never closes or kills " +
                "your Excel, so timeout auto-kill does not apply — if a test blocks on a " +
                "dialog, dismiss it in Excel yourself, and Stop only stops the queue " +
                "between tests.</html>");
        attachCheck.addItemListener(e -> saveGeneralSettings());
        optionsPanel.add(attachCheck);
        optionsPanel.add(new JLabel("Max minutes per test:"));
        timeoutSpinner.addChangeListener(e -> saveGeneralSettings());
        optionsPanel.add(timeoutSpinner);
        runSelectedButton.addActionListener(e -> startRun(selectedItems(), false));
        optionsPanel.add(runSelectedButton);
        runAllButton.addActionListener(e -> startRun(new ArrayList<>(items), false));
        optionsPanel.add(runAllButton);
        stopButton.setEnabled(false);
        stopButton.addActionListener(e -> {
            stopQueue = true;
            runner.requestStop();
            statusLabel.setText("Stopping...");
        });
        optionsPanel.add(stopButton);
        southPanel.add(optionsPanel);

        JPanel schedulePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 2));
        schedulePanel.add(new JLabel("Run once at:"));
        scheduleSpinner = new JSpinner(new SpinnerDateModel());
        scheduleSpinner.setEditor(new JSpinner.DateEditor(scheduleSpinner, "yyyy-MM-dd HH:mm"));
        Calendar tomorrow = Calendar.getInstance();
        tomorrow.add(Calendar.DAY_OF_MONTH, 1);
        tomorrow.set(Calendar.HOUR_OF_DAY, 9);
        tomorrow.set(Calendar.MINUTE, 0);
        tomorrow.set(Calendar.SECOND, 0);
        tomorrow.set(Calendar.MILLISECOND, 0);
        scheduleSpinner.setValue(tomorrow.getTime());
        schedulePanel.add(scheduleSpinner);
        startScheduleButton.addActionListener(e -> startSchedule());
        schedulePanel.add(startScheduleButton);
        stopScheduleButton.addActionListener(e -> {
            if (scheduledAt != null) {
                scheduledAt = null;
                scheduleStatusLabel.setText("Schedule is OFF");
                JOptionPane.showMessageDialog(this,
                        "Schedule cancelled. No run is pending.",
                        "Scheduled Run", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        schedulePanel.add(stopScheduleButton);
        schedulePanel.add(scheduleStatusLabel);
        southPanel.add(schedulePanel);

        runTab.add(southPanel, BorderLayout.SOUTH);

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Run tests", runTab);
        tabs.addTab("History & Statistics", statsPanel);
        add(tabs, BorderLayout.CENTER);

        JPanel statusBar = new JPanel(new BorderLayout());
        statusBar.setBorder(javax.swing.BorderFactory.createEmptyBorder(2, 8, 4, 8));
        statusBar.add(statusLabel, BorderLayout.CENTER);
        statusBar.add(elapsedLabel, BorderLayout.EAST);
        add(statusBar, BorderLayout.SOUTH);

        setSize(1140, 740);
        setMinimumSize(new java.awt.Dimension(920, 600));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) {
                onWindowClosing();
            }
        });

        loadSettingsIntoControls();

        Timer uiTimer = new Timer(1000, e -> onUiTick());
        uiTimer.start();

        refreshFileList(true);
        statsPanel.refresh();
    }

    // ------------------------------------------------------------------
    // Settings and file list
    // ------------------------------------------------------------------
    private void loadSettingsIntoControls() {
        folderField.setText(settings.folderPath == null || settings.folderPath.isBlank()
                ? AppPaths.baseDir().getAbsolutePath()
                : settings.folderPath);
        saveCheck.setSelected(settings.saveAfterRun);
        showCheck.setSelected(settings.showExcelWindow);
        attachCheck.setSelected(settings.attachToRunningExcel);
        timeoutSpinner.setValue(Math.max(1, Math.min(1440, settings.timeoutMinutes)));
    }

    private void saveGeneralSettings() {
        settings.folderPath = folderField.getText().trim();
        settings.saveAfterRun = saveCheck.isSelected();
        settings.showExcelWindow = showCheck.isSelected();
        settings.attachToRunningExcel = attachCheck.isSelected();
        settings.timeoutMinutes = ((Number) timeoutSpinner.getValue()).intValue();
        SettingsStore.save(settings);
    }

    private void refreshFileList(boolean initial) {
        String folder = folderField.getText().trim();
        items.clear();
        loading = true;
        tableModel.setRowCount(0);
        loading = false;

        File dir = folder.isEmpty() ? null : new File(folder);
        if (dir == null || !dir.isDirectory()) {
            if (!initial) {
                JOptionPane.showMessageDialog(this,
                        "The folder does not exist. Please choose the folder that " +
                        "contains the test .xlsm files.",
                        "Folder Not Found", JOptionPane.WARNING_MESSAGE);
            }
            statusLabel.setText("Folder not found: " + folder);
            return;
        }

        Map<String, RunRecord> lastByFile = new HashMap<>();
        for (RunRecord r : HistoryStore.loadAll()) {
            RunRecord prev = lastByFile.get(r.fileName.toLowerCase(Locale.ROOT));
            if (prev == null || r.start.isAfter(prev.start)) {
                lastByFile.put(r.fileName.toLowerCase(Locale.ROOT), r);
            }
        }

        File[] files = dir.listFiles((d, name) -> {
            String lower = name.toLowerCase(Locale.ROOT);
            // Skip Excel owner/lock files (~$<name>.xlsm): they appear
            // while a workbook is open and are not real test files.
            return lower.endsWith(".xlsm") && !name.startsWith("~$");
        });
        if (files == null) files = new File[0];
        Arrays.sort(files, Comparator.comparing(File::getName, String.CASE_INSENSITIVE_ORDER));

        // While filling the table, setting cell values fires model
        // events; the loading flag stops the listener from syncing
        // half-filled rows back into the settings (the bug that
        // blanked the script names in the C# v1.0).
        loading = true;
        for (File f : files) {
            String name = f.getName();
            TestFileItem item = new TestFileItem();
            item.fileName = name;
            item.filePath = f.getAbsolutePath();
            String storedMacro = settings.macroByFile.get(name);
            // An empty stored value counts as "not set" and is healed
            // by re-deriving from the file name.
            item.macroName = storedMacro != null && !storedMacro.isBlank()
                    ? storedMacro
                    : TestFileItem.deriveMacroName(name);
            Boolean storedSelected = settings.selectedByFile.get(name);
            item.selected = storedSelected == null || storedSelected;
            items.add(item);

            RunRecord last = lastByFile.get(name.toLowerCase(Locale.ROOT));
            tableModel.addRow(new Object[] {
                    item.selected,
                    item.fileName,
                    item.macroName,
                    last == null ? "" : last.status,
                    last == null ? "" : formatDuration(last.durationSec)});
        }
        loading = false;

        statusLabel.setText(items.isEmpty()
                ? "No .xlsm test files found in this folder."
                : "Found " + items.size() + " test file(s). Check the ones to run, then Run Selected.");
    }

    private void syncRowToSettings(int row) {
        if (row < 0 || row >= items.size()) return;
        TestFileItem item = items.get(row);
        Object runValue = tableModel.getValueAt(row, COL_RUN);
        item.selected = Boolean.TRUE.equals(runValue);
        Object macroValue = tableModel.getValueAt(row, COL_MACRO);
        item.macroName = macroValue == null ? "" : macroValue.toString().trim();
        settings.selectedByFile.put(item.fileName, item.selected);
        settings.macroByFile.put(item.fileName, item.macroName);
        SettingsStore.save(settings);
    }

    private void setAllSelected(boolean selected) {
        loading = true;
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            tableModel.setValueAt(selected, i, COL_RUN);
        }
        loading = false;
        for (int i = 0; i < items.size(); i++) syncRowToSettings(i);
    }

    private List<TestFileItem> selectedItems() {
        List<TestFileItem> result = new ArrayList<>();
        for (TestFileItem item : items) {
            if (item.selected) result.add(item);
        }
        return result;
    }

    private void browseFolder() {
        JFileChooser chooser = new JFileChooser();
        chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        chooser.setDialogTitle("Choose the folder that contains the test .xlsm files");
        File current = new File(folderField.getText().trim());
        if (current.isDirectory()) chooser.setCurrentDirectory(current);
        if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            folderField.setText(chooser.getSelectedFile().getAbsolutePath());
            saveGeneralSettings();
            refreshFileList(false);
        }
    }

    // ------------------------------------------------------------------
    // Scanning: read the real macro list out of each file, so the
    // operator picks an existing script instead of typing (and possibly
    // mistyping) its name. Typing in the Script column still works.
    // ------------------------------------------------------------------
    private void startScan() {
        if (running || scanning) return;
        if (items.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "No test files are listed. Choose the folder first, then scan.",
                    "Scan Scripts", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        scanning = true;
        setBusyUi(true, false);
        List<String> notes = new ArrayList<>();
        Thread thread = new Thread(() -> {
            try {
                for (int i = 0; i < items.size(); i++) {
                    TestFileItem item = items.get(i);
                    int row = i;
                    SwingUtilities.invokeLater(() ->
                            statusLabel.setText("Scanning " + item.fileName + "..."));
                    List<String> macros;
                    try {
                        macros = MacroScanner.scanMacros(item.filePath);
                    } catch (Exception ex) {
                        notes.add(item.fileName + ": " + ex.getMessage());
                        continue;
                    }
                    if (macros.isEmpty()) {
                        notes.add(item.fileName + ": no runnable scripts found in this file.");
                        continue;
                    }
                    String derived = TestFileItem.deriveMacroName(item.fileName);
                    String chosen = null;
                    for (String m : macros) {
                        if (m.equalsIgnoreCase(item.macroName)) { chosen = m; break; }
                    }
                    if (chosen == null) {
                        for (String m : macros) {
                            if (m.equalsIgnoreCase(derived)) { chosen = m; break; }
                        }
                    }
                    if (chosen == null && macros.size() == 1) chosen = macros.get(0);
                    if (chosen == null) {
                        // Ambiguous: ask the operator on the UI thread.
                        AtomicReference<String> picked = new AtomicReference<>();
                        try {
                            SwingUtilities.invokeAndWait(() ->
                                    picked.set(chooseMacro(item.fileName, macros, item.macroName)));
                        } catch (Exception ignored) { }
                        chosen = picked.get();
                    }
                    if (chosen != null) {
                        String finalChosen = chosen;
                        SwingUtilities.invokeLater(() -> {
                            item.macroName = finalChosen;
                            loading = true;
                            tableModel.setValueAt(finalChosen, row, COL_MACRO);
                            loading = false;
                            syncRowToSettings(row);
                        });
                    } else {
                        notes.add(item.fileName + ": found " + macros.size() + " scripts (" +
                                String.join(", ", macros) + "). Run Scan again to pick one, " +
                                "or type the name in the Script column.");
                    }
                }
            } finally {
                SwingUtilities.invokeLater(() -> {
                    scanning = false;
                    setBusyUi(false, false);
                    statusLabel.setText("Scan finished.");
                    if (!notes.isEmpty()) {
                        JOptionPane.showMessageDialog(this, String.join("\n\n", notes),
                                "Scan Scripts", JOptionPane.INFORMATION_MESSAGE);
                    }
                });
            }
        }, "scan-thread");
        thread.setDaemon(true);
        thread.start();
    }

    /** Small chooser shown when a file holds several scripts and none
     *  matches the current/default name. Returns null on Skip.
     *  Must be called on the event dispatch thread. */
    private String chooseMacro(String fileName, List<String> macros, String current) {
        JDialog dialog = new JDialog(this, "Choose script", true);
        dialog.setSize(430, 330);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout(0, 6));

        JLabel label = new JLabel("<html>" + fileName + " contains " + macros.size() +
                " scripts.<br>Choose the one this launcher should run:</html>");
        label.setBorder(javax.swing.BorderFactory.createEmptyBorder(8, 8, 0, 8));
        dialog.add(label, BorderLayout.NORTH);

        JList<String> list = new JList<>(macros.toArray(new String[0]));
        String preselect = macros.get(0);
        for (String m : macros) {
            if (m.equalsIgnoreCase(current)) { preselect = m; break; }
        }
        list.setSelectedValue(preselect, true);
        dialog.add(new JScrollPane(list), BorderLayout.CENTER);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 6));
        JButton okButton = new JButton("Use selected");
        JButton skipButton = new JButton("Skip");
        AtomicReference<String> result = new AtomicReference<>();
        okButton.addActionListener(e -> {
            result.set(list.getSelectedValue());
            dialog.dispose();
        });
        skipButton.addActionListener(e -> dialog.dispose());
        list.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override public void mouseClicked(java.awt.event.MouseEvent e) {
                if (e.getClickCount() == 2) {
                    result.set(list.getSelectedValue());
                    dialog.dispose();
                }
            }
        });
        buttons.add(okButton);
        buttons.add(skipButton);
        dialog.add(buttons, BorderLayout.SOUTH);

        dialog.setVisible(true);
        return result.get();
    }

    // ------------------------------------------------------------------
    // Running
    // ------------------------------------------------------------------
    private void startRun(List<TestFileItem> toRun, boolean silent) {
        if (running) return;
        if (toRun.isEmpty()) {
            if (!silent) {
                JOptionPane.showMessageDialog(this,
                        "Nothing to run. Check at least one test file in the list.",
                        "Run", JOptionPane.INFORMATION_MESSAGE);
            }
            if (currentRunScheduled) {
                scheduleStatusLabel.setText("Done: no test was selected. Schedule is OFF");
                currentRunScheduled = false;
            }
            return;
        }
        for (int i = 0; i < items.size(); i++) syncRowToSettings(i);
        saveGeneralSettings();

        running = true;
        stopQueue = false;
        setBusyUi(true, true);
        Thread thread = new Thread(() -> {
            int ok = 0, failed = 0, timedOut = 0, stopped = 0;
            try {
                for (TestFileItem item : toRun) {
                    if (stopQueue) break;
                    currentItemName = item.fileName;
                    currentItemStartMillis = System.currentTimeMillis();
                    int row = items.indexOf(item);
                    SwingUtilities.invokeLater(() -> {
                        setRowResult(row, "Running...", "");
                        statusLabel.setText("Running " + item.fileName +
                                " (script " + item.macroName + ")...");
                    });

                    RunRecord record = settings.attachToRunningExcel
                            ? runner.runAttached(item, settings)
                            : runner.runOne(item, settings);

                    HistoryStore.append(record);
                    SwingUtilities.invokeLater(() ->
                            setRowResult(row, record.status, formatDuration(record.durationSec)));
                    switch (record.status) {
                        case RunStatus.SUCCESS -> ok++;
                        case RunStatus.TIMED_OUT -> timedOut++;
                        case RunStatus.STOPPED -> stopped++;
                        default -> failed++;
                    }
                    if (runner.isStopRequested()) stopQueue = true;
                }
            } finally {
                int fOk = ok, fFailed = failed, fTimedOut = timedOut, fStopped = stopped;
                SwingUtilities.invokeLater(() -> {
                    running = false;
                    currentItemStartMillis = 0;
                    elapsedLabel.setText("");
                    setBusyUi(false, false);
                    statsPanel.refresh();
                    String summary = "Finished: " + fOk + " succeeded, " + fFailed + " failed, " +
                            fTimedOut + " timed out, " + fStopped +
                            " stopped. See History & Statistics for details.";
                    statusLabel.setText(summary);
                    if (currentRunScheduled) {
                        scheduleStatusLabel.setText("Done: ran at " +
                                LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")) +
                                ". Schedule is OFF");
                        currentRunScheduled = false;
                    }
                    if (!silent) {
                        JOptionPane.showMessageDialog(this, summary,
                                "Run Finished", JOptionPane.INFORMATION_MESSAGE);
                    }
                });
            }
        }, "run-thread");
        thread.setDaemon(true);
        thread.start();
    }

    private void setRowResult(int row, String status, String duration) {
        if (row < 0 || row >= tableModel.getRowCount()) return;
        loading = true;
        tableModel.setValueAt(status, row, COL_LAST_RESULT);
        tableModel.setValueAt(duration, row, COL_LAST_DURATION);
        loading = false;
    }

    private void setBusyUi(boolean busy, boolean enableStop) {
        runSelectedButton.setEnabled(!busy);
        runAllButton.setEnabled(!busy);
        startScheduleButton.setEnabled(!busy);
        stopButton.setEnabled(busy && enableStop);
        table.setEnabled(!busy);
        folderField.setEnabled(!busy);
    }

    static String formatDuration(double seconds) {
        if (seconds < 60) return String.format(Locale.ROOT, "%.1f s", seconds);
        long total = Math.round(seconds);
        return (total / 60) + " min " + String.format(Locale.ROOT, "%02d", total % 60) + " s";
    }

    // ------------------------------------------------------------------
    // Scheduling (one-time) and the 1-second UI timer
    // ------------------------------------------------------------------
    private void startSchedule() {
        if (running) {
            JOptionPane.showMessageDialog(this,
                    "A run is in progress. Please wait for it to finish.",
                    "Scheduled Run", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        Date value = (Date) scheduleSpinner.getValue();
        LocalDateTime target = LocalDateTime.ofInstant(value.toInstant(), ZoneId.systemDefault())
                .withSecond(0).withNano(0);
        if (!target.isAfter(LocalDateTime.now())) {
            JOptionPane.showMessageDialog(this,
                    "The scheduled time is in the past. Please choose a future date and time.",
                    "Scheduled Run", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (selectedItems().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "No test file is checked. Check the files to run first.",
                    "Scheduled Run", JOptionPane.WARNING_MESSAGE);
            return;
        }
        scheduledAt = target;
        scheduleStatusLabel.setText("Pending: runs once at " +
                target.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")));
        JOptionPane.showMessageDialog(this,
                "Scheduled. The app will run the checked tests once at " +
                target.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")) +
                ".\n\nKeep this app open until then. Click [Stop Schedule] to cancel.",
                "Scheduled Run", JOptionPane.INFORMATION_MESSAGE);
    }

    private void onUiTick() {
        if (running && currentItemStartMillis > 0) {
            long elapsedSec = (System.currentTimeMillis() - currentItemStartMillis) / 1000;
            elapsedLabel.setText(currentItemName + " elapsed " +
                    (elapsedSec / 60) + ":" + String.format(Locale.ROOT, "%02d", elapsedSec % 60));
        }
        if (scheduledAt != null && !running && !scanning &&
                !LocalDateTime.now().isBefore(scheduledAt)) {
            scheduledAt = null;
            currentRunScheduled = true;
            scheduleStatusLabel.setText("Running (scheduled run)...");
            startRun(selectedItems(), true);
        }
    }

    private void onWindowClosing() {
        if (running) {
            int answer = JOptionPane.showConfirmDialog(this,
                    "A test is running. Exit anyway?\nThe current test's Excel process will be closed.",
                    "Exit", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if (answer != JOptionPane.YES_OPTION) return;
            runner.requestStop();
        }
        saveGeneralSettings();
        dispose();
        System.exit(0);
    }
}
