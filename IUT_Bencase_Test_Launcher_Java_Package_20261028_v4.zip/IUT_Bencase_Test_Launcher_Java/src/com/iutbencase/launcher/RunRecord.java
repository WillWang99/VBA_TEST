package com.iutbencase.launcher;

import java.time.LocalDateTime;

/** One finished run, as stored in run-history.csv. */
public class RunRecord {
    public LocalDateTime start;
    public LocalDateTime end;
    public String fileName = "";
    public String macro = "";
    public String status = "";
    public double durationSec;
    public String message = "";
}
