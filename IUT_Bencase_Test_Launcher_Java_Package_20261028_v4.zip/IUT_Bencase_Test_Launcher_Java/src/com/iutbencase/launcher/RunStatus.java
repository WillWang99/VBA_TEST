package com.iutbencase.launcher;

/** Run status values written to the history CSV. Keep them stable:
 *  statistics group on these strings. Same values as the C# version. */
public final class RunStatus {
    public static final String SUCCESS = "Success";
    public static final String FAILED = "Failed";
    public static final String TIMED_OUT = "Timed out";
    public static final String STOPPED = "Stopped";

    private RunStatus() { }
}
