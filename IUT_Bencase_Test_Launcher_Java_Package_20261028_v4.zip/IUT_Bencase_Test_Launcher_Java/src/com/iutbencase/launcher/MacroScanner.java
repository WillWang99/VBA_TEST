package com.iutbencase.launcher;

import com.jacob.activeX.ActiveXComponent;
import com.jacob.com.ComException;
import com.jacob.com.ComThread;
import com.jacob.com.Dispatch;
import com.jacob.com.Variant;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

/**
 * Reads the list of runnable macros (public Subs) stored inside a
 * workbook, by walking its VBA project through Excel automation —
 * the same job the "Scan" buttons did in the Excel launcher.
 *
 * Reading the VBA project requires Excel's "Trust access to the VBA
 * project object model" setting (Excel &gt; Options &gt; Trust Center
 * &gt; Trust Center Settings &gt; Macro Settings). When it is off, this
 * throws an IllegalStateException explaining that; typing the script
 * name manually always works as a fallback.
 */
public final class MacroScanner {

    private static final int VB_EXT_PK_PROC = 0; // vbext_proctype.vbext_pk_Proc

    private MacroScanner() { }

    public static List<String> scanMacros(String filePath) {
        ActiveXComponent excel = null;
        Dispatch workbook = null;
        long pid = -1;
        int previousAutomationSecurity = 1; // msoAutomationSecurityLow

        try {
            ComThread.InitSTA();
            Set<Long> before = ExcelCom.excelPids();
            try {
                excel = new ActiveXComponent("Excel.Application");
            } catch (ComException e) {
                throw new IllegalStateException(
                        "Microsoft Excel could not be started on this computer " +
                        "(it may not be installed).");
            }
            pid = ExcelCom.newestNewPid(before);

            Dispatch.put(excel, "Visible", false);
            Dispatch.put(excel, "DisplayAlerts", false);
            Dispatch.put(excel, "AskToUpdateLinks", false);
            Dispatch.put(excel, "EnableEvents", false);

            // Scanning only READS the macro list; it never runs code.
            // Force macros off for this Excel instance so opening each
            // file does not stop on Excel's "enable macros" prompt,
            // which otherwise appears once per file on PCs whose macro
            // setting is "disable all macros with notification".
            try {
                previousAutomationSecurity = Dispatch.get(excel, "AutomationSecurity").getInt();
            } catch (Exception ignored) { }
            try {
                Dispatch.put(excel, "AutomationSecurity", 3); // msoAutomationSecurityForceDisable
            } catch (Exception ignored) { }

            Dispatch workbooks = Dispatch.get(excel, "Workbooks").toDispatch();
            // UpdateLinks:=0, ReadOnly:=true (scanning never modifies the file)
            workbook = Dispatch.call(workbooks, "Open", filePath, 0, true).toDispatch();

            Dispatch project;
            try {
                project = Dispatch.get(workbook, "VBProject").toDispatch();
            } catch (ComException e) {
                throw new IllegalStateException(
                        "Excel blocked reading the scripts in this file. To use Scan, enable " +
                        "'Trust access to the VBA project object model' (Excel > Options > " +
                        "Trust Center > Trust Center Settings > Macro Settings), or type the " +
                        "script name manually.");
            }

            Set<String> names = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
            Dispatch components = Dispatch.get(project, "VBComponents").toDispatch();
            int componentCount = 0;
            try {
                componentCount = Dispatch.get(components, "Count").getInt();
            } catch (Exception ignored) {
                // Locked project: treated as "no readable components".
            }

            for (int ci = 1; ci <= componentCount; ci++) {
                Dispatch codeModule;
                try {
                    Dispatch component = Dispatch.call(components, "Item", ci).toDispatch();
                    codeModule = Dispatch.get(component, "CodeModule").toDispatch();
                } catch (Exception e) {
                    continue; // component without readable code: skip
                }

                int totalLines = 0;
                try {
                    totalLines = Dispatch.get(codeModule, "CountOfLines").getInt();
                } catch (Exception ignored) { }

                int line = 1;
                while (line <= totalLines) {
                    String proc = null;
                    try {
                        Variant v = invokeGet(codeModule, "ProcOfLine", line, VB_EXT_PK_PROC);
                        proc = v == null ? null : v.getString();
                    } catch (Exception ignored) {
                        // Line is not inside a procedure.
                    }
                    if (proc == null || proc.isEmpty()) {
                        line++;
                        continue;
                    }

                    int start = line;
                    try {
                        start = invokeGet(codeModule, "ProcStartLine", proc, VB_EXT_PK_PROC).getInt();
                    } catch (Exception ignored) {
                        // Keep current line.
                    }

                    String declaration = null;
                    try {
                        Variant v = invokeGet(codeModule, "Lines", start, 1);
                        declaration = v == null ? null : v.getString();
                    } catch (Exception ignored) {
                        // Unknown: the name is kept (best effort).
                    }

                    if (isRunnableSub(declaration)) names.add(proc);

                    int count = 1;
                    try {
                        count = invokeGet(codeModule, "ProcCountLines", proc, VB_EXT_PK_PROC).getInt();
                    } catch (Exception ignored) {
                        // Advance one line.
                    }
                    line = start + Math.max(count, 1); // always moves forward
                }
            }

            return new ArrayList<>(names);
        } finally {
            if (workbook != null) {
                try { Dispatch.call(workbook, "Close", false); } catch (Exception ignored) { }
            }
            if (excel != null) {
                try { Dispatch.put(excel, "AutomationSecurity", previousAutomationSecurity); }
                catch (Exception ignored) { }
                try { Dispatch.call(excel, "Quit"); } catch (Exception ignored) { }
            }
            ExcelCom.ensureGone(pid, 3000);
            try { ComThread.Release(); } catch (Exception ignored) { }
        }
    }

    /** Parameterized property read (ProcOfLine, Lines, ...) — these are
     *  properties with arguments in the VBIDE object model, so they are
     *  read with an explicit Get invoke. */
    private static Variant invokeGet(Dispatch dispatch, String name, Object... args) {
        int[] argError = new int[1];
        return Dispatch.invoke(dispatch, name, Dispatch.Get, args, argError);
    }

    /** Best-effort filter for "a macro the operator can run": a public
     *  Sub (not a Function / Property / Private helper). An unreadable
     *  declaration keeps the name. */
    private static boolean isRunnableSub(String declaration) {
        if (declaration == null || declaration.isBlank()) return true;
        String lower = declaration.toLowerCase();
        if (lower.contains("private")) return false;
        String padded = " " + declaration.trim() + " ";
        if (padded.toLowerCase().contains(" function ")) return false;
        if (padded.toLowerCase().contains(" property ")) return false;
        return padded.toLowerCase().contains(" sub ");
    }
}
