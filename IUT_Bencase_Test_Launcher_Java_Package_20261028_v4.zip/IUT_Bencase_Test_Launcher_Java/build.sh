#!/usr/bin/env bash
# Build the IUT Bencase Test Launcher (Java version) on Linux/macOS.
# Requires a JDK 17 or newer (check: javac -version).
set -e
cd "$(dirname "$0")"
mkdir -p out
find src -name '*.java' > sources.txt
javac --release 17 -encoding UTF-8 -cp lib/jacob.jar -d out @sources.txt
jar --create --file app.jar --manifest manifest.mf -C out .
rm sources.txt
echo "BUILD OK: app.jar created."
