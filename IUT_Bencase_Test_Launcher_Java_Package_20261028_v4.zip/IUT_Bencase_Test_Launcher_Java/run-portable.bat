@echo off
rem Portable start script for PCs where Java cannot be installed
rem system-wide (no admin rights needed). If a folder named "jdk"
rem or "jre" sits next to this script and contains bin\java.exe,
rem that Java is used; otherwise the java on PATH is used.
rem No build step is needed either way: app.jar is ready to run
rem on any Java 17 or newer.
setlocal
cd /d %~dp0
set "JAVA_EXE=java"
if exist "%~dp0jdk\bin\java.exe" set "JAVA_EXE=%~dp0jdk\bin\java.exe"
if exist "%~dp0jre\bin\java.exe" set "JAVA_EXE=%~dp0jre\bin\java.exe"
"%JAVA_EXE%" -Djava.library.path=lib -jar app.jar
if errorlevel 1 pause
endlocal
