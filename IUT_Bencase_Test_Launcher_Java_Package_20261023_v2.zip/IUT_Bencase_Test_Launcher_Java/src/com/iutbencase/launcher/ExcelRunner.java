package com.iutbencase.launcher;

import com.jacob.activeX.ActiveXComponent;
import com.jacob.com.ComException;
import com.jacob.com.ComThread;
import com.jacob.com.Dispatch;

import java.time.LocalDateTime;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Runs one test macro in its OWN Excel process (created through the
 * JACOB COM bridge). Because the macro runs in a separate process, a
 * test that hangs or blocks on a dialog cannot freeze this app: when
 * the timeout expires (or the operator presses Stop, which calls
 * {@link #requestStop()}), the runner kills exactly that Excel
 * process. The blocked COM call then fails, and the run is recorded
 * as Timed out / Stopped. Same design as the C# version.
 */
public class ExcelRunner {

    private volatile boolean timedOut;
    private volatile boolean stopRequested;
    private volatile long excelPid = -1;

    /** Ask the currently running test (if any) to stop: its Excel
     *  process is killed and the run is recorded as Stopped. */
    public void requestStop() {
        stopRequested = true;
        ExcelCom.killPid(excelPid);
    }

    public boolean isStopRequested() {
        return stopRequested;
    }

    public RunRecord runOne(TestFileItem item, AppSettings settings) {
        RunRecord record = new RunRecord();
        record.start = LocalDateTime.now();
        record.fileName = item.fileName;
        record.macro = item.macroName;
        long startNanos = System.nanoTime();
        timedOut = false;
        stopRequested = false;
        excelPid = -1;

        ActiveXComponent excel = null;
        Dispatch workbook = null;

        ScheduledExecutorService watchdog = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "excel-watchdog");
            t.setDaemon(true);
            return t;
        });

        try {
            if (item.macroName == null || item.macroName.isBlank()) {
                throw new IllegalStateException(
                        "No script name set for this file. Enter it in the 'Script to run' column first.");
            }

            ComThread.InitSTA();
            Set<Long> before = ExcelCom.excelPids();
            try {
                excel = new ActiveXComponent("Excel.Application");
            } catch (ComException e) {
                throw new IllegalStateException(
                        "Microsoft Excel could not be started on this computer " +
                        "(it may not be installed). Details: " + trimMessage(e));
            }
            excelPid = ExcelCom.newestNewPid(before);

            if (settings.timeoutMinutes > 0) {
                watchdog.scheduleAtFixedRate(() -> {
                    double elapsedMinutes = (System.nanoTime() - startNanos) / 60_000_000_000.0;
                    if (elapsedMinutes >= settings.timeoutMinutes) {
                        timedOut = true;
                        ExcelCom.killPid(excelPid);
                    }
                }, 5, 5, TimeUnit.SECONDS);
            }

            Dispatch.put(excel, "Visible", settings.showExcelWindow);
            Dispatch.put(excel, "DisplayAlerts", false);   // no Excel prompts during the run
            Dispatch.put(excel, "AskToUpdateLinks", false);
            Dispatch.put(excel, "EnableEvents", false);   // suppress the file's Workbook_Open

            Dispatch workbooks = Dispatch.get(excel, "Workbooks").toDispatch();
            // UpdateLinks:=0, ReadOnly:=false
            workbook = Dispatch.call(workbooks, "Open", item.filePath, 0, false).toDispatch();
            Dispatch.put(excel, "EnableEvents", true);

            // Same call form as the other launchers: 'FileName.xlsm'!MacroName
            Dispatch.call(excel, "Run", "'" + item.fileName + "'!" + item.macroName);

            if (settings.saveAfterRun) {
                Dispatch.call(workbook, "Save");
            }

            record.status = RunStatus.SUCCESS;
            record.message = "Completed.";
        } catch (Exception ex) {
            if (timedOut) {
                record.status = RunStatus.TIMED_OUT;
                record.message = "Exceeded the " + settings.timeoutMinutes +
                        " minute limit and was closed (a script dialog or a hang is the usual cause).";
            } else if (stopRequested) {
                record.status = RunStatus.STOPPED;
                record.message = "Stopped by the operator.";
            } else {
                record.status = RunStatus.FAILED;
                record.message = shortError(ex);
            }
        } finally {
            watchdog.shutdownNow();
            record.end = LocalDateTime.now();
            record.durationSec = (System.nanoTime() - startNanos) / 1_000_000_000.0;
            if (workbook != null) {
                try { Dispatch.call(workbook, "Close", false); } catch (Exception ignored) { }
            }
            if (excel != null) {
                try { Dispatch.call(excel, "Quit"); } catch (Exception ignored) { }
            }
            ExcelCom.ensureGone(excelPid, 3000);
            excelPid = -1;
            try { ComThread.Release(); } catch (Exception ignored) { }
        }
        return record;
    }

    private static String shortError(Exception ex) {
        String message = trimMessage(ex);
        if (message.isEmpty()) message = ex.getClass().getSimpleName();
        return message.length() > 300 ? message.substring(0, 300) + "..." : message;
    }

    private static String trimMessage(Exception ex) {
        String message = ex.getMessage() == null ? "" : ex.getMessage().trim();
        // Keep the history cell readable: collapse line breaks.
        return message.replace('\r', ' ').replace('\n', ' ').replaceAll(" {2,}", " ");
    }
}
