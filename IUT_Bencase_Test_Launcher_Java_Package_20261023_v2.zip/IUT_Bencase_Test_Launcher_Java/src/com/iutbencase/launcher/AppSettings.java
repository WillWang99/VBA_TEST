package com.iutbencase.launcher;

import java.util.LinkedHashMap;
import java.util.Map;

/** Persisted app settings (launcher-settings.json next to the app). */
public class AppSettings {
    public String folderPath = "";
    public boolean saveAfterRun = true;
    public boolean showExcelWindow = false;
    public int timeoutMinutes = 180;

    /** Macro name per file name, when edited by the operator. */
    public final Map<String, String> macroByFile = new LinkedHashMap<>();

    /** Checkbox state per file name. */
    public final Map<String, Boolean> selectedByFile = new LinkedHashMap<>();
}
