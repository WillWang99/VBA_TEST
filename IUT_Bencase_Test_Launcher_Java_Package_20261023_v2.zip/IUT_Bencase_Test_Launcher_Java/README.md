# IUT Bencase Test Launcher — Java version

The same launcher as the C# version, implemented in Java (Swing) for
PCs where .NET cannot be installed. Feature-for-feature identical:

- Pick a folder → the app lists **every** `.xlsm` test file in it (no
  fixed list; new files appear automatically). Excel lock files
  (`~$...`) that exist while a workbook is open are ignored.
- The **Script to run** column is derived from the file name
  (`..._CCB.xlsm` → `Bencase_test_CCB`), can be edited by hand, and
  **Scan scripts** reads the macros actually stored in each file and
  lets you pick from the real list.
- Check the files to run → they execute **one at a time, in order**,
  each in its **own Excel process**.
- A per-test **timeout** (default 180 minutes) closes a blocked test
  (for example a script waiting on a dialog), records it as
  **Timed out**, and continues with the next one. **Stop** does the
  same on demand.
- **One-time scheduled run**: set a date and time, the app runs the
  checked tests once, unattended.
- Every run is recorded; the **History & Statistics** tab shows
  per-file run counts, success rate, average duration and last
  result, with a period filter and CSV export.

The data files are interchangeable with the C# version:
`run-history.csv` has the identical format, and
`launcher-settings.json` uses the same fields.

## How it talks to Excel

Java cannot call COM directly, so the app uses the **JACOB** bridge
(bundled in `lib/`: `jacob.jar` plus the Windows DLLs
`jacob-1.21-x64.dll` / `jacob-1.21-x86.dll`). Through it the app
starts a separate Excel process per test, opens the workbook, runs
its macro, saves and closes it — the same approach as the C#
version's automation. Keep the `lib` folder next to `app.jar`;
`run.bat` points Java at it.

## Requirements

- Windows 10/11 with Microsoft Excel (desktop, 2016 or later /
  Microsoft 365) — required to *run tests*, because the macros live
  in the workbooks.
- Java 17 or newer:
  - To **run** the included `app.jar`: a JRE/JDK 17+ is enough.
  - To **build from source**: a JDK 17+ (`javac -version` must work).
- The test files' folder should be an Excel **Trusted Location**
  (Excel → Options → Trust Center → Trusted Locations), or macro
  settings must otherwise allow these files.
- Reading script names with **Scan scripts** additionally needs
  Excel's **Trust access to the VBA project object model** setting
  (Trust Center → Macro Settings). Typing names manually works
  without it.

## Quick start (no build needed)

The package includes a prebuilt `app.jar`. Unzip everything into one
folder (keep `app.jar`, `run.bat` and `lib/` together), then
double-click **`run.bat`**.

1. In **Test files folder**, browse to the folder with the test
   `.xlsm` files.
2. Optionally click **Scan scripts** to fill the **Script to run**
   column with names that exist in the files (or type them).
3. Check the files to run and click **Run Selected** (or **Run All**).

## Locked-down PCs (no install rights)

No rebuild is needed on another PC: `app.jar` is compiled Java
bytecode and runs as-is on any Java 17+. If the PC has no Java and
you cannot install one (no admin rights), use the portable setup:

1. On any PC, download the Temurin JDK as a **.zip** (not the .msi
   installer) from adoptium.net, version 21, Windows x64.
2. Unzip it on the target PC — a folder like `jdk-21...` appears.
   No installation happens; it is just files in a folder.
3. Rename that folder to `jdk` and put it next to `app.jar` in this
   package's folder.
4. Start the app with **`run-portable.bat`**: it finds the `jdk`
   folder automatically and uses its Java (it falls back to a
   system Java on PATH if there is one).

Note: if the company blocks unknown programs by policy (AppLocker /
WDAC whitelisting), no packaging trick changes that — only IT can
allow the program. Rebuilding from source produces the same unsigned
files and does not help there. Microsoft Excel must still be
installed on the PC, and group policy must allow the workbooks'
macros to run, as with any launcher.

## Build from source

In a terminal (for example VS Code's integrated terminal) in this
folder:

```
build.bat
```

This compiles the sources in `src/` and recreates `app.jar`
(`build.sh` does the same on Linux/macOS). Then start with `run.bat`.

## Data files (created next to app.jar)

- `launcher-settings.json` — folder, options, per-file script names
  and checkbox states.
- `run-history.csv` — the full run history. Deleting it starts the
  statistics from zero; the app recreates it on the next run.

## Troubleshooting

- **`UnsatisfiedLinkError: no jacob... in java.library.path`** —
  start the app with `run.bat` (it sets the library path), and keep
  the `lib` folder next to `app.jar`. Do not rename the DLLs.
- **32-bit vs 64-bit** — JACOB loads the DLL that matches the Java
  runtime (x64 Java → `jacob-1.21-x64.dll`, 32-bit Java → the x86
  one). Both are in `lib/`. A 32-bit Java driving a 64-bit Excel is
  fine (Excel runs out of process).
- **`javac` is not recognized** — the JDK is not installed or not on
  PATH. Install a JDK 17+ (for example Eclipse Temurin) and reopen
  the terminal.
- **A run fails immediately with an Excel error** — usually macro
  security: add the test folder as a Trusted Location, or check that
  the file opens and its macro runs manually in Excel.
- **A run fails in a second or two and the macro works in Excel** —
  the name in the **Script to run** column does not exist in that
  file. Click **Scan scripts** to pick an existing name, or type the
  right one.
- **A test shows "Timed out"** — its script ran past the limit
  (often a dialog inside the script waiting for a click). Raise
  **Max minutes per test** if the test legitimately needs longer.

## Project layout

```
app.jar                 Prebuilt application (rebuild with build.bat)
run.bat                 Start script (sets the JACOB library path)
build.bat / build.sh    Build scripts (JDK 17+)
manifest.mf             Jar manifest (main class + JACOB classpath)
lib/                    JACOB 1.21: jacob.jar + Windows DLLs (x64/x86)
src/com/iutbencase/launcher/
  Main.java             Entry point
  MainFrame.java        Run tab, run queue, scheduling, scanning UI
  StatsPanel.java       History & Statistics tab
  ExcelRunner.java      Runs one test in its own Excel process,
                        with timeout / stop
  MacroScanner.java     Reads the macro list inside a workbook
  ExcelCom.java         Excel process tracking (find/kill our Excel)
  Models & stores       TestFileItem, RunRecord, FileStats,
                        AppSettings, SettingsStore, HistoryStore,
                        Json (settings), AppPaths
```
