Attribute VB_Name = "modSchedule"
'==============================================================================
' Module: modSchedule -- scheduled run (Application.OnTime)
' Minimal design: no existing module is changed, except one line in modRunner
' (its failure pop-up is skipped while SilentMode is True, so an unattended
' run never blocks on a dialog; the failure is still written to Run Log).
'
' Settings live on the Control Panel, row 23:
'   B23 = interval in minutes (1-1440)
'   D23 = [Start Schedule] button, E23 = [Stop Schedule] button
'   F23 = status text ("Next run: ..." / "Schedule is OFF")
' The row-23 labels and the two buttons are created by BuildButtons
' (modBuildButtons), same one-time setup as the other buttons.
'
' How it works: StartSchedule runs all enabled tests once right away, then
' arms Application.OnTime; each tick runs the tests again and re-arms.
' The scheduled run calls RunTest per enabled test (same as [Run All Tests]
' but without the confirmation / summary pop-ups).
'
' Limits of Application.OnTime (by design, not bugs):
'  - Master and Excel must stay open; closing Excel ends the schedule.
'  - Click [Stop Schedule] before closing Master; otherwise Excel may
'    reopen Master at the next scheduled time (it will not run anything,
'    because the schedule flag lives in memory and starts as OFF).
'  - If a manual run is in progress when a tick fires, that round is
'    skipped and the schedule continues with the next one.
'==============================================================================
Option Explicit

Private Const SCHED_INTERVAL_CELL As String = "B23"
Private Const SCHED_STATUS_CELL As String = "F23"
Private Const MIN_INTERVAL As Long = 1
Private Const MAX_INTERVAL As Long = 1440   ' at most once a day

Private NextRunTime As Date
Private ScheduleActive As Boolean

' Set to True by RunScheduledOnce so modRunner logs failures without the
' pop-up. Public so modRunner can read it.
Public SilentMode As Boolean

'------------------------------------------------------------------------------
' [Start Schedule] button entry.
'------------------------------------------------------------------------------
Public Sub StartSchedule()
    Dim minutes As Long
    minutes = ReadIntervalMinutes()
    If minutes = 0 Then
        MsgBox "Please enter the interval in minutes (1-1440) in cell B23 of the Control Panel first.", _
               vbExclamation, "Scheduled Run"
        Exit Sub
    End If
    If ScheduleActive Then
        MsgBox "The schedule is already active. Next run: " & Format(NextRunTime, "yyyy-mm-dd hh:nn") & "." & vbCrLf & _
               "Click [Stop Schedule] first if you want to restart it.", vbInformation, "Scheduled Run"
        Exit Sub
    End If
    ScheduleActive = True
    RunScheduledOnce
    ArmTimer minutes
    MsgBox "Schedule started: all enabled tests run now, then every " & minutes & " minute(s)." & vbCrLf & _
           "Next run: " & Format(NextRunTime, "yyyy-mm-dd hh:nn") & "." & vbCrLf & vbCrLf & _
           "Keep Master and Excel open. Click [Stop Schedule] before closing Master.", _
           vbInformation, "Scheduled Run"
End Sub

'------------------------------------------------------------------------------
' [Stop Schedule] button entry.
'------------------------------------------------------------------------------
Public Sub StopSchedule()
    If ScheduleActive And NextRunTime <> 0 Then
        On Error Resume Next
        Application.OnTime NextRunTime, "ScheduleTick", , False
        On Error GoTo 0
    End If
    ScheduleActive = False
    NextRunTime = 0
    SetScheduleStatus "Schedule is OFF"
    MsgBox "Schedule stopped.", vbInformation, "Scheduled Run"
End Sub

'------------------------------------------------------------------------------
' Application.OnTime callback. Must be Public: OnTime calls it by name.
'------------------------------------------------------------------------------
Public Sub ScheduleTick()
    Dim minutes As Long
    If Not ScheduleActive Then Exit Sub
    RunScheduledOnce
    minutes = ReadIntervalMinutes()
    If minutes = 0 Then
        ScheduleActive = False
        NextRunTime = 0
        SetScheduleStatus "Schedule stopped (B23 interval is empty or invalid)"
        Exit Sub
    End If
    ArmTimer minutes
End Sub

'------------------------------------------------------------------------------
' Run every enabled test's default script once, unattended:
' no confirmation, no summary, no failure pop-ups (SilentMode).
' Tests without a default script are logged as Failed instead of popping up.
'------------------------------------------------------------------------------
Private Sub RunScheduledOnce()
    Dim ws As Worksheet
    Dim r As Long
    Dim testCode As String
    If IsRunning Then Exit Sub   ' a run is in progress; skip this round
    SilentMode = True
    On Error GoTo CleanUp
    Set ws = ThisWorkbook.Worksheets(SHEET_CONFIG)
    For r = CONFIG_FIRST_ROW To CONFIG_LAST_ROW
        testCode = Trim(CStr(ws.Cells(r, CONFIG_COL_TEST).Value))
        If testCode <> "" And IsTestEnabled(testCode) Then
            If GetDefaultMacroForTest(testCode) = "" Then
                AppendLog testCode, GetFileNameForTest(testCode), "", "Failed", 0, _
                          "Scheduled run skipped: no default script set"
            Else
                RunTest testCode
            End If
        End If
    Next r
CleanUp:
    SilentMode = False
End Sub

Private Sub ArmTimer(ByVal minutes As Long)
    NextRunTime = Now + TimeSerial(0, minutes, 0)
    Application.OnTime NextRunTime, "ScheduleTick"
    SetScheduleStatus "Next run: " & Format(NextRunTime, "yyyy-mm-dd hh:nn")
End Sub

' Interval from Control Panel!B23; 0 = empty / not a number / out of range.
Private Function ReadIntervalMinutes() As Long
    Dim v As Variant
    v = ThisWorkbook.Worksheets(SHEET_PANEL).Range(SCHED_INTERVAL_CELL).Value
    If IsNumeric(v) Then
        If CLng(v) >= MIN_INTERVAL And CLng(v) <= MAX_INTERVAL Then
            ReadIntervalMinutes = CLng(v)
        End If
    End If
End Function

Private Sub SetScheduleStatus(ByVal text As String)
    On Error Resume Next
    ThisWorkbook.Worksheets(SHEET_PANEL).Range(SCHED_STATUS_CELL).Value = text
    On Error GoTo 0
End Sub
