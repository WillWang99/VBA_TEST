Attribute VB_Name = "modSchedule"
'==============================================================================
' Module: modSchedule -- scheduled run, ONE time only (Application.OnTime)
' Set a run time, click [Start Schedule], and Master waits (pending) until
' that time, runs all enabled tests once, and is done. No repetition.
'
' Settings live on the Control Panel, row 23:
'   B23 = run time. Two accepted forms:
'         - time of day only, e.g. 18:30  -> today at 18:30; if that time
'           has already passed, tomorrow at 18:30.
'         - full date + time, e.g. 2026-10-22 18:30 -> exactly then
'           (a full date + time in the past is rejected).
'         The value may be a real Excel date/time OR typed text: depending
'         on the Windows regional format, Excel may keep a typed
'         "2026-10-22 18:30" as TEXT (it displays like a date but is not a
'         number). ReadTargetTime parses both, so either way works.
'   D23 = [Start Schedule] button, E23 = [Stop Schedule] button
'   F23 = status text ("Pending: runs once at ..." / "Schedule is OFF")
' The row-23 labels and the two buttons are created by BuildButtons
' (modBuildButtons), same one-time setup as the other buttons.
'
' The run itself calls RunTest per enabled test (same set as [Run All
' Tests]) but unattended: no confirmation / summary / failure pop-ups;
' every result is written to the Run Log only. For that, modRunner skips
' its failure pop-up while SilentMode (declared below) is True.
'
' Limits of Application.OnTime (by design, not bugs):
'  - Master and Excel must stay open until the run time; closing Excel
'    cancels the pending run.
'  - Click [Stop Schedule] to cancel a pending run. If you close Master
'    without stopping, Excel may reopen Master at the set time (nothing
'    will run; the schedule flag lives in memory and starts as OFF).
'==============================================================================
Option Explicit

Private Const SCHED_TIME_CELL As String = "B23"
Private Const SCHED_STATUS_CELL As String = "F23"

Private NextRunTime As Date
Private ScheduleActive As Boolean

' Set to True by RunScheduledOnce so modRunner logs failures without the
' pop-up. Public so modRunner can read it.
Public SilentMode As Boolean

'------------------------------------------------------------------------------
' [Start Schedule] button entry: enter the pending state until B23's time.
'------------------------------------------------------------------------------
Public Sub StartSchedule()
    Dim target As Date
    Dim raw As Variant
    If ScheduleActive Then
        MsgBox "A scheduled run is already pending for " & Format(NextRunTime, "yyyy-mm-dd hh:nn") & "." & vbCrLf & _
               "Click [Stop Schedule] first if you want to change it.", vbInformation, "Scheduled Run"
        Exit Sub
    End If
    If Not ReadTargetTime(target) Then
        raw = ThisWorkbook.Worksheets(SHEET_PANEL).Range(SCHED_TIME_CELL).Value
        If Trim(CStr(raw)) = "" Then
            MsgBox "Please enter the run time in cell B23 of the Control Panel first." & vbCrLf & _
                   "Examples: 18:30 (today; tomorrow if that time has passed) or 2026-10-22 18:30.", _
                   vbExclamation, "Scheduled Run"
        Else
            MsgBox "The value in B23 ('" & CStr(raw) & "') was not recognized as a date/time." & vbCrLf & _
                   "Please enter it like 18:30 or 2026-10-22 18:30.", vbExclamation, "Scheduled Run"
        End If
        Exit Sub
    End If
    If target <= Now Then
        MsgBox "The time in B23 (" & Format(target, "yyyy-mm-dd hh:nn") & ") is in the past." & vbCrLf & _
               "Please set a future time.", vbExclamation, "Scheduled Run"
        Exit Sub
    End If
    NextRunTime = target
    ScheduleActive = True
    Application.OnTime NextRunTime, "ScheduleTick"
    SetScheduleStatus "Pending: runs once at " & Format(NextRunTime, "yyyy-mm-dd hh:nn")
    MsgBox "Scheduled. Master will run all enabled tests once at " & Format(NextRunTime, "yyyy-mm-dd hh:nn") & "." & vbCrLf & vbCrLf & _
           "Keep Master and Excel open until then. Click [Stop Schedule] to cancel.", _
           vbInformation, "Scheduled Run"
End Sub

'------------------------------------------------------------------------------
' [Stop Schedule] button entry: cancel the pending run.
'------------------------------------------------------------------------------
Public Sub StopSchedule()
    If ScheduleActive And NextRunTime <> 0 Then
        On Error Resume Next
        Application.OnTime NextRunTime, "ScheduleTick", , False
        On Error GoTo 0
    End If
    ScheduleActive = False
    NextRunTime = 0
    SetScheduleStatus "Schedule is OFF"
    MsgBox "Schedule cancelled. No run is pending.", vbInformation, "Scheduled Run"
End Sub

'------------------------------------------------------------------------------
' Application.OnTime callback. Must be Public: OnTime calls it by name.
' Runs the tests once and does NOT re-arm: one time only.
'------------------------------------------------------------------------------
Public Sub ScheduleTick()
    If Not ScheduleActive Then Exit Sub
    ScheduleActive = False
    NextRunTime = 0
    SetScheduleStatus "Running now (scheduled run)..."
    RunScheduledOnce
    SetScheduleStatus "Done: ran at " & Format(Now, "yyyy-mm-dd hh:nn") & ". Schedule is OFF"
End Sub

'------------------------------------------------------------------------------
' Run every enabled test's default script once, unattended:
' no confirmation, no summary, no failure pop-ups (SilentMode).
' Tests without a default script are logged as Failed instead of popping up.
'------------------------------------------------------------------------------
Private Sub RunScheduledOnce()
    Dim ws As Worksheet
    Dim r As Long
    Dim testCode As String
    If IsRunning Then Exit Sub   ' a run is in progress; do not overlap
    SilentMode = True
    On Error GoTo CleanUp
    Set ws = ThisWorkbook.Worksheets(SHEET_CONFIG)
    For r = CONFIG_FIRST_ROW To CONFIG_LAST_ROW
        testCode = Trim(CStr(ws.Cells(r, CONFIG_COL_TEST).Value))
        If testCode <> "" And IsTestEnabled(testCode) Then
            If GetDefaultMacroForTest(testCode) = "" Then
                AppendLog testCode, GetFileNameForTest(testCode), "", "Failed", 0, _
                          "Scheduled run skipped: no default script set"
            Else
                RunTest testCode
            End If
        End If
    Next r
CleanUp:
    SilentMode = False
End Sub

'------------------------------------------------------------------------------
' Read the run time from Control Panel!B23.
' Returns False if the cell is empty or holds no recognizable date/time.
' The cell may hold a real date/time value, or TEXT that looks like one
' (Excel keeps it as text under some regional formats) -- both are parsed.
' Time-of-day only (serial < 1): today at that time, or tomorrow if past.
' Full date + time (serial >= 1): used as-is (StartSchedule rejects past).
'------------------------------------------------------------------------------
Private Function ReadTargetTime(ByRef target As Date) As Boolean
    Dim v As Variant
    Dim d As Double
    v = ThisWorkbook.Worksheets(SHEET_PANEL).Range(SCHED_TIME_CELL).Value
    ' NOTE: for a date/time-formatted cell, Range.Value returns a Date, and
    ' VBA's IsNumeric() returns False for date expressions -- so the vbDate
    ' case must be tested explicitly, before IsNumeric.
    If VarType(v) = vbDate Or IsNumeric(v) Then
        d = CDbl(v)
    ElseIf VarType(v) = vbString Then
        If Not SerialFromText(Trim(CStr(v)), d) Then Exit Function
    Else
        Exit Function
    End If
    If d <= 0 Then Exit Function
    If d < 1 Then
        target = Date + d
        If target <= Now Then target = target + 1
    Else
        target = CDate(d)
    End If
    ReadTargetTime = True
End Function

'------------------------------------------------------------------------------
' Convert a typed date/time TEXT to an Excel serial number.
' First tries VBA's IsDate/CDate (locale formats, e.g. "10/21/2026 6:45 PM",
' and usually ISO too). If that fails, parses the ISO-style forms manually:
'   "18:30", "18:30:15", "2026-10-22", "2026-10-22 18:30", "2026/10/22 18:30"
' A time-only text returns a serial < 1; a date returns an integer part.
'------------------------------------------------------------------------------
Private Function SerialFromText(ByVal s As String, ByRef serial As Double) As Boolean
    Dim sp As Long
    Dim dateText As String
    Dim timeText As String
    Dim dp() As String
    Dim tp() As String
    Dim y As Long, mo As Long, dy As Long
    Dim hh As Long, mi As Long, ss As Long

    If s = "" Then Exit Function
    If IsDate(s) Then
        serial = CDbl(CDate(s))
        SerialFromText = True
        Exit Function
    End If

    sp = InStr(s, " ")
    If sp > 0 Then
        dateText = Trim(Left(s, sp - 1))
        timeText = Trim(Mid(s, sp + 1))
    ElseIf InStr(s, "-") > 0 Or InStr(s, "/") > 0 Then
        dateText = s
    Else
        timeText = s
    End If

    If timeText <> "" Then
        tp = Split(timeText, ":")
        If UBound(tp) < 1 Or UBound(tp) > 2 Then Exit Function
        If Not IsNumeric(tp(0)) Or Not IsNumeric(tp(1)) Then Exit Function
        hh = CLng(tp(0))
        mi = CLng(tp(1))
        If UBound(tp) = 2 Then
            If Not IsNumeric(tp(2)) Then Exit Function
            ss = CLng(tp(2))
        End If
        If hh < 0 Or hh > 23 Or mi < 0 Or mi > 59 Or ss < 0 Or ss > 59 Then Exit Function
    End If

    If dateText <> "" Then
        dateText = Replace(dateText, "/", "-")
        dp = Split(dateText, "-")
        If UBound(dp) <> 2 Then Exit Function
        If Not IsNumeric(dp(0)) Or Not IsNumeric(dp(1)) Or Not IsNumeric(dp(2)) Then Exit Function
        y = CLng(dp(0))
        mo = CLng(dp(1))
        dy = CLng(dp(2))
        If y < 2000 Or y > 2100 Or mo < 1 Or mo > 12 Or dy < 1 Or dy > 31 Then Exit Function
        serial = DateSerial(y, mo, dy)
    End If

    serial = serial + (hh * 3600# + mi * 60# + ss) / 86400#
    SerialFromText = True
End Function

Private Sub SetScheduleStatus(ByVal text As String)
    On Error Resume Next
    ThisWorkbook.Worksheets(SHEET_PANEL).Range(SCHED_STATUS_CELL).Value = text
    On Error GoTo 0
End Sub
