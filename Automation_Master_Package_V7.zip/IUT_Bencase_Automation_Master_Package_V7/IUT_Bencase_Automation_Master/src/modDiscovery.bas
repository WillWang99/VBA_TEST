Attribute VB_Name = "modDiscovery"
'==============================================================================
' Module: modDiscovery -- scan a target file for runnable macros (Public Sub)
' How it works: enumerate procedure names in standard modules via VBProject.
' Note: this requires Excel to trust "Access to the VBA project object model",
'       or it will error. On error, Master pops up an English guide and falls
'       back to the hand-maintained macro list in the Config sheet. It will
'       not crash. This is a deliberate fallback path, not a bug.
' To avoid a "missing reference" on some machines from referencing
' "Microsoft Visual Basic for Applications Extensibility", this module uses
' late-bound Object + numeric constants only.
'==============================================================================
Option Explicit

' Numeric constants for vbext_ComponentType / vbext_ProcKind (avoids referencing the VBIDE library)
Private Const VBEXT_CT_STDMODULE As Long = 1   ' Standard module
Private Const VBEXT_PK_PROC As Long = 0        ' Sub / Function procedure

'------------------------------------------------------------------------------
' Enumerate the Public Sub macro names in an open workbook (de-duplicated,
' in order of appearance within each module).
' Return a Collection; if VBProject cannot be accessed, return an empty
' Collection and let the caller handle the error.
'------------------------------------------------------------------------------
Public Function ListMacrosInWorkbook(ByVal wb As Workbook) As Collection
    Dim result As New Collection
    Dim vbProj As Object
    Dim vbComp As Object
    Dim codeMod As Object
    Dim lineCount As Long
    Dim i As Long
    Dim procName As String
    Dim procStart As Long
    Dim declLine As String

    On Error GoTo Fail
    Set vbProj = wb.VBProject   ' <-- errors 1004 / 50289 here if access is not trusted
    For Each vbComp In vbProj.VBComponents
        If vbComp.Type = VBEXT_CT_STDMODULE Then
            Set codeMod = vbComp.CodeModule
            lineCount = codeMod.CountOfLines
            For i = 1 To lineCount
                procName = ""
                On Error Resume Next
                procName = codeMod.ProcOfLine(i, VBEXT_PK_PROC)
                On Error GoTo Fail
                If procName <> "" Then
                    ' Collect each name only once: de-duplicate by Key (clear Err
                    ' first, so a leftover error number does not affect the check)
                    On Error Resume Next
                    Err.Clear
                    result.Add procName, UCase(procName)
                    If Err.Number = 0 Then
                        ' Newly collected macro: check its declaration line, skip Private Sub
                        procStart = codeMod.ProcStartLine(procName, VBEXT_PK_PROC)
                        declLine = codeMod.Lines(procStart, 1)
                        If InStr(1, declLine, "Private", vbTextCompare) > 0 Then
                            result.Remove UCase(procName)
                        End If
                    End If
                    Err.Clear
                    On Error GoTo Fail
                End If
            Next i
        End If
    Next vbComp
    Set ListMacrosInWorkbook = result
    Exit Function

Fail:
    ' Re-raise the error to the caller, which decides whether it is an
    ' "untrusted access" error and shows the English guide
    Err.Raise Err.Number, Err.Source, Err.Description
End Function

'------------------------------------------------------------------------------
' Scan one test's target file and write the macro list back to Config column D;
' if the default macro is empty and at least one macro was found, make the
' first macro the default.
' Return value: number of macros found; -1 means failure due to "untrusted access".
'------------------------------------------------------------------------------
Public Function ScanAndUpdateConfig(ByVal testCode As String) As Long
    Dim filePath As String
    Dim wb As Workbook
    Dim wasOpen As Boolean
    Dim macros As Collection
    Dim macroStr As String

    ScanAndUpdateConfig = -1
    If Not IsTestEnabled(testCode) Then
        MsgBox "Test " & testCode & " is disabled in the Config sheet (Enabled <> YES).", vbInformation, "Skipped"
        ScanAndUpdateConfig = 0
        Exit Function
    End If

    filePath = FindTargetFilePath(testCode)
    If filePath = "" Then
        MsgBox "Cannot find the file for test " & testCode & ": " & GetFileNameForTest(testCode) & vbCrLf & _
               "Please confirm the file is in folder " & GetFolderPath() & " or click [Browse...] to change the folder.", _
               vbExclamation, "File Not Found"
        ScanAndUpdateConfig = 0
        Exit Function
    End If

    Set wb = OpenTargetWorkbook(filePath, False, wasOpen)
    If wb Is Nothing Then
        MsgBox "Cannot open file: " & filePath, vbExclamation, "Open Failed"
        ScanAndUpdateConfig = 0
        Exit Function
    End If

    On Error GoTo ScanFail
    Set macros = ListMacrosInWorkbook(wb)
    On Error GoTo 0
    macroStr = JoinMacroList(macros)
    SetAllMacrosStringForTest testCode, macroStr
    If GetDefaultMacroForTest(testCode) = "" And macros.Count > 0 Then
        SetDefaultMacroForTest testCode, macros(1)
    End If
    CloseTargetWorkbook wb, wasOpen, True
    ScanAndUpdateConfig = macros.Count
    Exit Function

ScanFail:
    CloseTargetWorkbook wb, wasOpen, True
    ' Error numbers are language-independent, so they cover Excel in any language.
    ' The "Programmatic access" text check is a second signal for English Excel.
    If Err.Number = 1004 Or Err.Number = 50289 Or InStr(1, Err.Description, "Programmatic access", vbTextCompare) > 0 Then
        MsgBox "Scanning requires Excel to trust 'Access to the VBA project object model', which is currently not enabled." & vbCrLf & vbCrLf & _
               "To enable: File -> Options -> Trust Center -> Trust Center Settings -> Macro Settings -> " & vbCrLf & _
               "check 'Trust access to the VBA project object model' -> OK -> reopen Master." & vbCrLf & vbCrLf & _
               "Alternatively, type the macro names directly in column D of the Config sheet (comma-separated);" & vbCrLf & _
               "Master will use the Config list directly, which does not affect running.", vbExclamation, "Trust Access Required"
        ScanAndUpdateConfig = -1
    Else
        MsgBox "Error scanning " & testCode & ": " & Err.Description, vbExclamation, "Scan Failed"
        ScanAndUpdateConfig = 0
    End If
End Function

'------------------------------------------------------------------------------
' Set the selected test's macro list as the dropdown options of the
' "selected script" cell in the Advanced section.
'------------------------------------------------------------------------------
Public Sub RefreshMacroListForSelectedTest()
    Dim testCode As String
    Dim macroStr As String
    Dim macros As Collection
    Dim ws As Worksheet
    Dim cell As Range
    Dim listStr As String
    Dim v As Variant

    testCode = GetSelectedTest()
    If testCode = "" Then
        MsgBox "Please select a test in the 'Test' cell first.", vbInformation, "No Test Selected"
        Exit Sub
    End If
    macroStr = GetAllMacrosStringForTest(testCode)
    If Trim(macroStr) = "" Then
        If MsgBox("Test " & testCode & " has no macro list in the Config sheet yet. Scan its file now?", _
                  vbYesNo + vbQuestion, "Macro List Empty") = vbYes Then
            If ScanAndUpdateConfig(testCode) < 0 Then Exit Sub
            macroStr = GetAllMacrosStringForTest(testCode)
        Else
            Exit Sub
        End If
    End If
    If Trim(macroStr) = "" Then
        MsgBox "No runnable Public Sub macro found in the file for test " & testCode & ".", vbInformation, "No Macros Available"
        Exit Sub
    End If

    Set macros = SplitMacroList(macroStr)
    listStr = ""
    For Each v In macros
        If listStr = "" Then listStr = CStr(v) Else listStr = listStr & "," & CStr(v)
    Next v

    Set ws = ThisWorkbook.Worksheets(SHEET_PANEL)
    Set cell = ws.Range(PANEL_SEL_MACRO_CELL)
    On Error Resume Next
    cell.Validation.Delete
    On Error GoTo 0
    ' The Formula1 string of a data-validation dropdown is limited to about 255
    ' characters; if longer, do not set a dropdown, leave free input instead
    If Len(listStr) <= 250 Then
        cell.Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Formula1:=listStr
    End If
    cell.Value = macros(1)
    MsgBox "Refreshed the script list for test " & testCode & ": " & macros.Count & " found.", vbInformation, "Refreshed"
End Sub
