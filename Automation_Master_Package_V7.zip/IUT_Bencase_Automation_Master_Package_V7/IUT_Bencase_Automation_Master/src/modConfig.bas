Attribute VB_Name = "modConfig"
'==============================================================================
' Module: modConfig -- config read/write (Config sheet + Control Panel options)
' Note: all "test / file name / default macro / options" live in the worksheets,
'       not hard-coded. To add a test or change a macro name, edit the Config
'       sheet; no code change is needed.
'==============================================================================
Option Explicit

' --- Worksheet names (do not rename them; the code depends on these three names) ---
Public Const SHEET_PANEL As String = "Control Panel"
Public Const SHEET_CONFIG As String = "Config"
Public Const SHEET_LOG As String = "Run Log"

' --- Config sheet layout (row 1 = header, rows 2-7 = the 6 tests) ---
Public Const CONFIG_FIRST_ROW As Long = 2
Public Const CONFIG_LAST_ROW As Long = 7
Public Const CONFIG_COL_TEST As Long = 1   ' A: Test Code
Public Const CONFIG_COL_FILE As Long = 2   ' B: File Name
Public Const CONFIG_COL_DEFAULT_MACRO As Long = 3 ' C: Default Macro
Public Const CONFIG_COL_ALL_MACROS As Long = 4    ' D: All Macros (comma-separated)
Public Const CONFIG_COL_DESC As Long = 5   ' E: Description
Public Const CONFIG_COL_ENABLED As Long = 6 ' F: Enabled (YES/NO)

' --- Key Control Panel cells (see the layout diagram in README) ---
Public Const PANEL_FOLDER_CELL As String = "B4"   ' Test files folder
Public Const PANEL_TEST_TABLE_FIRST_ROW As Long = 9 ' Test table first row
Public Const PANEL_TEST_TABLE_LAST_ROW As Long = 14 ' 6 tests
Public Const PANEL_SEL_TEST_CELL As String = "B17"  ' Advanced section: selected test
Public Const PANEL_SEL_MACRO_CELL As String = "B18"  ' Advanced section: selected script
Public Const PANEL_CLOSE_AFTER_CELL As String = "B20" ' Close target file after run YES/NO
Public Const PANEL_SHOW_TARGET_CELL As String = "B21" ' Show target file window YES/NO
Public Const PANEL_LOG_PREVIEW_FIRST_ROW As Long = 26 ' Log preview first data row (row 25 is the preview header)
Public Const PANEL_LOG_PREVIEW_ROWS As Long = 10

' --- Running flag (prevents double-clicks / closing while a script is running) ---
Public IsRunning As Boolean

'------------------------------------------------------------------------------
' Folder: prefer Control Panel!B4; if empty, use the Master file's folder and write it back
'------------------------------------------------------------------------------
Public Function GetFolderPath() As String
    Dim ws As Worksheet
    Dim p As String
    Set ws = ThisWorkbook.Worksheets(SHEET_PANEL)
    p = Trim(CStr(ws.Range(PANEL_FOLDER_CELL).Value))
    If p = "" Then
        p = ThisWorkbook.Path
        If p = "" Then
            MsgBox "Please save the Master file first, then run it.", vbExclamation, "Master Not Saved"
            GetFolderPath = ""
            Exit Function
        End If
        ws.Range(PANEL_FOLDER_CELL).Value = p
    End If
    ' Strip the trailing backslash (except for a root directory)
    If Len(p) > 3 And Right(p, 1) = "\" Then p = Left(p, Len(p) - 1)
    GetFolderPath = p
End Function

Public Sub SetFolderPath(ByVal p As String)
    ThisWorkbook.Worksheets(SHEET_PANEL).Range(PANEL_FOLDER_CELL).Value = p
End Sub

'------------------------------------------------------------------------------
' Config sheet: find the row number by test code; return 0 if not found
'------------------------------------------------------------------------------
Public Function GetTestRow(ByVal testCode As String) As Long
    Dim ws As Worksheet
    Dim r As Long
    Set ws = ThisWorkbook.Worksheets(SHEET_CONFIG)
    For r = CONFIG_FIRST_ROW To CONFIG_LAST_ROW
        If UCase(Trim(CStr(ws.Cells(r, CONFIG_COL_TEST).Value))) = UCase(Trim(testCode)) Then
            GetTestRow = r
            Exit Function
        End If
    Next r
    GetTestRow = 0
End Function

Public Function GetFileNameForTest(ByVal testCode As String) As String
    Dim r As Long
    r = GetTestRow(testCode)
    If r = 0 Then Exit Function
    GetFileNameForTest = Trim(CStr(ThisWorkbook.Worksheets(SHEET_CONFIG).Cells(r, CONFIG_COL_FILE).Value))
End Function

Public Function GetDefaultMacroForTest(ByVal testCode As String) As String
    Dim r As Long
    r = GetTestRow(testCode)
    If r = 0 Then Exit Function
    GetDefaultMacroForTest = Trim(CStr(ThisWorkbook.Worksheets(SHEET_CONFIG).Cells(r, CONFIG_COL_DEFAULT_MACRO).Value))
End Function

Public Sub SetDefaultMacroForTest(ByVal testCode As String, ByVal macroName As String)
    Dim r As Long
    r = GetTestRow(testCode)
    If r = 0 Then Exit Sub
    ThisWorkbook.Worksheets(SHEET_CONFIG).Cells(r, CONFIG_COL_DEFAULT_MACRO).Value = macroName
End Sub

Public Function GetAllMacrosStringForTest(ByVal testCode As String) As String
    Dim r As Long
    r = GetTestRow(testCode)
    If r = 0 Then Exit Function
    GetAllMacrosStringForTest = Trim(CStr(ThisWorkbook.Worksheets(SHEET_CONFIG).Cells(r, CONFIG_COL_ALL_MACROS).Value))
End Function

Public Sub SetAllMacrosStringForTest(ByVal testCode As String, ByVal macroList As String)
    Dim r As Long
    r = GetTestRow(testCode)
    If r = 0 Then Exit Sub
    ThisWorkbook.Worksheets(SHEET_CONFIG).Cells(r, CONFIG_COL_ALL_MACROS).Value = macroList
End Sub

Public Function IsTestEnabled(ByVal testCode As String) As Boolean
    Dim r As Long
    Dim v As String
    r = GetTestRow(testCode)
    If r = 0 Then
        IsTestEnabled = False
        Exit Function
    End If
    v = UCase(Trim(CStr(ThisWorkbook.Worksheets(SHEET_CONFIG).Cells(r, CONFIG_COL_ENABLED).Value)))
    IsTestEnabled = (v = "YES" Or v = "Y" Or v = "TRUE" Or v = "1")
End Function

'------------------------------------------------------------------------------
' Split "MacroA, MacroB, MacroC" into a de-duplicated Collection
'------------------------------------------------------------------------------
Public Function SplitMacroList(ByVal s As String) As Collection
    Dim c As New Collection
    Dim parts() As String
    Dim i As Long
    Dim m As String
    If Trim(s) = "" Then
        Set SplitMacroList = c
        Exit Function
    End If
    parts = Split(s, ",")
    For i = LBound(parts) To UBound(parts)
        m = Trim(CStr(parts(i)))
        If m <> "" Then
            On Error Resume Next
            c.Add m, UCase(m)  ' Use the upper-case name as the Key for de-duplication
            On Error GoTo 0
        End If
    Next i
    Set SplitMacroList = c
End Function

Public Function JoinMacroList(ByVal c As Collection) As String
    Dim out As String
    Dim v As Variant
    For Each v In c
        If out = "" Then
            out = CStr(v)
        Else
            out = out & ", " & CStr(v)
        End If
    Next v
    JoinMacroList = out
End Function

'------------------------------------------------------------------------------
' Advanced section options
'------------------------------------------------------------------------------
Public Function GetSelectedTest() As String
    GetSelectedTest = Trim(CStr(ThisWorkbook.Worksheets(SHEET_PANEL).Range(PANEL_SEL_TEST_CELL).Value))
End Function

Public Function GetSelectedMacro() As String
    GetSelectedMacro = Trim(CStr(ThisWorkbook.Worksheets(SHEET_PANEL).Range(PANEL_SEL_MACRO_CELL).Value))
End Function

Public Function GetCloseAfter() As Boolean
    Dim v As String
    v = UCase(Trim(CStr(ThisWorkbook.Worksheets(SHEET_PANEL).Range(PANEL_CLOSE_AFTER_CELL).Value)))
    GetCloseAfter = Not (v = "NO" Or v = "N" Or v = "FALSE" Or v = "0")
End Function

Public Function GetShowTarget() As Boolean
    Dim v As String
    v = UCase(Trim(CStr(ThisWorkbook.Worksheets(SHEET_PANEL).Range(PANEL_SHOW_TARGET_CELL).Value)))
    GetShowTarget = Not (v = "NO" Or v = "N" Or v = "FALSE" Or v = "0")
End Function

'------------------------------------------------------------------------------
' Update one row's "Last Result" (column F) in the Control Panel test table
'------------------------------------------------------------------------------
Public Sub SetPanelLastResult(ByVal testCode As String, ByVal text As String)
    Dim ws As Worksheet
    Dim r As Long
    Set ws = ThisWorkbook.Worksheets(SHEET_PANEL)
    For r = PANEL_TEST_TABLE_FIRST_ROW To PANEL_TEST_TABLE_LAST_ROW
        If UCase(Trim(CStr(ws.Cells(r, 1).Value))) = UCase(Trim(testCode)) Then
            ws.Cells(r, 6).Value = text
            Exit Sub
        End If
    Next r
End Sub
