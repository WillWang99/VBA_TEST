Attribute VB_Name = "modSchedule"
'==============================================================================
' Module: modSchedule -- scheduled run, ONE time only (Application.OnTime)
' Set a run time, click [Start Schedule], and Master waits (pending) until
' that time, runs all enabled tests once, and is done. No repetition.
'
' Settings live on the Control Panel, row 23:
'   B23 = run time. Two accepted forms:
'         - time of day only, e.g. 18:30  -> today at 18:30; if that time
'           has already passed, tomorrow at 18:30.
'         - full date + time, e.g. 2026-10-22 18:30 -> exactly then
'           (a full date + time in the past is rejected).
'   D23 = [Start Schedule] button, E23 = [Stop Schedule] button
'   F23 = status text ("Pending: runs once at ..." / "Schedule is OFF")
' The row-23 labels and the two buttons are created by BuildButtons
' (modBuildButtons), same one-time setup as the other buttons.
'
' The run itself calls RunTest per enabled test (same set as [Run All
' Tests]) but unattended: no confirmation / summary / failure pop-ups;
' every result is written to the Run Log only. For that, modRunner skips
' its failure pop-up while SilentMode (declared below) is True.
'
' Limits of Application.OnTime (by design, not bugs):
'  - Master and Excel must stay open until the run time; closing Excel
'    cancels the pending run.
'  - Click [Stop Schedule] to cancel a pending run. If you close Master
'    without stopping, Excel may reopen Master at the set time (nothing
'    will run; the schedule flag lives in memory and starts as OFF).
'==============================================================================
Option Explicit

Private Const SCHED_TIME_CELL As String = "B23"
Private Const SCHED_STATUS_CELL As String = "F23"

Private NextRunTime As Date
Private ScheduleActive As Boolean

' Set to True by RunScheduledOnce so modRunner logs failures without the
' pop-up. Public so modRunner can read it.
Public SilentMode As Boolean

'------------------------------------------------------------------------------
' [Start Schedule] button entry: enter the pending state until B23's time.
'------------------------------------------------------------------------------
Public Sub StartSchedule()
    Dim target As Date
    If ScheduleActive Then
        MsgBox "A scheduled run is already pending for " & Format(NextRunTime, "yyyy-mm-dd hh:nn") & "." & vbCrLf & _
               "Click [Stop Schedule] first if you want to change it.", vbInformation, "Scheduled Run"
        Exit Sub
    End If
    If Not ReadTargetTime(target) Then
        MsgBox "Please enter the run time in cell B23 of the Control Panel first." & vbCrLf & _
               "Examples: 18:30 (today; tomorrow if that time has passed) or 2026-10-22 18:30.", _
               vbExclamation, "Scheduled Run"
        Exit Sub
    End If
    If target <= Now Then
        MsgBox "The time in B23 (" & Format(target, "yyyy-mm-dd hh:nn") & ") is in the past." & vbCrLf & _
               "Please set a future time.", vbExclamation, "Scheduled Run"
        Exit Sub
    End If
    NextRunTime = target
    ScheduleActive = True
    Application.OnTime NextRunTime, "ScheduleTick"
    SetScheduleStatus "Pending: runs once at " & Format(NextRunTime, "yyyy-mm-dd hh:nn")
    MsgBox "Scheduled. Master will run all enabled tests once at " & Format(NextRunTime, "yyyy-mm-dd hh:nn") & "." & vbCrLf & vbCrLf & _
           "Keep Master and Excel open until then. Click [Stop Schedule] to cancel.", _
           vbInformation, "Scheduled Run"
End Sub

'------------------------------------------------------------------------------
' [Stop Schedule] button entry: cancel the pending run.
'------------------------------------------------------------------------------
Public Sub StopSchedule()
    If ScheduleActive And NextRunTime <> 0 Then
        On Error Resume Next
        Application.OnTime NextRunTime, "ScheduleTick", , False
        On Error GoTo 0
    End If
    ScheduleActive = False
    NextRunTime = 0
    SetScheduleStatus "Schedule is OFF"
    MsgBox "Schedule cancelled. No run is pending.", vbInformation, "Scheduled Run"
End Sub

'------------------------------------------------------------------------------
' Application.OnTime callback. Must be Public: OnTime calls it by name.
' Runs the tests once and does NOT re-arm: one time only.
'------------------------------------------------------------------------------
Public Sub ScheduleTick()
    If Not ScheduleActive Then Exit Sub
    ScheduleActive = False
    NextRunTime = 0
    SetScheduleStatus "Running now (scheduled run)..."
    RunScheduledOnce
    SetScheduleStatus "Done: ran at " & Format(Now, "yyyy-mm-dd hh:nn") & ". Schedule is OFF"
End Sub

'------------------------------------------------------------------------------
' Run every enabled test's default script once, unattended:
' no confirmation, no summary, no failure pop-ups (SilentMode).
' Tests without a default script are logged as Failed instead of popping up.
'------------------------------------------------------------------------------
Private Sub RunScheduledOnce()
    Dim ws As Worksheet
    Dim r As Long
    Dim testCode As String
    If IsRunning Then Exit Sub   ' a run is in progress; do not overlap
    SilentMode = True
    On Error GoTo CleanUp
    Set ws = ThisWorkbook.Worksheets(SHEET_CONFIG)
    For r = CONFIG_FIRST_ROW To CONFIG_LAST_ROW
        testCode = Trim(CStr(ws.Cells(r, CONFIG_COL_TEST).Value))
        If testCode <> "" And IsTestEnabled(testCode) Then
            If GetDefaultMacroForTest(testCode) = "" Then
                AppendLog testCode, GetFileNameForTest(testCode), "", "Failed", 0, _
                          "Scheduled run skipped: no default script set"
            Else
                RunTest testCode
            End If
        End If
    Next r
CleanUp:
    SilentMode = False
End Sub

'------------------------------------------------------------------------------
' Read the run time from Control Panel!B23.
' Returns False if the cell is empty or not a date/time value.
' Time-of-day only (< 1): today at that time, or tomorrow if already past.
' Full date + time (>= 1): used as-is (StartSchedule rejects a past time).
'------------------------------------------------------------------------------
Private Function ReadTargetTime(ByRef target As Date) As Boolean
    Dim v As Variant
    Dim d As Double
    v = ThisWorkbook.Worksheets(SHEET_PANEL).Range(SCHED_TIME_CELL).Value
    If Not IsNumeric(v) Then Exit Function
    d = CDbl(v)
    If d <= 0 Then Exit Function
    If d < 1 Then
        target = Date + d
        If target <= Now Then target = target + 1
    Else
        target = CDate(d)
    End If
    ReadTargetTime = True
End Function

Private Sub SetScheduleStatus(ByVal text As String)
    On Error Resume Next
    ThisWorkbook.Worksheets(SHEET_PANEL).Range(SCHED_STATUS_CELL).Value = text
    On Error GoTo 0
End Sub
