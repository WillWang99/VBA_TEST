Attribute VB_Name = "modRunner"
'==============================================================================
' Module: modRunner -- run the test scripts in target files (core)
' Call chain: button -> Run_CCB / RunSelected / RunAllTests -> RunTest -> RunMacro
' RunMacro's job: validate -> open target file -> Application.Run -> log -> close file
' A single test failure is only logged; it does not stop the later tests of "Run All Tests".
'==============================================================================
Option Explicit

'------------------------------------------------------------------------------
' Run one test's default script (Config column C). Called by the one-click button.
'------------------------------------------------------------------------------
Public Function RunTest(ByVal testCode As String) As Boolean
    Dim macroName As String
    If Not IsTestEnabled(testCode) Then
        MsgBox "Test " & testCode & " is disabled in the Config sheet (Enabled <> YES).", vbInformation, "Skipped"
        RunTest = False
        Exit Function
    End If
    macroName = GetDefaultMacroForTest(testCode)
    If macroName = "" Then
        MsgBox "Test " & testCode & " has no default script set." & vbCrLf & vbCrLf & _
               "Please enter the default macro name for this test in column C of the Config sheet," & vbCrLf & _
               "or select the test in the Advanced section and click [Refresh Script List], then [Scan].", vbExclamation, "Default Script Not Set"
        RunTest = False
        Exit Function
    End If
    RunTest = RunMacro(testCode, macroName, GetCloseAfter(), GetShowTarget())
End Function

'------------------------------------------------------------------------------
' Run a specified script of a specified test. Return True = success, False = failure.
'------------------------------------------------------------------------------
Public Function RunMacro(ByVal testCode As String, ByVal macroName As String, _
                         ByVal closeAfter As Boolean, ByVal showTarget As Boolean) As Boolean
    Dim filePath As String
    Dim fileName As String
    Dim wb As Workbook
    Dim wasOpen As Boolean
    Dim startTime As Double
    Dim durationSec As Double
    Dim runTarget As String
    Dim errMsg As String

    If IsRunning Then
        MsgBox "A script is already running. Please wait for it to finish.", vbExclamation, "Running"
        RunMacro = False
        Exit Function
    End If
    IsRunning = True
    startTime = Timer
    On Error GoTo RunFail

    ' --- Validate ---
    filePath = FindTargetFilePath(testCode)
    If filePath = "" Then
        errMsg = "Cannot find file " & GetFileNameForTest(testCode) & ", Please confirm the file is in folder " & GetFolderPath() & "."
        GoTo LogFail
    End If
    fileName = Mid(filePath, InStrRev(filePath, "\") + 1)
    If Trim(macroName) = "" Then
        errMsg = "No script name specified."
        GoTo LogFail
    End If

    ' --- Open the target file ---
    Set wb = OpenTargetWorkbook(filePath, showTarget, wasOpen)
    If wb Is Nothing Then
        errMsg = "Cannot open file " & filePath
        GoTo LogFail
    End If

    ' --- Run the script ---
    ' Application.Run full form: 'FileName'!MacroName. The macro name may
    ' carry a module prefix, e.g. Module1.RunAll.
    runTarget = "'" & fileName & "'!" & macroName
    Application.StatusBar = "Running script " & macroName & " for test " & testCode & " ..."
    Application.Run runTarget
    Application.StatusBar = False

    durationSec = Timer - startTime
    If durationSec < 0 Then durationSec = durationSec + 86400 ' Midnight crossover fix
    CloseTargetWorkbook wb, wasOpen, closeAfter
    IsRunning = False
    AppendLog testCode, fileName, macroName, "Success", durationSec, "Took " & Round(durationSec, 2) & " seconds"
    RunMacro = True
    Exit Function

LogFail:
    durationSec = Timer - startTime
    If durationSec < 0 Then durationSec = durationSec + 86400
    IsRunning = False
    Application.StatusBar = False
    AppendLog testCode, fileName, macroName, "Failed", durationSec, errMsg
    ' Scheduled runs set SilentMode (modSchedule): log only, no pop-up,
    ' so an unattended run never blocks waiting for a click.
    If Not SilentMode Then MsgBox errMsg, vbExclamation, "Run Failed: " & testCode
    RunMacro = False
    Exit Function

RunFail:
    errMsg = "Error running script " & macroName & " for test " & testCode & ": " & Err.Description & " (Error " & Err.Number & ")"
    If Not wb Is Nothing Then
        On Error Resume Next
        CloseTargetWorkbook wb, wasOpen, closeAfter
        On Error GoTo 0
    End If
    Resume LogFail
End Function

'------------------------------------------------------------------------------
' Advanced section: run the selected test's selected script.
'------------------------------------------------------------------------------
Public Sub RunSelected()
    Dim testCode As String
    Dim macroName As String
    testCode = GetSelectedTest()
    macroName = GetSelectedMacro()
    If testCode = "" Then
        MsgBox "Please select a test in the 'Test' cell first.", vbInformation, "No Test Selected"
        Exit Sub
    End If
    If macroName = "" Then
        MsgBox "Please select a script in the 'Script' cell first (click [Refresh Script List]).", vbInformation, "No Script Selected"
        Exit Sub
    End If
    RunMacro testCode, macroName, GetCloseAfter(), GetShowTarget()
End Sub

'------------------------------------------------------------------------------
' Run the default script of every enabled test (in Config order).
' One failure does not stop the rest.
'------------------------------------------------------------------------------
Public Sub RunAllTests()
    Dim ws As Worksheet
    Dim r As Long
    Dim testCode As String
    Dim okCount As Long
    Dim failCount As Long
    Dim skipCount As Long
    Dim summary As String
    If IsRunning Then
        MsgBox "A script is already running. Please wait for it to finish.", vbExclamation, "Running"
        Exit Sub
    End If
    If MsgBox("This will run the default script of every enabled test in Config order. Continue?", _
              vbYesNo + vbQuestion, "Run All Tests") <> vbYes Then Exit Sub
    Set ws = ThisWorkbook.Worksheets(SHEET_CONFIG)
    For r = CONFIG_FIRST_ROW To CONFIG_LAST_ROW
        testCode = Trim(CStr(ws.Cells(r, CONFIG_COL_TEST).Value))
        If testCode = "" Then
            skipCount = skipCount + 1
        ElseIf Not IsTestEnabled(testCode) Then
            skipCount = skipCount + 1
        Else
            If RunTest(testCode) Then okCount = okCount + 1 Else failCount = failCount + 1
        End If
    Next r
    summary = "All runs finished: " & okCount & " succeeded, " & failCount & " failed, " & skipCount & " skipped." & vbCrLf & _
              "See the Run Log sheet for details."
    MsgBox summary, vbInformation, "Run All Tests"
End Sub

'------------------------------------------------------------------------------
' The 6 one-click button entries (each test's button on Control Panel binds to one).
' Keep the one-to-one binding: even if a button is moved or copied,
' Application.Caller parsing cannot break it.
'------------------------------------------------------------------------------
Public Sub Run_CCB()
    RunTest "CCB"
End Sub

Public Sub Run_ACWB()
    RunTest "ACWB"
End Sub

Public Sub Run_PEICB()
    RunTest "PEICB"
End Sub

Public Sub Run_OSTC()
    RunTest "OSTC"
End Sub

Public Sub Run_CGEB()
    RunTest "CGEB"
End Sub

Public Sub Run_NLDB()
    RunTest "NLDB"
End Sub
