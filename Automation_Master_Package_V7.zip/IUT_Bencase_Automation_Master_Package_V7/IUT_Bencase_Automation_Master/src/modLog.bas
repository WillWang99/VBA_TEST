Attribute VB_Name = "modLog"
'==============================================================================
' Module: modLog -- run log (Run Log sheet + log preview on Control Panel)
'==============================================================================
Option Explicit

'------------------------------------------------------------------------------
' Append one run-log entry. Pass Status as "Success" or "Failed".
' Also update the matching test's "Last Result" on Control Panel and the log preview.
'------------------------------------------------------------------------------
Public Sub AppendLog(ByVal testCode As String, ByVal fileName As String, _
                     ByVal macroName As String, ByVal status As String, _
                     ByVal durationSec As Double, ByVal message As String)
    Dim ws As Worksheet
    Dim nextRow As Long
    Dim stamp As String
    Set ws = ThisWorkbook.Worksheets(SHEET_LOG)
    nextRow = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row + 1
    If nextRow < 2 Then nextRow = 2
    stamp = Format(Now, "yyyy-mm-dd hh:nn:ss")
    ws.Cells(nextRow, 1).Value = stamp
    ws.Cells(nextRow, 2).Value = testCode
    ws.Cells(nextRow, 3).Value = fileName
    ws.Cells(nextRow, 4).Value = macroName
    ws.Cells(nextRow, 5).Value = status
    ws.Cells(nextRow, 6).Value = Round(durationSec, 2)
    ws.Cells(nextRow, 7).Value = message
    On Error Resume Next
    ThisWorkbook.Save   ' Save the log; if the file is read-only, silently skip without interrupting the run
    On Error GoTo 0

    SetPanelLastResult testCode, stamp & " " & status & IIf(Trim(message) = "", "", ": " & message)
    UpdateLogPreview
End Sub

'------------------------------------------------------------------------------
' Copy the last N rows of Run Log to the log preview area on Control Panel.
'------------------------------------------------------------------------------
Public Sub UpdateLogPreview()
    Dim logWs As Worksheet
    Dim panelWs As Worksheet
    Dim lastRow As Long
    Dim firstRow As Long
    Dim r As Long, pr As Long
    Dim c As Long
    Set logWs = ThisWorkbook.Worksheets(SHEET_LOG)
    Set panelWs = ThisWorkbook.Worksheets(SHEET_PANEL)
    lastRow = logWs.Cells(logWs.Rows.Count, 1).End(xlUp).Row
    ' Clear the preview area
    panelWs.Range(panelWs.Cells(PANEL_LOG_PREVIEW_FIRST_ROW, 1), _
                  panelWs.Cells(PANEL_LOG_PREVIEW_FIRST_ROW + PANEL_LOG_PREVIEW_ROWS - 1, 6)).ClearContents
    If lastRow < 2 Then Exit Sub
    firstRow = lastRow - PANEL_LOG_PREVIEW_ROWS + 1
    If firstRow < 2 Then firstRow = 2
    pr = PANEL_LOG_PREVIEW_FIRST_ROW
    For r = firstRow To lastRow
        For c = 1 To 6
            panelWs.Cells(pr, c).Value = logWs.Cells(r, c).Value
        Next c
        pr = pr + 1
    Next r
End Sub

'------------------------------------------------------------------------------
' Clear Log (keep the header row). Called by the button on the Run Log sheet.
'------------------------------------------------------------------------------
Public Sub ClearLog()
    Dim ws As Worksheet
    If MsgBox("Are you sure you want to clear the entire run log?", vbYesNo + vbQuestion, "Clear Log") <> vbYes Then Exit Sub
    Set ws = ThisWorkbook.Worksheets(SHEET_LOG)
    ws.Range(ws.Cells(2, 1), ws.Cells(ws.Rows.Count, 7)).ClearContents
    On Error Resume Next
    ThisWorkbook.Save
    On Error GoTo 0
    UpdateLogPreview
    MsgBox "Run log cleared.", vbInformation, "Cleared"
End Sub
