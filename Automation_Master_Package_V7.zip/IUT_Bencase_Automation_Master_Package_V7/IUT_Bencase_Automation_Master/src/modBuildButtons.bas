Attribute VB_Name = "modBuildButtons"
'==============================================================================
' Module: modBuildButtons -- one-time creation of the clickable buttons
' After a manual import there are no button shapes on the sheets (the texts
' like "[ Run ]" are only cell values, not clickable). Run BuildButtons once
' (Alt+F8) to draw real buttons over those cells, each bound 1:1 to the macro
' you already tested. After that, everything runs by clicking and Alt+F8 is
' no longer needed. Save the file (Ctrl+S) so the buttons are kept.
' BuildButtons is safe to re-run: it deletes the buttons it created before
' (names starting with "btn") and recreates them. No run logic is changed;
' the buttons are only a clickable skin over the existing macros.
'==============================================================================
Option Explicit

Public Sub BuildButtons()
    Dim panel As Worksheet
    Dim logWs As Worksheet
    Dim r As Long
    Dim code As String

    Set panel = ThisWorkbook.Worksheets(SHEET_PANEL)
    Set logWs = ThisWorkbook.Worksheets(SHEET_LOG)

    DeleteOurButtons panel
    DeleteOurButtons logWs

    ' --- Folder row: browse for the folder / refresh the status / help ---
    AddButton panel, "F4", "btnBrowse", "Browse...", "BrowseFolder", False
    AddButton panel, "F5", "btnRefresh", "Refresh Status", "RefreshStatus", False
    AddButton panel, "F6", "btnHelp", "Help", "ShowHelp", False

    ' --- One [Run] button per test row (column E, rows 9-14).
    '     The macro name is built from the test code in column A of that row. ---
    For r = PANEL_TEST_TABLE_FIRST_ROW To PANEL_TEST_TABLE_LAST_ROW
        code = UCase(Trim(CStr(panel.Cells(r, 1).Value)))
        If code <> "" Then
            AddButton panel, panel.Cells(r, 5).Address, "btnRun_" & code, "Run", "Run_" & code, True
        End If
    Next r

    ' --- Advanced section ---
    AddButton panel, "C17", "btnRefreshList", "Refresh Script List", "RefreshMacroListForSelectedTest", False
    AddButton panel, "D17", "btnScanSel", "Scan Selected Test", "ScanSelectedTest", False
    AddButton panel, "E17", "btnScanAll", "Scan All Tests", "ScanAllTests", False
    AddButton panel, "C18", "btnRunSel", "Run Selected Script", "RunSelected", True

    ' --- Run All Tests (A22, merged A22:B22) ---
    AddButton panel, "A22", "btnRunAll", "Run All Tests", "RunAllTests", True

    ' --- Scheduled run (row 23): labels + run-time default + Start/Stop ---
    SetupScheduleRow panel
    AddButton panel, "D23", "btnStartSched", "Start Schedule", "StartSchedule", False
    AddButton panel, "E23", "btnStopSched", "Stop Schedule", "StopSchedule", False

    ' --- Run Log sheet: Clear Log (H2) ---
    AddButton logWs, "H2", "btnClearLog", "Clear Log", "ClearLog", False

    MsgBox "Buttons created. From now on, just click the buttons on the Control Panel and Run Log sheets." & vbCrLf & _
           "Please save the file now (Ctrl+S) so the buttons are kept.", vbInformation, "Build Buttons"
End Sub

' Delete only the buttons created by this module (names starting with "btn").
Private Sub DeleteOurButtons(ByVal ws As Worksheet)
    Dim i As Long
    For i = ws.Shapes.Count To 1 Step -1
        If ws.Shapes(i).Name Like "btn*" Then ws.Shapes(i).Delete
    Next i
End Sub

' Fill in the row-23 schedule labels / defaults. The labels in A23/C23 are
' owned by this setup and are always refreshed; B23 keeps the user's own
' run time, except when it is empty or still holds a leftover interval
' number from the old repeating design (a whole number >= 1), in which
' case it defaults to tomorrow 09:00.
Private Sub SetupScheduleRow(ByVal ws As Worksheet)
    Dim v As Variant
    ws.Range("A23").Value = "Run once at:"
    ws.Range("C23").Value = "(one time)"
    ws.Range("A23").Font.Bold = True
    v = ws.Range("B23").Value
    If Trim(CStr(v)) = "" Or (IsNumeric(v) And CDbl(v) >= 1 And CDbl(v) = Int(CDbl(v))) Then
        ws.Range("B23").Value = Date + 1 + TimeSerial(9, 0, 0)
    End If
    If Trim(CStr(ws.Range("F23").Value)) = "" Then ws.Range("F23").Value = "Schedule is OFF"
End Sub

' Draw one Form Control button exactly over a cell (or its merged area)
' and bind it to a macro in this workbook.
Private Sub AddButton(ByVal ws As Worksheet, ByVal cellAddress As String, _
                      ByVal btnName As String, ByVal caption As String, _
                      ByVal macroName As String, ByVal bold As Boolean)
    Dim area As Range
    Dim btn As Button
    Set area = ws.Range(cellAddress)
    If area.MergeCells Then Set area = area.MergeArea
    Set btn = ws.Buttons.Add(area.Left, area.Top, area.Width, area.Height)
    btn.Name = btnName
    btn.Caption = caption
    btn.OnAction = macroName
    btn.Font.Size = 10
    btn.Font.Bold = bold
End Sub
