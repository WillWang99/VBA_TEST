Attribute VB_Name = "modFileOps"
'==============================================================================
' Module: modFileOps -- finding / opening / closing target files
' Key points:
'  1. The Windows file system is case-insensitive; Dir() finds files like
'     cgeb / CGEB even when the case differs.
'  2. Temporarily turn off EnableEvents while opening, so the target file's
'     Workbook_Open does not run automatically; restore EnableEvents after
'     opening, before actually running the script.
'  3. If the target file was already open, do not close it after the run
'     (only close files opened by Master).
'==============================================================================
Option Explicit

'------------------------------------------------------------------------------
' Find the target file by the file name in Config, inside the folder.
' Return the full path; return "" if not found.
' Use Dir() instead of concatenating, because Dir() returns the real file
' name on disk (exact case).
'------------------------------------------------------------------------------
Public Function FindTargetFilePath(ByVal testCode As String) As String
    Dim folder As String
    Dim fileName As String
    Dim found As String
    folder = GetFolderPath()
    If folder = "" Then Exit Function
    fileName = GetFileNameForTest(testCode)
    If fileName = "" Then Exit Function
    found = Dir(folder & "\" & fileName)
    If found = "" Then
        FindTargetFilePath = ""
    Else
        FindTargetFilePath = folder & "\" & found
    End If
End Function

'------------------------------------------------------------------------------
' Check whether the target file is already open in Excel (by file name, case-insensitive).
'------------------------------------------------------------------------------
Public Function GetOpenWorkbook(ByVal fileName As String) As Workbook
    Dim wb As Workbook
    For Each wb In Application.Workbooks
        If UCase(wb.Name) = UCase(fileName) Then
            Set GetOpenWorkbook = wb
            Exit Function
        End If
    Next wb
    Set GetOpenWorkbook = Nothing
End Function

'------------------------------------------------------------------------------
' Open the target file.
'   showTarget: True = visible window (default; compatible with scripts that
'               rely on ActiveSheet/Selection);
'               False = open in the background (faster, but some scripts may
'               fail without an active window).
'   wasAlreadyOpen: output parameter; tells the caller whether the file was
'               already open.
'------------------------------------------------------------------------------
Public Function OpenTargetWorkbook(ByVal filePath As String, ByVal showTarget As Boolean, _
                                   ByRef wasAlreadyOpen As Boolean) As Workbook
    Dim wb As Workbook
    Dim fileName As String
    Dim oldEvents As Boolean
    Dim oldAlerts As Boolean
    Dim oldScreen As Boolean

    fileName = Mid(filePath, InStrRev(filePath, "\") + 1)
    Set wb = GetOpenWorkbook(fileName)
    If Not wb Is Nothing Then
        wasAlreadyOpen = True
        wb.Windows(1).Visible = showTarget
        Set OpenTargetWorkbook = wb
        Exit Function
    End If

    wasAlreadyOpen = False
    oldEvents = Application.EnableEvents
    oldAlerts = Application.DisplayAlerts
    oldScreen = Application.ScreenUpdating
    On Error GoTo OpenFail
    Application.EnableEvents = False   ' Suppress the target file's Workbook_Open auto-run
    Application.DisplayAlerts = False
    Application.ScreenUpdating = False
    Set wb = Workbooks.Open(Filename:=filePath, UpdateLinks:=False, ReadOnly:=False)
    Application.EnableEvents = oldEvents
    Application.DisplayAlerts = oldAlerts
    Application.ScreenUpdating = oldScreen
    wb.Windows(1).Visible = showTarget
    Set OpenTargetWorkbook = wb
    Exit Function

OpenFail:
    Application.EnableEvents = oldEvents
    Application.DisplayAlerts = oldAlerts
    Application.ScreenUpdating = oldScreen
    Set OpenTargetWorkbook = Nothing
End Function

'------------------------------------------------------------------------------
' Close the target file. Only close files opened by Master; never close one
' that was already open.
' The test script may have written results back to the target file, so save on close.
'------------------------------------------------------------------------------
Public Sub CloseTargetWorkbook(ByVal wb As Workbook, ByVal wasAlreadyOpen As Boolean, _
                               ByVal closeAfter As Boolean)
    Dim oldAlerts As Boolean
    If wb Is Nothing Then Exit Sub
    If wasAlreadyOpen Then Exit Sub
    If Not closeAfter Then Exit Sub
    oldAlerts = Application.DisplayAlerts
    On Error Resume Next
    Application.DisplayAlerts = False
    wb.Close SaveChanges:=True
    Application.DisplayAlerts = oldAlerts
    On Error GoTo 0
End Sub
