Attribute VB_Name = "DummyModule"
'==============================================================================
' Dummy test macros (only for verifying Master itself per docs/TEST_PLAN.md; not for real files)
' Usage: create a new .xlsm -> Alt+F11 -> import this file -> save.
'==============================================================================
Option Explicit

Public Sub DummyTest()
    ' Write the run time into A1 of the first sheet of the current workbook,
    ' proving the script was actually called by Master.
    ThisWorkbook.Worksheets(1).Range("A1").Value = "DummyTest ran at " & Format(Now, "yyyy-mm-dd hh:nn:ss")
    ThisWorkbook.Save
End Sub

Public Sub DummyTest2()
    MsgBox "DummyTest2 ran (called by Master).", vbInformation, "Dummy"
End Sub
