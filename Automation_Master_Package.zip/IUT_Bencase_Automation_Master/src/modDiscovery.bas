﻿Attribute VB_Name = "modDiscovery"
'==============================================================================
' 模块：modDiscovery —— 扫描目标文件里可运行的宏（Public Sub）
' 原理：通过 VBProject 枚举标准模块里的过程名。
' 注意：这需要 Excel 信任“对 VBA 工程对象模型的访问”，否则会报错。
'      报错时 Master 会弹出英文指引，并回退到 Config 表里手工维护的宏列表，
'      不会崩溃。这是刻意设计的降级路径，不是 Bug。
' 为避免引用“Microsoft Visual Basic for Applications Extensibility”导致
' 在个别机器上出现“缺少引用”，本模块全部使用 Object 后期绑定 + 数字常量。
'==============================================================================
Option Explicit

' vbext_ComponentType / vbext_ProcKind 的数字常量（避免引用 VBIDE 库）
Private Const VBEXT_CT_STDMODULE As Long = 1   ' 标准模块
Private Const VBEXT_PK_PROC As Long = 0        ' Sub / Function 过程

'------------------------------------------------------------------------------
' 枚举一个已打开工作簿里的 Public Sub 宏名（去重，保持模块内出现顺序）。
' 返回 Collection；若无权访问 VBProject 则返回空 Collection 并由调用方处理错误。
'------------------------------------------------------------------------------
Public Function ListMacrosInWorkbook(ByVal wb As Workbook) As Collection
    Dim result As New Collection
    Dim vbProj As Object
    Dim vbComp As Object
    Dim codeMod As Object
    Dim lineCount As Long
    Dim i As Long
    Dim procName As String
    Dim procStart As Long
    Dim declLine As String

    On Error GoTo Fail
    Set vbProj = wb.VBProject   ' <-- 若未信任访问，此处报错 1004 / 50289
    For Each vbComp In vbProj.VBComponents
        If vbComp.Type = VBEXT_CT_STDMODULE Then
            Set codeMod = vbComp.CodeModule
            lineCount = codeMod.CountOfLines
            For i = 1 To lineCount
                procName = ""
                On Error Resume Next
                procName = codeMod.ProcOfLine(i, VBEXT_PK_PROC)
                On Error GoTo Fail
                If procName <> "" Then
                    ' 只收一次：用 Key 去重（先清 Err，避免上一行残留的错误号干扰判断）
                    On Error Resume Next
                    Err.Clear
                    result.Add procName, UCase(procName)
                    If Err.Number = 0 Then
                        ' 新收的宏：检查声明行，跳过 Private Sub
                        procStart = codeMod.ProcStartLine(procName, VBEXT_PK_PROC)
                        declLine = codeMod.Lines(procStart, 1)
                        If InStr(1, declLine, "Private", vbTextCompare) > 0 Then
                            result.Remove UCase(procName)
                        End If
                    End If
                    Err.Clear
                    On Error GoTo Fail
                End If
            Next i
        End If
    Next vbComp
    Set ListMacrosInWorkbook = result
    Exit Function

Fail:
    ' 把错误抛给调用方，由调用方判断是否为“未信任访问”并给出英文指引
    Err.Raise Err.Number, Err.Source, Err.Description
End Function

'------------------------------------------------------------------------------
' 扫描某个测试的目标文件，把宏列表写回 Config 表的 D 列；
' 若默认宏为空且扫到至少一个宏，则把第一个宏设为默认宏。
' 返回值：成功扫到的宏个数；-1 表示因“未信任访问”失败。
'------------------------------------------------------------------------------
Public Function ScanAndUpdateConfig(ByVal testCode As String) As Long
    Dim filePath As String
    Dim wb As Workbook
    Dim wasOpen As Boolean
    Dim macros As Collection
    Dim macroStr As String

    ScanAndUpdateConfig = -1
    If Not IsTestEnabled(testCode) Then
        MsgBox "Test " & testCode & " is disabled in the Config sheet (Enabled <> YES).", vbInformation, "Skipped"
        ScanAndUpdateConfig = 0
        Exit Function
    End If

    filePath = FindTargetFilePath(testCode)
    If filePath = "" Then
        MsgBox "Cannot find the file for test " & testCode & ": " & GetFileNameForTest(testCode) & vbCrLf & _
               "Please confirm the file is in folder " & GetFolderPath() & " or click [Browse...] to change the folder.", _
               vbExclamation, "File Not Found"
        ScanAndUpdateConfig = 0
        Exit Function
    End If

    Set wb = OpenTargetWorkbook(filePath, False, wasOpen)
    If wb Is Nothing Then
        MsgBox "Cannot open file: " & filePath, vbExclamation, "Open Failed"
        ScanAndUpdateConfig = 0
        Exit Function
    End If

    On Error GoTo ScanFail
    Set macros = ListMacrosInWorkbook(wb)
    On Error GoTo 0
    macroStr = JoinMacroList(macros)
    SetAllMacrosStringForTest testCode, macroStr
    If GetDefaultMacroForTest(testCode) = "" And macros.Count > 0 Then
        SetDefaultMacroForTest testCode, macros(1)
    End If
    CloseTargetWorkbook wb, wasOpen, True
    ScanAndUpdateConfig = macros.Count
    Exit Function

ScanFail:
    CloseTargetWorkbook wb, wasOpen, True
    If Err.Number = 1004 Or Err.Number = 50289 Or InStr(1, Err.Description, "Programmatic access", vbTextCompare) > 0 _
       Or InStr(1, Err.Description, "信任", vbTextCompare) > 0 Then
        MsgBox "Scanning requires Excel to trust 'Access to the VBA project object model', which is currently not enabled." & vbCrLf & vbCrLf & _
               "To enable: File -> Options -> Trust Center -> Trust Center Settings -> Macro Settings -> " & vbCrLf & _
               "check 'Trust access to the VBA project object model' -> OK -> reopen Master." & vbCrLf & vbCrLf & _
               "Alternatively, type the macro names directly in column D of the Config sheet (comma-separated);" & vbCrLf & _
               "Master will use the Config list directly, which does not affect running.", vbExclamation, "Trust Access Required"
        ScanAndUpdateConfig = -1
    Else
        MsgBox "Error scanning " & testCode & ": " & Err.Description, vbExclamation, "Scan Failed"
        ScanAndUpdateConfig = 0
    End If
End Function

'------------------------------------------------------------------------------
' 根据高级区所选测试，把该测试的宏列表设为“所选脚本”单元格的下拉选项。
'------------------------------------------------------------------------------
Public Sub RefreshMacroListForSelectedTest()
    Dim testCode As String
    Dim macroStr As String
    Dim macros As Collection
    Dim ws As Worksheet
    Dim cell As Range
    Dim listStr As String
    Dim v As Variant

    testCode = GetSelectedTest()
    If testCode = "" Then
        MsgBox "Please select a test in the 'Test' cell first.", vbInformation, "No Test Selected"
        Exit Sub
    End If
    macroStr = GetAllMacrosStringForTest(testCode)
    If Trim(macroStr) = "" Then
        If MsgBox("Test " & testCode & " has no macro list in the Config sheet yet. Scan its file now?", _
                  vbYesNo + vbQuestion, "Macro List Empty") = vbYes Then
            If ScanAndUpdateConfig(testCode) < 0 Then Exit Sub
            macroStr = GetAllMacrosStringForTest(testCode)
        Else
            Exit Sub
        End If
    End If
    If Trim(macroStr) = "" Then
        MsgBox "No runnable Public Sub macro found in the file for test " & testCode & ".", vbInformation, "No Macros Available"
        Exit Sub
    End If

    Set macros = SplitMacroList(macroStr)
    listStr = ""
    For Each v In macros
        If listStr = "" Then listStr = CStr(v) Else listStr = listStr & "," & CStr(v)
    Next v

    Set ws = ThisWorkbook.Worksheets(SHEET_PANEL)
    Set cell = ws.Range(PANEL_SEL_MACRO_CELL)
    On Error Resume Next
    cell.Validation.Delete
    On Error GoTo 0
    ' 数据验证下拉的 Formula1 字符串上限约 255 字符；超长时不设下拉，改为自由输入
    If Len(listStr) <= 250 Then
        cell.Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Formula1:=listStr
    End If
    cell.Value = macros(1)
    MsgBox "Refreshed the script list for test " & testCode & ": " & macros.Count & " found.", vbInformation, "Refreshed"
End Sub
