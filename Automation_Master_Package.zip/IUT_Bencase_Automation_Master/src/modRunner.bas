﻿Attribute VB_Name = "modRunner"
'==============================================================================
' 模块：modRunner —— 运行目标文件中的测试脚本（核心）
' 调用链：按钮 → Run_CCB / RunSelected / RunAllTests → RunTest → RunMacro
' RunMacro 的职责：校验 → 打开目标文件 → Application.Run → 记录日志 → 关闭文件
' 单个测试失败时只记日志、不中断“Run All Tests”的后续测试。
'==============================================================================
Option Explicit

'------------------------------------------------------------------------------
' 运行某个测试的默认脚本（Config 表 C 列）。由一键按钮调用。
'------------------------------------------------------------------------------
Public Function RunTest(ByVal testCode As String) As Boolean
    Dim macroName As String
    If Not IsTestEnabled(testCode) Then
        MsgBox "Test " & testCode & " is disabled in the Config sheet (Enabled <> YES).", vbInformation, "Skipped"
        RunTest = False
        Exit Function
    End If
    macroName = GetDefaultMacroForTest(testCode)
    If macroName = "" Then
        MsgBox "Test " & testCode & " has no default script set." & vbCrLf & vbCrLf & _
               "Please enter the default macro name for this test in column C of the Config sheet," & vbCrLf & _
               "or select the test in the Advanced section and click [Refresh Script List], then [Scan].", vbExclamation, "Default Script Not Set"
        RunTest = False
        Exit Function
    End If
    RunTest = RunMacro(testCode, macroName, GetCloseAfter(), GetShowTarget())
End Function

'------------------------------------------------------------------------------
' 运行指定测试的指定脚本。返回 True = 成功，False = 失败。
'------------------------------------------------------------------------------
Public Function RunMacro(ByVal testCode As String, ByVal macroName As String, _
                         ByVal closeAfter As Boolean, ByVal showTarget As Boolean) As Boolean
    Dim filePath As String
    Dim fileName As String
    Dim wb As Workbook
    Dim wasOpen As Boolean
    Dim startTime As Double
    Dim durationSec As Double
    Dim runTarget As String
    Dim errMsg As String

    If IsRunning Then
        MsgBox "A script is already running. Please wait for it to finish.", vbExclamation, "Running"
        RunMacro = False
        Exit Function
    End If
    IsRunning = True
    startTime = Timer
    On Error GoTo RunFail

    ' --- 校验 ---
    filePath = FindTargetFilePath(testCode)
    If filePath = "" Then
        errMsg = "Cannot find file " & GetFileNameForTest(testCode) & "，Please confirm the file is in folder " & GetFolderPath() & "."
        GoTo LogFail
    End If
    fileName = Mid(filePath, InStrRev(filePath, "\") + 1)
    If Trim(macroName) = "" Then
        errMsg = "No script name specified."
        GoTo LogFail
    End If

    ' --- 打开目标文件 ---
    Set wb = OpenTargetWorkbook(filePath, showTarget, wasOpen)
    If wb Is Nothing Then
        errMsg = "Cannot open file " & filePath
        GoTo LogFail
    End If

    ' --- 运行脚本 ---
    ' Application.Run 的完整形式：'文件名'!宏名。宏名可带模块前缀，如 Module1.RunAll。
    runTarget = "'" & fileName & "'!" & macroName
    Application.StatusBar = "Running script " & macroName & " for test " & testCode & " ..."
    Application.Run runTarget
    Application.StatusBar = False

    durationSec = Timer - startTime
    If durationSec < 0 Then durationSec = durationSec + 86400 ' 跨午夜修正
    CloseTargetWorkbook wb, wasOpen, closeAfter
    IsRunning = False
    AppendLog testCode, fileName, macroName, "Success", durationSec, "Took " & Round(durationSec, 2) & " seconds"
    RunMacro = True
    Exit Function

LogFail:
    durationSec = Timer - startTime
    If durationSec < 0 Then durationSec = durationSec + 86400
    IsRunning = False
    Application.StatusBar = False
    AppendLog testCode, fileName, macroName, "Failed", durationSec, errMsg
    MsgBox errMsg, vbExclamation, "Run Failed: " & testCode
    RunMacro = False
    Exit Function

RunFail:
    errMsg = "Error running script " & macroName & " for test " & testCode & ": " & Err.Description & " (Error " & Err.Number & ")"
    If Not wb Is Nothing Then
        On Error Resume Next
        CloseTargetWorkbook wb, wasOpen, closeAfter
        On Error GoTo 0
    End If
    Resume LogFail
End Function

'------------------------------------------------------------------------------
' 高级区：运行所选测试的所选脚本。
'------------------------------------------------------------------------------
Public Sub RunSelected()
    Dim testCode As String
    Dim macroName As String
    testCode = GetSelectedTest()
    macroName = GetSelectedMacro()
    If testCode = "" Then
        MsgBox "Please select a test in the 'Test' cell first.", vbInformation, "No Test Selected"
        Exit Sub
    End If
    If macroName = "" Then
        MsgBox "Please select a script in the 'Script' cell first (click [Refresh Script List]).", vbInformation, "No Script Selected"
        Exit Sub
    End If
    RunMacro testCode, macroName, GetCloseAfter(), GetShowTarget()
End Sub

'------------------------------------------------------------------------------
' 运行全部已启用的测试的默认脚本（按 Config 表顺序）。单个失败不中断其余。
'------------------------------------------------------------------------------
Public Sub RunAllTests()
    Dim ws As Worksheet
    Dim r As Long
    Dim testCode As String
    Dim okCount As Long
    Dim failCount As Long
    Dim skipCount As Long
    Dim summary As String
    If IsRunning Then
        MsgBox "A script is already running. Please wait for it to finish.", vbExclamation, "Running"
        Exit Sub
    End If
    If MsgBox("This will run the default script of every enabled test in Config order. Continue?", _
              vbYesNo + vbQuestion, "Run All Tests") <> vbYes Then Exit Sub
    Set ws = ThisWorkbook.Worksheets(SHEET_CONFIG)
    For r = CONFIG_FIRST_ROW To CONFIG_LAST_ROW
        testCode = Trim(CStr(ws.Cells(r, CONFIG_COL_TEST).Value))
        If testCode = "" Then
            skipCount = skipCount + 1
        ElseIf Not IsTestEnabled(testCode) Then
            skipCount = skipCount + 1
        Else
            If RunTest(testCode) Then okCount = okCount + 1 Else failCount = failCount + 1
        End If
    Next r
    summary = "All runs finished: " & okCount & " succeeded, " & failCount & " failed, " & skipCount & " skipped." & vbCrLf & _
              "See the Run Log sheet for details."
    MsgBox summary, vbInformation, "Run All Tests"
End Sub

'------------------------------------------------------------------------------
' 一键按钮的 6 个入口（Control Panel 上每个测试的按钮各绑定一个）。
' 保持一对一绑定：即使按钮被移动、复制，也不会因 Application.Caller 解析出错。
'------------------------------------------------------------------------------
Public Sub Run_CCB()
    RunTest "CCB"
End Sub

Public Sub Run_ACWB()
    RunTest "ACWB"
End Sub

Public Sub Run_PEICB()
    RunTest "PEICB"
End Sub

Public Sub Run_OSTC()
    RunTest "OSTC"
End Sub

Public Sub Run_CGEB()
    RunTest "CGEB"
End Sub

Public Sub Run_NLDB()
    RunTest "NLDB"
End Sub
