﻿Attribute VB_Name = "modFileOps"
'==============================================================================
' 模块：modFileOps —— 目标文件的查找 / 打开 / 关闭
' 关键点：
'  1. Windows 文件系统不区分大小写，Dir() 能找到 cgeb / CGEB 这种大小写不一致的文件。
'  2. 打开时临时关掉 EnableEvents，避免目标文件的 Workbook_Open 自动运行；
'     打开完成、正式运行脚本之前再恢复 EnableEvents。
'  3. 如果目标文件本来就已打开，运行后不关闭它（只关闭由 Master 打开的）。
'==============================================================================
Option Explicit

'------------------------------------------------------------------------------
' 按 Config 里的文件名，在文件夹中查找目标文件。
' 返回完整路径；找不到返回 ""。
' 用 Dir() 而不是直接拼接，因为 Dir() 返回磁盘上的真实文件名（大小写准确）。
'------------------------------------------------------------------------------
Public Function FindTargetFilePath(ByVal testCode As String) As String
    Dim folder As String
    Dim fileName As String
    Dim found As String
    folder = GetFolderPath()
    If folder = "" Then Exit Function
    fileName = GetFileNameForTest(testCode)
    If fileName = "" Then Exit Function
    found = Dir(folder & "\" & fileName)
    If found = "" Then
        FindTargetFilePath = ""
    Else
        FindTargetFilePath = folder & "\" & found
    End If
End Function

'------------------------------------------------------------------------------
' 检查目标文件是否已经在 Excel 中打开（按文件名，不区分大小写）。
'------------------------------------------------------------------------------
Public Function GetOpenWorkbook(ByVal fileName As String) As Workbook
    Dim wb As Workbook
    For Each wb In Application.Workbooks
        If UCase(wb.Name) = UCase(fileName) Then
            Set GetOpenWorkbook = wb
            Exit Function
        End If
    Next wb
    Set GetOpenWorkbook = Nothing
End Function

'------------------------------------------------------------------------------
' 打开目标文件。
'   showTarget: True = 可见窗口（默认，兼容依赖 ActiveSheet/Selection 的脚本）；
'               False = 后台打开（运行更快，但个别脚本可能因无活动窗口而报错）。
'   wasAlreadyOpen: 输出参数，告诉调用方该文件是否本来就开着。
'------------------------------------------------------------------------------
Public Function OpenTargetWorkbook(ByVal filePath As String, ByVal showTarget As Boolean, _
                                   ByRef wasAlreadyOpen As Boolean) As Workbook
    Dim wb As Workbook
    Dim fileName As String
    Dim oldEvents As Boolean
    Dim oldAlerts As Boolean
    Dim oldScreen As Boolean

    fileName = Mid(filePath, InStrRev(filePath, "\") + 1)
    Set wb = GetOpenWorkbook(fileName)
    If Not wb Is Nothing Then
        wasAlreadyOpen = True
        wb.Windows(1).Visible = showTarget
        Set OpenTargetWorkbook = wb
        Exit Function
    End If

    wasAlreadyOpen = False
    oldEvents = Application.EnableEvents
    oldAlerts = Application.DisplayAlerts
    oldScreen = Application.ScreenUpdating
    On Error GoTo OpenFail
    Application.EnableEvents = False   ' 抑制目标文件的 Workbook_Open 自动运行
    Application.DisplayAlerts = False
    Application.ScreenUpdating = False
    Set wb = Workbooks.Open(Filename:=filePath, UpdateLinks:=False, ReadOnly:=False)
    Application.EnableEvents = oldEvents
    Application.DisplayAlerts = oldAlerts
    Application.ScreenUpdating = oldScreen
    wb.Windows(1).Visible = showTarget
    Set OpenTargetWorkbook = wb
    Exit Function

OpenFail:
    Application.EnableEvents = oldEvents
    Application.DisplayAlerts = oldAlerts
    Application.ScreenUpdating = oldScreen
    Set OpenTargetWorkbook = Nothing
End Function

'------------------------------------------------------------------------------
' 关闭目标文件。只有关闭由 Master 打开的文件；本来就开着的不关闭。
' 测试脚本可能已把结果写回目标文件，因此关闭时保存。
'------------------------------------------------------------------------------
Public Sub CloseTargetWorkbook(ByVal wb As Workbook, ByVal wasAlreadyOpen As Boolean, _
                               ByVal closeAfter As Boolean)
    Dim oldAlerts As Boolean
    If wb Is Nothing Then Exit Sub
    If wasAlreadyOpen Then Exit Sub
    If Not closeAfter Then Exit Sub
    oldAlerts = Application.DisplayAlerts
    On Error Resume Next
    Application.DisplayAlerts = False
    wb.Close SaveChanges:=True
    Application.DisplayAlerts = oldAlerts
    On Error GoTo 0
End Sub
