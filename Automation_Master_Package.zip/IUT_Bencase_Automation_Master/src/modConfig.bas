﻿Attribute VB_Name = "modConfig"
'==============================================================================
' 模块：modConfig —— 配置读写（Config 表 + Control Panel 上的选项）
' 说明：所有“测试 / 文件名 / 默认宏 / 选项”都存在工作表里，不写死在代码中。
'      同事要新增测试或改宏名，只需改 Config 表，无需改代码。
'==============================================================================
Option Explicit

' --- 工作表名（请勿随意改名，代码依赖这三个名字）---
Public Const SHEET_PANEL As String = "Control Panel"
Public Const SHEET_CONFIG As String = "Config"
Public Const SHEET_LOG As String = "Run Log"

' --- Config 表结构（第 1 行是标题，第 2~7 行是 6 个测试）---
Public Const CONFIG_FIRST_ROW As Long = 2
Public Const CONFIG_LAST_ROW As Long = 7
Public Const CONFIG_COL_TEST As Long = 1   ' A: Test Code
Public Const CONFIG_COL_FILE As Long = 2   ' B: File Name
Public Const CONFIG_COL_DEFAULT_MACRO As Long = 3 ' C: Default Macro
Public Const CONFIG_COL_ALL_MACROS As Long = 4    ' D: All Macros（逗号分隔）
Public Const CONFIG_COL_DESC As Long = 5   ' E: Description
Public Const CONFIG_COL_ENABLED As Long = 6 ' F: Enabled (YES/NO)

' --- Control Panel 关键单元格（见 README 里的布局图）---
Public Const PANEL_FOLDER_CELL As String = "B4"   ' 测试文件文件夹
Public Const PANEL_TEST_TABLE_FIRST_ROW As Long = 9 ' 测试表格第 1 行
Public Const PANEL_TEST_TABLE_LAST_ROW As Long = 14 ' 6 个测试
Public Const PANEL_SEL_TEST_CELL As String = "B17"  ' 高级区：所选测试
Public Const PANEL_SEL_MACRO_CELL As String = "B18"  ' 高级区：所选脚本
Public Const PANEL_CLOSE_AFTER_CELL As String = "B20" ' 运行后关闭目标文件 YES/NO
Public Const PANEL_SHOW_TARGET_CELL As String = "B21" ' 显示目标文件窗口 YES/NO
Public Const PANEL_LOG_PREVIEW_FIRST_ROW As Long = 26 ' 日志预览数据第 1 行（第 25 行是预览表头）
Public Const PANEL_LOG_PREVIEW_ROWS As Long = 10

' --- 运行状态标志（防止重复点击 / 关闭时Running）---
Public IsRunning As Boolean

'------------------------------------------------------------------------------
' 文件夹：优先读 Control Panel!B4；若为空则用 Master 文件所在文件夹并写回
'------------------------------------------------------------------------------
Public Function GetFolderPath() As String
    Dim ws As Worksheet
    Dim p As String
    Set ws = ThisWorkbook.Worksheets(SHEET_PANEL)
    p = Trim(CStr(ws.Range(PANEL_FOLDER_CELL).Value))
    If p = "" Then
        p = ThisWorkbook.Path
        If p = "" Then
            MsgBox "Please save the Master file first, then run it.", vbExclamation, "Master Not Saved"
            GetFolderPath = ""
            Exit Function
        End If
        ws.Range(PANEL_FOLDER_CELL).Value = p
    End If
    ' 去掉末尾的反斜杠（根目录除外）
    If Len(p) > 3 And Right(p, 1) = "\" Then p = Left(p, Len(p) - 1)
    GetFolderPath = p
End Function

Public Sub SetFolderPath(ByVal p As String)
    ThisWorkbook.Worksheets(SHEET_PANEL).Range(PANEL_FOLDER_CELL).Value = p
End Sub

'------------------------------------------------------------------------------
' Config 表：按测试代码找行号，找不到返回 0
'------------------------------------------------------------------------------
Public Function GetTestRow(ByVal testCode As String) As Long
    Dim ws As Worksheet
    Dim r As Long
    Set ws = ThisWorkbook.Worksheets(SHEET_CONFIG)
    For r = CONFIG_FIRST_ROW To CONFIG_LAST_ROW
        If UCase(Trim(CStr(ws.Cells(r, CONFIG_COL_TEST).Value))) = UCase(Trim(testCode)) Then
            GetTestRow = r
            Exit Function
        End If
    Next r
    GetTestRow = 0
End Function

Public Function GetFileNameForTest(ByVal testCode As String) As String
    Dim r As Long
    r = GetTestRow(testCode)
    If r = 0 Then Exit Function
    GetFileNameForTest = Trim(CStr(ThisWorkbook.Worksheets(SHEET_CONFIG).Cells(r, CONFIG_COL_FILE).Value))
End Function

Public Function GetDefaultMacroForTest(ByVal testCode As String) As String
    Dim r As Long
    r = GetTestRow(testCode)
    If r = 0 Then Exit Function
    GetDefaultMacroForTest = Trim(CStr(ThisWorkbook.Worksheets(SHEET_CONFIG).Cells(r, CONFIG_COL_DEFAULT_MACRO).Value))
End Function

Public Sub SetDefaultMacroForTest(ByVal testCode As String, ByVal macroName As String)
    Dim r As Long
    r = GetTestRow(testCode)
    If r = 0 Then Exit Sub
    ThisWorkbook.Worksheets(SHEET_CONFIG).Cells(r, CONFIG_COL_DEFAULT_MACRO).Value = macroName
End Sub

Public Function GetAllMacrosStringForTest(ByVal testCode As String) As String
    Dim r As Long
    r = GetTestRow(testCode)
    If r = 0 Then Exit Function
    GetAllMacrosStringForTest = Trim(CStr(ThisWorkbook.Worksheets(SHEET_CONFIG).Cells(r, CONFIG_COL_ALL_MACROS).Value))
End Function

Public Sub SetAllMacrosStringForTest(ByVal testCode As String, ByVal macroList As String)
    Dim r As Long
    r = GetTestRow(testCode)
    If r = 0 Then Exit Sub
    ThisWorkbook.Worksheets(SHEET_CONFIG).Cells(r, CONFIG_COL_ALL_MACROS).Value = macroList
End Sub

Public Function IsTestEnabled(ByVal testCode As String) As Boolean
    Dim r As Long
    Dim v As String
    r = GetTestRow(testCode)
    If r = 0 Then
        IsTestEnabled = False
        Exit Function
    End If
    v = UCase(Trim(CStr(ThisWorkbook.Worksheets(SHEET_CONFIG).Cells(r, CONFIG_COL_ENABLED).Value)))
    IsTestEnabled = (v = "YES" Or v = "Y" Or v = "TRUE" Or v = "1")
End Function

'------------------------------------------------------------------------------
' 把 "MacroA, MacroB, MacroC" 拆成去重后的 Collection
'------------------------------------------------------------------------------
Public Function SplitMacroList(ByVal s As String) As Collection
    Dim c As New Collection
    Dim parts() As String
    Dim i As Long
    Dim m As String
    If Trim(s) = "" Then
        Set SplitMacroList = c
        Exit Function
    End If
    parts = Split(s, ",")
    For i = LBound(parts) To UBound(parts)
        m = Trim(CStr(parts(i)))
        If m <> "" Then
            On Error Resume Next
            c.Add m, UCase(m)  ' 用大写做 Key 去重
            On Error GoTo 0
        End If
    Next i
    Set SplitMacroList = c
End Function

Public Function JoinMacroList(ByVal c As Collection) As String
    Dim out As String
    Dim v As Variant
    For Each v In c
        If out = "" Then
            out = CStr(v)
        Else
            out = out & ", " & CStr(v)
        End If
    Next v
    JoinMacroList = out
End Function

'------------------------------------------------------------------------------
' 高级区选项
'------------------------------------------------------------------------------
Public Function GetSelectedTest() As String
    GetSelectedTest = Trim(CStr(ThisWorkbook.Worksheets(SHEET_PANEL).Range(PANEL_SEL_TEST_CELL).Value))
End Function

Public Function GetSelectedMacro() As String
    GetSelectedMacro = Trim(CStr(ThisWorkbook.Worksheets(SHEET_PANEL).Range(PANEL_SEL_MACRO_CELL).Value))
End Function

Public Function GetCloseAfter() As Boolean
    Dim v As String
    v = UCase(Trim(CStr(ThisWorkbook.Worksheets(SHEET_PANEL).Range(PANEL_CLOSE_AFTER_CELL).Value)))
    GetCloseAfter = Not (v = "NO" Or v = "N" Or v = "FALSE" Or v = "0")
End Function

Public Function GetShowTarget() As Boolean
    Dim v As String
    v = UCase(Trim(CStr(ThisWorkbook.Worksheets(SHEET_PANEL).Range(PANEL_SHOW_TARGET_CELL).Value)))
    GetShowTarget = Not (v = "NO" Or v = "N" Or v = "FALSE" Or v = "0")
End Function

'------------------------------------------------------------------------------
' 更新 Control Panel 测试表格里某一行的“Last Result”（F 列）
'------------------------------------------------------------------------------
Public Sub SetPanelLastResult(ByVal testCode As String, ByVal text As String)
    Dim ws As Worksheet
    Dim r As Long
    Set ws = ThisWorkbook.Worksheets(SHEET_PANEL)
    For r = PANEL_TEST_TABLE_FIRST_ROW To PANEL_TEST_TABLE_LAST_ROW
        If UCase(Trim(CStr(ws.Cells(r, 1).Value))) = UCase(Trim(testCode)) Then
            ws.Cells(r, 6).Value = text
            Exit Sub
        End If
    Next r
End Sub
