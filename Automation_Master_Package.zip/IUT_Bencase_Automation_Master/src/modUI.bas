﻿Attribute VB_Name = "modUI"
'==============================================================================
' 模块：modUI —— Control Panel 上按钮的入口 + 状态刷新 + 文件夹浏览
' Auto_Open 在 Master 打开时自动执行（前提：已启用宏），刷新文件状态。
'==============================================================================
Option Explicit

'------------------------------------------------------------------------------
' 打开 Master 时自动刷新文件状态（不需要用户点任何按钮）。
'------------------------------------------------------------------------------
Public Sub Auto_Open()
    On Error Resume Next
    RefreshStatus True   ' 打开时静默刷新，不弹窗打扰
    ThisWorkbook.Worksheets(SHEET_PANEL).Activate
    UpdateLogPreview
    On Error GoTo 0
End Sub

'------------------------------------------------------------------------------
' 刷新 Control Panel 测试表格：文件名 / 默认脚本 / 文件状态。
' 不覆盖“Last Result”列。
' Silent=True 时不弹窗（供 Auto_Open / Workbook_Open 调用）。
'------------------------------------------------------------------------------
Public Sub RefreshStatus(Optional ByVal Silent As Boolean = False)
    Dim panelWs As Worksheet
    Dim configWs As Worksheet
    Dim r As Long, pr As Long
    Dim testCode As String
    Dim filePath As String
    Dim folder As String

    folder = GetFolderPath()
    If folder = "" Then Exit Sub
    Set panelWs = ThisWorkbook.Worksheets(SHEET_PANEL)
    Set configWs = ThisWorkbook.Worksheets(SHEET_CONFIG)

    For pr = PANEL_TEST_TABLE_FIRST_ROW To PANEL_TEST_TABLE_LAST_ROW
        testCode = Trim(CStr(panelWs.Cells(pr, 1).Value))
        If testCode <> "" Then
            ' 文件名与默认脚本始终以 Config 表为准
            panelWs.Cells(pr, 2).Value = GetFileNameForTest(testCode)
            panelWs.Cells(pr, 4).Value = GetDefaultMacroForTest(testCode)
            filePath = FindTargetFilePath(testCode)
            If filePath = "" Then
                panelWs.Cells(pr, 3).Value = "✗ Not found"
                panelWs.Cells(pr, 3).Font.Color = RGB(192, 0, 0)
            Else
                panelWs.Cells(pr, 3).Value = "✓ Found"
                panelWs.Cells(pr, 3).Font.Color = RGB(0, 112, 192)
            End If
        End If
    Next pr

    ' 高级区测试下拉：若为空，默认选第一家
    If Trim(CStr(panelWs.Range(PANEL_SEL_TEST_CELL).Value)) = "" Then
        panelWs.Range(PANEL_SEL_TEST_CELL).Value = Trim(CStr(configWs.Cells(CONFIG_FIRST_ROW, CONFIG_COL_TEST).Value))
    End If
    UpdateLogPreview
    If Not Silent Then
        MsgBox "Status refreshed. Folder: " & folder, vbInformation, "Refreshed"
    End If
End Sub

'------------------------------------------------------------------------------
' 浏览文件夹（Windows 文件夹选择框），选后刷新状态。
'------------------------------------------------------------------------------
Public Sub BrowseFolder()
    Dim dlg As FileDialog
    Dim folder As String
    Set dlg = Application.FileDialog(msoFileDialogFolderPicker)
    dlg.Title = "Select the folder containing the 6 test files"
    dlg.InitialFileName = GetFolderPath()
    If dlg.Show = -1 Then
        folder = dlg.SelectedItems(1)
        SetFolderPath folder
        RefreshStatus
    End If
End Sub

'------------------------------------------------------------------------------
' 扫描所选测试 / Scan All Tests（调用 modDiscovery）。
'------------------------------------------------------------------------------
Public Sub ScanSelectedTest()
    Dim testCode As String
    Dim n As Long
    testCode = GetSelectedTest()
    If testCode = "" Then
        MsgBox "Please select a test in the 'Test' cell first.", vbInformation, "No Test Selected"
        Exit Sub
    End If
    n = ScanAndUpdateConfig(testCode)
    If n >= 0 Then
        RefreshStatus
        MsgBox "Scan complete for test " & testCode & ": " & n & " runnable script(s) found and written back to the Config sheet.", vbInformation, "Scan Complete"
    End If
End Sub

Public Sub ScanAllTests()
    Dim ws As Worksheet
    Dim r As Long
    Dim testCode As String
    Dim n As Long
    Dim total As Long
    If MsgBox("This will open each of the 6 target files in turn and scan the scripts inside, writing them to the Config sheet. Continue?" & vbCrLf & _
              "(Requires trusted 'Access to the VBA project object model'; otherwise a guide will pop up.)", _
              vbYesNo + vbQuestion, "Scan All Tests") <> vbYes Then Exit Sub
    Set ws = ThisWorkbook.Worksheets(SHEET_CONFIG)
    For r = CONFIG_FIRST_ROW To CONFIG_LAST_ROW
        testCode = Trim(CStr(ws.Cells(r, CONFIG_COL_TEST).Value))
        If testCode <> "" And IsTestEnabled(testCode) Then
            n = ScanAndUpdateConfig(testCode)
            If n < 0 Then Exit Sub  ' 未信任访问：已弹出指引，中止扫描
            total = total + n
        End If
    Next r
    RefreshStatus
    MsgBox "All scans complete. " & total & " runnable script(s) found in total and written back to the Config sheet.", vbInformation, "Scan Complete"
End Sub

'------------------------------------------------------------------------------
' 快速帮助（Control Panel 上的 [Help] 按钮）。
'------------------------------------------------------------------------------
Public Sub ShowHelp()
    MsgBox "How to use (for colleagues who don't write code):" & vbCrLf & vbCrLf & _
           "1. Put the Master file and the 6 test files in the same folder." & vbCrLf & _
           "2. Open Master and click [Enable Macros] if prompted." & vbCrLf & _
           "3. In the test table, find the test you want to run and click its [Run] button." & vbCrLf & _
           "4. See the result in that row's 'Last Result' and on the Run Log sheet." & vbCrLf & vbCrLf & _
           "First time: confirm the default script (column C) for the 6 files on the Config sheet," & vbCrLf & _
           "or select a test in the Advanced section and click [Scan] to auto-fill." & vbCrLf & vbCrLf & _
           "See README.md in the same folder for details.", vbInformation, "Help"
End Sub
