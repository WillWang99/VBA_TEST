# Test Plan (first use, about 5 minutes)

Purpose: verify that Master itself works, without touching the real 6 files.
Please follow these steps in Windows Excel.

## Setup: make 2 Dummy target files (2 minutes)

1. Create a folder `MasterTest` on the Desktop. Keep Master (after injection) and this package
   outside that folder; put the Dummy files inside `MasterTest`.
2. Create `Dummy_CCB.xlsm`:
   - Create a new Excel file → Save As `Dummy_CCB.xlsm` (Macro-Enabled Workbook).
   - Press `Alt+F11` → Insert → Module → paste the contents of `docs/DummyMacro.bas` → Save.
   - The file contains two macros: `DummyTest` (writes the time into A1) and `DummyTest2` (pops up a MsgBox).
3. Copy `Dummy_CCB.xlsm` as `Dummy_ACWB.xlsm` (identical content is fine; only used to verify multiple tests).

## Test Steps

| # | Action | Expected result |
| --- | --- | --- |
| T1 | Open Master, click [Enable Macros]; change Control Panel B4 to the `MasterTest` folder path, click [Refresh Status] | B4 takes effect; the test table status updates |
| T2 | On the Config sheet, temporarily change the CCB row's column B to `Dummy_CCB.xlsm`, column C to `DummyTest`, keep column F as YES; change the ACWB row's column B to `Dummy_ACWB.xlsm`, column C to `DummyTest` | Config saved |
| T3 | Back on Control Panel, click [Refresh Status] | CCB and ACWB rows show `✓ Found` (the other 4 rows show `✗ Not found`, which is normal) |
| T4 | Click CCB row's [Run] | Dummy_CCB.xlsm is opened and run, A1 gets the time; Run Log gains a "Success" row; CCB row's "Last Result" updates |
| T5 | In the Advanced section, select test CCB, click [Refresh Script List] | The B18 dropdown shows `DummyTest, DummyTest2` (requires trusted access; otherwise type `DummyTest, DummyTest2` in Config column D by hand and retry) |
| T6 | In the Advanced section, select script `DummyTest2`, click [Run Selected Script] | A MsgBox pops up; Run Log gains a "Success" row |
| T7 | Click [Run All Tests] | CCB and ACWB succeed; the other tests are logged as "Failed" (file not found) but do not interrupt; a summary pops up at the end |
| T8 | Open Dummy_CCB.xlsm and confirm A1 has a timestamp | The target file was actually written by the script |
| T9 | Change the Config sheet back to the real 6 file names and macro names | Restored to the production configuration |

## Pass Criteria

- T4, T6, T7 pass, and there are no unexplained failures in Run Log → ready for the real files.
- If a step fails, send back the full message from that step + the Message column content of the
  corresponding Run Log row for locating the cause.

## Cleanup

After testing, delete the `MasterTest` folder and the Dummy files. The Run Log can be cleared with [Clear Log].
